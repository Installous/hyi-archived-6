  /* Done by Dacal mod by DemoneLatino */ 
 /* Thx to @schnedi for the refresh code */
       /** TWITTER @DemoneLatino **/

/* *************************************** */
/* The following scripts will allow you to fine tune */
/* *************************************** */

/* *************************************** */
/* ************* CLOCK **************** */

var Clock = "12h"; // <--- 12h or 24h choose you,change "12h" to "24h" if you use "24h"

/* *************************************** */
/* ************* LANGUAGE **************** */

//Choose Languages:  
//(fr) for french; 
//(de) for german; 
//(es) for spanish;
//(it) for italian;
//(en) for english;

var lang = "en" // <-- change here

/* *************************************** */
/* ************* Weather  **************** */

// Use www.weather.com to find your weathercode
// For example searching for Milan Italy will get you this URL
// http://www.weather.com/weather/right-now/Milan+Italy+ITXX0042
// The last part ITXX0042 is the weathercode to use in "var locale"

var gps = true;  // Requires MyLocation app

//you not have (GPS) "myLocation" download from cydia "GPS Weather Lockscreen" by crazyvivek(iOS 4.x - 5.0.1) or search on Google the version compatible with iOS 5.1.1 or 6.x contact me via cydia for more support or talk with me on TWITTER @DemoneLatino


var locale = "ITXX0042"   // put zipCode,if you want to use the GPS set GPS to false 


var tempUnit = "c"; // f for fahrenheit

var IconSet = "DemoneBrillant";  // add your own set

var iconExt = ".png"  // icons extension

var updateInterval = 5;  // in minutes

