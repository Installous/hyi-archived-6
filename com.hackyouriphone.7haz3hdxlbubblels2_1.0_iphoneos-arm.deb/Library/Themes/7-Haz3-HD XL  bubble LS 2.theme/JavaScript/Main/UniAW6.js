// UniAW6.21 By Ian Nicoll with credit to Dacal

var updateWeatherEvery = updateInterval*60*1000;
var xmldata = false;
var postal;
var filename = "";
var Start_wind_effects = false;
var Show_wind_effects = false;
var wind_effects;
var where = "";
var whereOld = "";
var DemoOn = false;
var refreshLocationTimer;
var updateTimer = 0;
var zip;
var TextColor = "TextColorGrey";
var meteorTimer;
if (screen.height > 500) {var iPhoneType = "iph5";} else {var iPhoneType = "iph4";}
$.ajaxSetup({timeout:10000}); // Set a time out for all ajax requests.

switch (lang) {
case "cn":
	var days = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
	var months=['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
	break;
case "fi":
    var days = ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"];
    var months = ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kesäkuu", "Heinäkuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"];
    break;	

case "fr":
    var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
    var months = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Decembre"];
    break;
case "de":
    var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
    var months = ["Januar", "Februar", "Maerz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];		
break;
case "nl":
    var days = ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"];
    var months = ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"];		
break;
case "sp":
    var days = ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"];
    var months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Juliot', 'Agosto', 'Septiembre', 'Octubre', 'Novimbre', 'Decimbre'];
    break;
case "it":
    var days = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"];
    var months = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
    break;
case "ru":
	var days = ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"];
	var months = ['Января','Февраля','Марта','Апреля','Мая','Июня','Июля','Августа','Сентября','Октября','Ноября','Декабря'];
	break;
default: 
    var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
break;
}

function updateClock () {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var mil = currentTime.getMilliseconds();
var currentDate = currentTime.getDate() < 10 ? '' + currentTime.getDate() : currentTime.getDate();
time_to_change_wall = currentHours + currentMinutes/60;
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (ampm == false) {
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
	} else {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
	}

// ANALOG CLOCK
if (Hide_AnalogClock == false) {

	// COMMON PART
	if (Second_Hand_Sweep == true) { 
		var sdegree = currentSeconds * 6 + (mil / (1000/6));
		var srotate = "rotate(" + sdegree + "deg)";
	} else {
		var sdegree = currentSeconds * 6;
		var srotate = "rotate(" + sdegree + "deg)";
	}

	var mdegree = currentMinutes * 6;
	var mrotate = "rotate(" + mdegree + "deg)";
	$("#minhand").css("-webkit-transform", mrotate );

	var hdegree = currentHours * 30 + (currentMinutes / 2);
	var hrotate = "rotate(" + hdegree + "deg)";
	$("#hourhand").css("-webkit-transform", hrotate );	
	// END COMMON PART
	
	switch (Second_Hand_Options) {
	case "big":
		$("#bigsechand").css("-webkit-transform", srotate );
	break;
	case "small":
		$("#smallsechand").css("-webkit-transform", srotate );
	break;
	case "both":
		$("#smallsechand, #bigsechand").css("-webkit-transform", srotate );
	break;
	}
	
	if 	(Hide_AnalogClock_Info == true) {
	document.getElementById("month").style.display='none';
	document.getElementById("year").style.display='none';
	document.getElementById("day").style.display='none';
	}
}
// END ANALOG CLOCK

	
if (Show_Single_Line_Date == true) {
document.getElementById("SingleLineDate").innerHTML = days[currentTime.getDay()] + ", " + months[currentTime.getMonth()] + " " + currentDate + ". " + currentTime.getFullYear(); 
}

document.getElementById("clock").innerHTML = currentTimeString;
document.getElementById("ampm").innerHTML = timeOfDay;
document.getElementById("second").innerHTML = currentSeconds;

document.getElementById("day").innerHTML = days[currentTime.getDay()] + ""; // Place comma & space between "" for seperation
document.getElementById("month").innerHTML = months[currentTime.getMonth()];
document.getElementById("year").innerHTML = currentTime.getFullYear();
document.getElementById("date").innerHTML = currentDate;

// DAY OR NIGHT CHANGE
if (xmldata == true) {
	if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { var whereTmp = "night";	} else { var whereTmp = "day"; }
	if (whereTmp != where) { window.location.reload(); }
}
// END
	
if ((DemoMode == false ) && (currentTime.getTime() - updateTimer >= updateWeatherEvery)) {
	if (updateTimer == 0) {
		if (gps == true) { UpdateLocation(); } else { convertWoeid(); }
		} else {
		if (zip != null) { weatherRefresherTemp(zip) } else { convertWoeid(); } ;
		}
	updateTimer = currentTime.getTime();
	}	

}

function init(){
if (iPhoneType == "iph4") { replacejscssfile("Main", "UniAW6_iph5", "UniAW6_iph4", "css"); }
if (Dandelion_Effects == true) { wind_effects = "dandelion_effects"; } else { wind_effects = "leaves_effects"; }

if (DacalSun == true) {
document.getElementById("sun").style.backgroundImage = "url(Images/Weather/sun/sun2.png)";
document.getElementById("sunray").style.backgroundImage = "url(Images/Weather/sun/sunray0.png)";
document.getElementById("sunray1").style.backgroundImage = "url(Images/Weather/sun/sunray2.png)";
document.getElementById("arcsun").style.backgroundImage = "url(Images/Weather/sun/sun2.png)";
document.getElementById("arcsunray").style.backgroundImage = "url(Images/Weather/sun/sunray0.png)";
document.getElementById("arcsunray1").style.backgroundImage = "url(Images/Weather/sun/sunray2.png)";
}

/* INITIALIZE TOUCH SCREEN EVENTS */

	var elem = document.getElementById("TouchLayer");
	if (ChangeClick == false) {
		elem.addEventListener("touchend", touchEnd, false);	
		} else {
		elem.addEventListener("click", touchEnd, false);
		}
	
		/* ============== */

switch (Second_Hand_Options) {
	case "big":
		// document.getElementById("smallsechand").style.display = 'none'; /* Remove the "//" at the start of this line to hide the small second hand when "big" secondhand is selected in the Config.js file */
	break;
	case "small":
		document.getElementById("bigsechand").style.display = 'none';
	break;
	case "none":
		document.getElementById("bigsechand").style.display = 'none';
		document.getElementById("smallsechand").style.display = 'none';
	break;
}

if (show_background == true) { document.getElementById("background").src="Images/background/"+iPhoneType+"/background.png"; }
if (showDock == true) { document.getElementById("dock").src="Images/dock/dock.png"; }		
if (Hide_Forecast_Background == true) { document.getElementById("forecastbg").style.display='none'; }
if (Hide_WeatherInfo_Background == true) { document.getElementById("WeatherInfoBG").style.display='none'; }		
if (Hide_DigitalClock == true) { document.getElementById("Digitalclock").style.display='none'; }
if (Hide_All_Weather_Info == true) { document.getElementById("WeatherInfo").style.display='none'; }
if (SecDisplay == false) { document.getElementById("second").style.display='none'; }		
if (Hide_Forecast == true) { document.getElementById("forecastInfo").style.display='none'; }
if (FullScreen_WW == true) { document.getElementById("fullScreenWeatherWalls").style.display='block'; }
if (Hide_AnalogClock == true) {
	document.getElementById("analogclock").style.display='none';
	document.getElementById("calendar").style.display='none';
}
				
/* START DEMO MODE */
if (DemoMode == true) { demo(); }

updateClock();
if (Second_Hand_Sweep == true ) { setInterval(updateClock, 100); }
else { setInterval(updateClock, 1000); }
}

function demo() {
		DemoOn = true;
		document.getElementById("desc").innerHTML = "DEMO MODE";
		document.getElementById("lastupdate").innerHTML = "Last Update: 12:12pm";	
		document.getElementById("wind").innerHTML = "Wind condition here";
		document.getElementById("visibility").innerHTML = "Visibility: 9.99km";
		document.getElementById("pressure").innerHTML = "Pressure: 1015.92mb";
		document.getElementById("rising").innerHTML = "&larr;&rarr;";
		document.getElementById("temp").innerHTML="27" + "&#176;";
		document.getElementById("low").innerHTML="24" + "&#176;";
		document.getElementById("high").innerHTML="32" + "&#176;";
		document.getElementById("hi").innerHTML="Hi:";
		document.getElementById("lo").innerHTML="Lo:";
		document.getElementById("humidity").innerHTML="Humidity: 80" + "%";
		document.getElementById("coordinates").innerHTML="23.08" + "&#176" + "N" + " " + "113.54" + "&#176" + "E";
		document.getElementById("coordinates").style.color="#d9e0b9";
		document.getElementById("sunrise").innerHTML="5:40 am";
		document.getElementById("sunset").innerHTML="6:20 pm";
		document.getElementById("sunrisetext").innerHTML="Sunrise";
		document.getElementById("sunsettext").innerHTML="Sunset";
		document.getElementById("arcmoon").style.webkitTransform = "rotate(0deg)";
		document.getElementById("arcmoonray").style.webkitTransform = "rotate(0deg)";
		document.getElementById("arcsun").style.webkitTransform = "rotate(0deg)";
		document.getElementById("arcsunray").style.webkitTransform = "rotate(0deg)";
		document.getElementById("arcsunray1").style.left = 160 - 300 + "px";		
		document.getElementById("moon").style.webkitTransform = "translateX(100px)";
		document.getElementById("moonray").style.webkitTransform = "translateX(100px)";
		document.getElementById("sun").style.webkitTransform = "translateX(100px)";
		document.getElementById("sunray").style.webkitTransform = "translateX(100px)";
		document.getElementById("sunray1").style.webkitTransform = "translateX(100px)";
//		document.getElementById("nointernet").style.display='none';

		if (Reverse_Hi_Lo == true) {
			document.getElementById("Day1Icon").src="Icon Sets/HTC/1.png";
			document.getElementById("Day1").innerHTML="Mon";
			document.getElementById("Day1HiLo").innerHTML="65" + "&#176;" + "/" + "-56" + "&#176;";
			document.getElementById("Day2Icon").src="Icon Sets/HTC/28.png";
			document.getElementById("Day2").innerHTML="Tue";
			document.getElementById("Day2HiLo").innerHTML="64" + "&#176;" + "/" + "-55" + "&#176;";
			document.getElementById("Day3Icon").src="Icon Sets/HTC/30.png";
			document.getElementById("Day3").innerHTML="Wed";
			document.getElementById("Day3HiLo").innerHTML="63" + "&#176;" + "/" + "-54" + "&#176;";
			document.getElementById("Day4Icon").src="Icon Sets/HTC/45.png";
			document.getElementById("Day4").innerHTML="Thu";
			document.getElementById("Day4HiLo").innerHTML="62" + "&#176;" + "/" + "-53" + "&#176;";
			document.getElementById("Day5Icon").src="Icon Sets/HTC/45.png";
			document.getElementById("Day5").innerHTML="Fri";
			document.getElementById("Day5HiLo").innerHTML="61" + "&#176;" + "/" + "-52" + "&#176;";			
		} else {
			document.getElementById("Day1Icon").src="Icon Sets/HTC/1.png";
			document.getElementById("Day1").innerHTML="Mon";
			document.getElementById("Day1HiLo").innerHTML="-56" + "&#176;" + "/" + "65" + "&#176;";
			document.getElementById("Day2Icon").src="Icon Sets/HTC/28.png";
			document.getElementById("Day2").innerHTML="Tue";
			document.getElementById("Day2HiLo").innerHTML="-55" + "&#176;" + "/" + "64" + "&#176;";
			document.getElementById("Day3Icon").src="Icon Sets/HTC/30.png";
			document.getElementById("Day3").innerHTML="Wed";
			document.getElementById("Day3HiLo").innerHTML="-54" + "&#176;" + "/" + "63" + "&#176;";
			document.getElementById("Day4Icon").src="Icon Sets/HTC/45.png";
			document.getElementById("Day4").innerHTML="Thu";
			document.getElementById("Day4HiLo").innerHTML="-53" + "&#176;" + "/" + "62" + "&#176;";
			document.getElementById("Day5Icon").src="Icon Sets/HTC/45.png";
			document.getElementById("Day5").innerHTML="Fri";
			document.getElementById("Day5HiLo").innerHTML="-52" + "&#176;" + "/" + "61" + "&#176;";			
		} 
	
		where = WhereTest;
		filename = WeatherTest;
		whereOld = where;
		if ((WindTest >= Strong_Wind) && (filename != "windy")) { Start_wind_effects = true; } else { Start_wind_effects = false; }
		loadjscssfile ("Weather/"+iPhoneType, filename, "css");
		loadjscssfile ("Weather/"+iPhoneType, filename, "js");
		if (Start_wind_effects == true) {
			loadjscssfile ("Weather/"+iPhoneType, wind_effects, "css");
			loadjscssfile ("Weather/"+iPhoneType, wind_effects, "js");
			Show_wind_effects = true;
		}
		if (FullScreen_WW == true) { document.getElementById("fullScreenWeatherWalls").src="Images/fullScreenWeatherWalls/" + where + "_" + filename +".jpg"; }
		if (show_day_night_walls == true) { document.getElementById("DayNightWalls").src="Images/day_night_"+iPhoneType+"/" + where  + ".png"; }	
}

function weatherRefresherTemp(zip) {
	fetchWeatherData(dealWithWeather, zip);
}

function dealWithWeather(obj){
	if (obj.error == false) {
		DemoOn = false;
//		document.getElementById("nointernet").style.display='none';
		direction = parseFloat(obj.winddir);
		document.getElementById("city").className =  TextColor;
		document.getElementById("city").innerHTML = obj.city;
		if (useRealFeel == true) { tempValue = obj.realFeel; } else { tempValue = obj.temp; }
		document.getElementById("temp").innerHTML=tempValue + "&#176;";
		document.getElementById("chill").innerHTML=obj.chill + "&#176;";
		document.getElementById("low").innerHTML=obj.todaylow + "&#176;";
		document.getElementById("high").innerHTML=obj.todayhigh + "&#176;";
		document.getElementById("tiret").innerHTML = "/";
		document.getElementById("visibility").innerHTML=obj.visibility + obj.visibilityunit;
		document.getElementById("tiret").style.color = "#FFFFFF";
		document.getElementById("desc").innerHTML=obj.description;
		document.getElementById("pressure").innerHTML=obj.pressure + obj.pressureunit;
		
		if (obj.rising == 0) document.getElementById('rising').innerHTML= "&larr;&rarr;";
        if (obj.rising == 1) document.getElementById('rising').innerHTML= "&uarr;";
        if (obj.rising == 2) document.getElementById('rising').innerHTML= "&darr;";

		
		if (gps == true) {
		document.getElementById("coordinates").className = "TextColorGrey";
		document.getElementById("coordinates").innerHTML = textLat + " " + textLong;
		} else {
		document.getElementById("coordinates").className = "TextColorGrey";
		document.getElementById("coordinates").innerHTML = "WOEID";
		}

		switch (lang) {
		
		case "cn":
		hi.innerHTML = "最高:";
		lo.innerHTML = "最低:";
		sunrisetext.innerHTML = "日出:";
		sunsettext.innerHTML = "日落:";

			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='阳光明媚'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='蒙蒙细雨'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='大雪纷飞'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='倾盆大雨'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='雨雪霏霏'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='雨雪霏霏'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='天朗气清';	  }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='风和日丽';	       }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='日丽风清';	 }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='云淡风清';	}
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='日暖生烟';        }
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='十面霾伏'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='浮云蔽日';   }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='乌云蔽日';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='云迷雾锁';	    }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='疾风骤雨';    }
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='晴空骤雨';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='电闪雷鸣';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='雷雨交加'; }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='风潇雨晦';	 }
			if (translatedesc=='partly cloudy with thunder showers') { document.getElementById("desc").innerHTML='风雨如晦';	}
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='和风细雨';	    }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='细雨霖铃'; }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='流风回雪';  }
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='云雪成欢';	}
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='晴雪初飞';	}
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='俄而雪骤';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='雨雪霏霏';	  }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='大雪纷飞'; }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='闲云弄雪';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='冰天雪地'; }
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='雨雪霏霏';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='凄风冷雨';      }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='雨雪霏霏';	 }
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='骄阳似火'; }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='天寒地冻'; }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='风和日丽';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='晴空万里'; }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='风清云净';	   }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='云淡风轻'; 	}
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='烟雾缭绕'; }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='雨霁云消';	    }
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='断雨残云';	}
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='雷雨交加';   }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='大雾迷茫';    }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='流风回雪'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='流风回雪'; }	       
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='大雨滂沱';	 }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='和风细雨';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='雨雪霏霏';	  }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='雨雪纷纷';	  }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='电闪雷鸣';	  }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='狂风暴雨';    }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='热带风暴';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='风卷残云';    }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='寒风冷雨';    }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='狂风暴雪'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='天降冰雹'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='飞沙走石';	  }
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='烟雾弥漫';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='风起云涌';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='冰雹带雨';	 }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='霹雳列缺';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='霹雳列缺';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='电闪雷鸣';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='急风骤雨';    }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='骤雪初歇';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='雷雨交加';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='自行判断';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='西门吹雪';	 }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='骤雨初歇'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='雷电交加'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='风卷残云'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='飞沙走砾'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='狂风肆虐'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='尘土飞扬'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='飞沙走石'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='狂风肆虐'; }
			document.getElementById("pressure").innerHTML = "最高: " + obj.pressure + obj.pressureunit;	
			document.getElementById("lastupdate").innerHTML = "上次更新: " + currentTimeString + " " + timeOfDay;
			document.getElementById("visibility").innerHTML = "能见度: " + obj.visibility + obj.visibilityunit;
			document.getElementById("humidity").innerHTML = "湿度: " + obj.humidity + "%";	     
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NO";		
			if (direction < 326.25) obj.winddir = "NO";		
			if (direction < 303.75) obj.winddir = "O-NO";
			if (direction < 281.25) obj.winddir = "O";		
			if (direction < 258.75) obj.winddir = "O-SO";		
			if (direction < 236.25) obj.winddir = "SO";
			if (direction < 213.75) obj.winddir = "S-SO";		
			if (direction < 191.25) obj.winddir = "S";		
			if (direction < 168.75) obj.winddir = "S-SE";
			if (direction < 146.25) obj.winddir = "SE";		
			if (direction < 123.75) obj.winddir = "E-SE";		
			if (direction < 101.25) obj.winddir = "E";		
			if (direction < 78.75) obj.winddir = "E-NE";		
			if (direction < 56.25) obj.winddir = "NE";
			if (direction < 33.75) obj.winddir = "N-NE";		
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "无风";
			if (direction == 0) {
								document.getElementById("wind").innerHTML = "风向: " + obj.winddir;			
								} else {
								document.getElementById("wind").innerHTML = "风向: " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit; }
								
		break;		
		
		case "ru":
		hi.innerHTML = "привет:";
		lo.innerHTML = "вот:";
		sunrisetext.innerHTML = "утро:";
		sunsettext.innerHTML = "закат:";
		
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Солнечно'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Изморось'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Сильный снег'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Сильный дождь'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Дождь со снегом'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Дождь со снегом'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Ясно';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Небольшая облачность';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Переменная облачность';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Прерывистая облачность';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Солнце и туман';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Туман'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Небольшая облачность';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Облачно';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Туман';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Дождь';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Солнце и дождь';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Бури';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Буря';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Облачно дождь с громом';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Солнце дождь с громом';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Небольшой дождь';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Дождь';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Порывы';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Облачно с порывами';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Солнце и порывы';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Снег с порывами';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Дождь со снегом';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Снег';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Облачно со снегом';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Лед';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Дождь со снегом';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Ледяной дождь';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Дождь и снег';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Горячий';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Холодный';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Ветер';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Ясно';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Ясно';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Переменная облачность';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Туман';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Облачно с дождем';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Солнечно с дождем';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Облачно с грозой';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Туман';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Небольшой снег'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Небольшой снег с дождем'; }       
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Ливень';    }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Мелкий дождь';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Дождь и мокрый снег';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Снег и мокрый снег';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Гроза';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Ураган';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Горячая буря';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Торнадо';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Изморозь';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Снежные заряды'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Град'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Пыль';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Туман';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Бурный';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Дождь и град';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Изолированные грозы';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Изолированные грозы с дождем';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Рассеянные грозы';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Рассеянный дождь';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Рассеянный снег с дождем';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Небольшой дождь с грозой';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Недоступно';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Снег/Ветер';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Слабый дождь';	  }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Гром'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Переменная облачность/Ветер'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Песчанная буря'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Всплеск/Ветер'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Песок'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Песочная буря/Ветер'; }
			document.getElementById("lastupdate").innerHTML = "обновлены в: " + currentTimeString + " " + timeOfDay;
			document.getElementById("humidity").innerHTML = "влажность': " + obj.humidity + "%";	
			document.getElementById("visibility").innerHTML = "видимость: " + obj.visibility + obj.visibilityunit;
			document.getElementById("pressure").innerHTML = "давление: " + obj.pressure + obj.pressureunit;	
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NO";		
			if (direction < 326.25) obj.winddir = "NO";		
			if (direction < 303.75) obj.winddir = "O-NO";
			if (direction < 281.25) obj.winddir = "O";		
			if (direction < 258.75) obj.winddir = "O-SO";		
			if (direction < 236.25) obj.winddir = "SO";
			if (direction < 213.75) obj.winddir = "S-SO";		
			if (direction < 191.25) obj.winddir = "S";		
			if (direction < 168.75) obj.winddir = "S-SE";
			if (direction < 146.25) obj.winddir = "SE";		
			if (direction < 123.75) obj.winddir = "E-SE";		
			if (direction < 101.25) obj.winddir = "E";		
			if (direction < 78.75) obj.winddir = "E-NE";		
			if (direction < 56.25) obj.winddir = "NE";
			if (direction < 33.75) obj.winddir = "N-NE";		
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "Нет ветра";
			if (direction == 0) {
					document.getElementById("wind").innerHTML = "ветер : " + obj.winddir;				
					} else {
					document.getElementById("wind").innerHTML = "ветер : " + obj.winddir + " | " + Math.round(obj.windspeed) + " " + obj.windunit;	}
		break;									
		
		case "it":
		hi.innerHTML = "alto:";
		lo.innerHTML = "basso:";
		sunrisetext.innerHTML = "alba:";
		sunsettext.innerHTML = "tramonto:";
		
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleggiato'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Pioggerella'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Forti nevicate'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Forti piogge'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Vevischio'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Misto pioggia e neve'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Sereno';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Molto soleggiato';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parzialmente soleggiato';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuvoloso a tratti';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sole coperto';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Nebbia'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Molto nuvoloso';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuvoloso';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebbia';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Diluvio';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleggiato con pioggia';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Fulmini';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tuoni';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Molto Nuvoloso con pioggia e fulmini';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Possibili Piogge';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Pioggia leggera';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pioggia';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Nevischio';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Nuvoloso con nevischio';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parzialmente soleggiato con neve';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Raffiche di neve';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Precipitazioni nevose';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neve';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Molto nuvoloso con neve';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Ghiaccio';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Nevischio';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Grandine';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pioggia e neve';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Caldo';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Freddo';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Ventoso';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Sereno';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Molto sereno';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Parzialmente nuvoloso';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Velato';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Cielo velato';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Nuvoloso a tratti';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parzialmente nuvoloso con raffiche';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebbiolina';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Neve leggiera'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Poca neve'; }       
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Forti precipitazioni';    }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Freddino';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Misto pioggia e nevischio';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Misto neve e nevischio';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tuoni e fulmini';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Uragano';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tempesta tropicale';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Grandine';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Vento e neve'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Grandine'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvere';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Humeado';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempesa';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='misto neve e grandine';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Fulmini isolati';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Temporali isolati';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tempesta di fulmini';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Tempesta di pioggia';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Neve sparsa';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pioggia leggera con fulmini';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Troppa neve';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Piccole precipitazioni';	  }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tuoni'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Molto nuvoloso con vento'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormenta'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Pioggia e vento'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormenta ventosa'; }
			document.getElementById("lastupdate").innerHTML = "Attuale: " + currentTimeString + " " + timeOfDay;
			document.getElementById("humidity").innerHTML = "Umidita': " + obj.humidity + "%";	
			document.getElementById("visibility").innerHTML = "visibilità: " + obj.visibility + obj.visibilityunit;
			document.getElementById("pressure").innerHTML = "Pressione: " + obj.pressure + obj.pressureunit;	
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NO";		
			if (direction < 326.25) obj.winddir = "NO";		
			if (direction < 303.75) obj.winddir = "O-NO";
			if (direction < 281.25) obj.winddir = "O";		
			if (direction < 258.75) obj.winddir = "O-SO";		
			if (direction < 236.25) obj.winddir = "SO";
			if (direction < 213.75) obj.winddir = "S-SO";		
			if (direction < 191.25) obj.winddir = "S";		
			if (direction < 168.75) obj.winddir = "S-SE";
			if (direction < 146.25) obj.winddir = "SE";		
			if (direction < 123.75) obj.winddir = "E-SE";		
			if (direction < 101.25) obj.winddir = "E";		
			if (direction < 78.75) obj.winddir = "E-NE";		
			if (direction < 56.25) obj.winddir = "NE";
			if (direction < 33.75) obj.winddir = "N-NE";		
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "No hay viento";
			if (direction == 0) {
					document.getElementById("wind").innerHTML = "Vento : " + obj.winddir;				
					} else {
					document.getElementById("wind").innerHTML = "Vento : " + obj.winddir + " | " + Math.round(obj.windspeed) + " " + obj.windunit;	}
		break;
		
		case "fi":
		
		hi.innerHTML = "korkein:";
		lo.innerHTML = "alin:";
		sunrisetext.innerHTML = "aamu:";
		sunsettext.innerHTML = "yö:";
				
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Aurinkoista'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Tihkusadetta'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Rankkaa lumisadetta'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Rankkasade'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='R&auml;nt&auml;&auml;'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Vesisadetta ja r&auml;nt&auml;&auml;'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Selke&auml;&auml;';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Melko selke&auml;&auml;';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Puolipilvist&auml;';	  }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Ajoittaisia pilvi&auml;';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Utuista auringonpaistetta';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Utuista';	}
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Enimm&auml;kseen pilvist&auml;';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Pilvist&auml;';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Sumua';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Sadekuuroja';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Puolipilvist&auml; ja sadekuuroja';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Ukkosmyrskyj&auml;';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Ukkosta';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Ukkoskuuroja';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Ukkoskuuroja';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Tihkusadetta';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Sadetta';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Lumisadetta';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Pilvist&auml; ja lumisadetta';	  }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Aurinkoista ja lumisadetta';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Lumisadetta';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Lumikuuroja';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Lumisadetta';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Melko pilvist&auml; ja lumisadetta';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Rakeita';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='R&auml;nt&auml;&auml;';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='J&auml;&auml;t&auml;v&auml;&auml; sadetta';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Vesi ja lumisadetta';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Hellett&auml;';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='kylm&auml;&auml;';	  }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Tuulista';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Selke&auml;&auml;';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Enimm&auml;kseen selke&auml;&auml;';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Puolipilvist&auml;';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Utuista';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Osittaisia sadekuuroja';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Pilvistä ja sadekuuroja';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Puolipilvist&auml; ja ukkoskuuroja';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Sumuista';    }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Heikkoa lumisadetta'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Heikkoja lumikuuroja'; }	
			if (translatedesc=='light snow shower') { document.getElementById("desc").innerHTML='Heikkoja lumikuuroja'; }
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Sadekuuroja';    }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Osittaista tihkusadetta';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Vesi ja r&auml;nt&auml;sadetta';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Lumi ja r&auml;nt&auml;sadetta';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Rankkoja ukkoskuuroja';    }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Py&ouml;rremyrsky';    }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Trooppinen myrsky';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornaado';    }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='J&auml;&auml;t&auml;v&auml;&auml; tihkusadetta';    }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Lumituisku'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Rakeita'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='P&ouml;lyist&auml;';    }
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Utuista';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Ei tietoja';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Vesisadetta ja raekuuroja';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Paikallisia ukkoskuuroja';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Paikallisia ukkoskuuroja';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Hajanaisia ukkoskuuroja';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Hajanaisia sadekuuroja';    }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Hajanaisia lumikuuroja';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Kevyit&auml; ukkoskuuroja';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Ei tietoja';    }
			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Sadetta l&auml;hell&auml;'; }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Lumipyry&auml;';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Kevyiyt&auml; sadekuuroja'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Ukkosta'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Enimm&auml;kseen tuulista'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Hiekkamyrsky'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Puuskaista tuulta'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Kuivaa tuulta'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTM= 'Tuulista'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='Puuskaista tuulta'; }
			document.getElementById("lastupdate").innerHTML = "päivitetään: " + currentTimeString + " " + timeOfDay;
			document.getElementById("visibility").innerHTML = "näkyvyys: " + obj.visibility + obj.visibilityunit;
			document.getElementById("humidity").innerHTML = "Ilmankosteus " + obj.humidity + "%";	
			document.getElementById("pressure").innerHTML = "Paine: " + obj.pressure + obj.pressureunit;	
			if (direction <= 360) obj.winddir = "Pohj";
			if (direction < 348.75) obj.winddir = "Pohjoinen";		
			if (direction < 326.25) obj.winddir = "Koillinen";		
			if (direction < 303.75) obj.winddir = "It&auml;";
			if (direction < 281.25) obj.winddir = "It&auml;";		
			if (direction < 258.75) obj.winddir = "It&auml;";		
			if (direction < 236.25) obj.winddir = "Kaakko";
			if (direction < 213.75) obj.winddir = "Etel&auml;";		
			if (direction < 191.25) obj.winddir = "Etel&auml;";		
			if (direction < 168.75) obj.winddir = "Etel&auml;";
			if (direction < 146.25) obj.winddir = "Lounas";		
			if (direction < 123.75) obj.winddir = "L&auml;nsi";		
			if (direction < 101.25) obj.winddir = "L&auml;nsi";		
			if (direction < 78.75) obj.winddir = "L&auml;nsi";		
			if (direction < 56.25) obj.winddir = "Luode";
			if (direction < 33.75) obj.winddir = "Pohjoinen";		
			if (direction < 11.25) obj.winddir = "Pohjoinen";
			if (direction == 0) obj.winddir = "ei tuulta; :";
			if (direction == 0) {
								document.getElementById("wind").innerHTML = "Tuuli : " + obj.winddir;				
								} else {

			document.getElementById("wind").innerHTML = "Tuuli : " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit; }
		break;
		
		case "nl":
		
		hi.innerHTML = "hoog:";
		lo.innerHTML = "laag:";
		sunrisetext.innerHTML = "ochtend:";
		sunsettext.innerHTML = "nacht:";		
		
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Lichte Sneeuwval'; }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado!'; }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tropische Storm'; }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Wervelwind'; }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Zware Onweersbuien'; }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Onweersbuien'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Regen en Sneeuw'; }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Regen en Ijzel'; }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Sneeuw en Ijzel'; }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Bevriezende Motregen'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Motregen'; }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Ijzel'; }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Buien'; }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Sneeuwvlagen'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Lichte Sneeuwbuien'; }
			if (translatedesc=='light snow grains') { document.getElementById("desc").innerHTML='Lichte Sneeuwbuien'; }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Sneeuw Drift'; }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Sneeuw'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Hagel'; }
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Ijzel'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Stoffig'; }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Mistig'; }
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Wazig'; }
			if (translatedesc=='smoky') { document.getElementById("desc").innerHTML='Wazig'; }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Stormachtig'; }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Winderig'; }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Koud'; }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Bewolkt'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Algemeen Bewolkt'; }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Gedeeltelijk Bewolkt'; }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Helder'; }
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Zonnig'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Bewolkt Weer'; }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Regen en Hagel'; }
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Heet'; }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Geisoleerde Onweersbuien'; }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Verspreide Onweersbuien'; }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Verspreide Buien'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Zware Sneeuw'; }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Verspreide Sneeuwbuien'; }
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Gedeeltelijk Bewolkt'; }
			if (translatedesc=='thundershowers') { document.getElementById("desc").innerHTML='Onweersbuien'; }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Sneeuwbuien'; }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Geisoleerde Onweersbuien'; }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Lichte Regenbuien'; }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='niet beschikbaar'; }
			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Lokale Regenbuien'; }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Gedeeltelijk Zonnig'; }
			if (translatedesc=='ground fog') { document.getElementById("desc").innerHTML='Grondmist'; }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Lichte Motregen'; }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Lichte Regen'; }
			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Mist'; }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Mist'; }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Regen'; }
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Regenbui'; }
			if (translatedesc=='severe thunderstorm/windy') { document.getElementById("desc").innerHTML='Zware Onweersbui/Winderig'; }
			document.getElementById("lastupdate").innerHTML = "Laatste Update: " + currentTimeString + " " + timeOfDay;
			document.getElementById("humidity").innerHTML = "Vochtigheid: " + obj.humidity + "%";
			document.getElementById("visibility").innerHTML = "zichtbaarheid: " + obj.visibility + obj.visibilityunit;	
			document.getElementById("pressure").innerHTML = "Druk: " + obj.pressure + obj.pressureunit;	
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NW";	
			if (direction < 326.25) obj.winddir = "NW";	
			if (direction < 303.75) obj.winddir = "W-NW";
			if (direction < 281.25) obj.winddir = "W";	
			if (direction < 258.75) obj.winddir = "W-ZW";	
			if (direction < 236.25) obj.winddir = "ZW";
			if (direction < 213.75) obj.winddir = "Z-ZW";	
			if (direction < 191.25) obj.winddir = "Z";	
			if (direction < 168.75) obj.winddir = "Z-SO";
			if (direction < 146.25) obj.winddir = "ZO";	
			if (direction < 123.75) obj.winddir = "O-ZO";	
			if (direction < 101.25) obj.winddir = "O";	
			if (direction < 78.75) obj.winddir = "O-NO";	
			if (direction < 56.25) obj.winddir = "NO";
			if (direction < 33.75) obj.winddir = "N-NO";	
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "Geen wind";
			if (direction == 0) {
								document.getElementById("wind").innerHTML = "Wind : " + obj.winddir;
								} else 	{
								document.getElementById("wind").innerHTML = "Wind : " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit;}
		break;
		case "fr":
		
		hi.innerHTML = "élevé:";
		lo.innerHTML = "faible:";
		sunrisetext.innerHTML = "matinée:";
		sunsettext.innerHTML = "nuit:";		
		
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Ensoleill&eacute;'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruine'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Fortes chutes de neige'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Fortes averses'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Ciel d&eacute;gag&eacute;';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Quelques nuages';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Partiellement nuageux';	  }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Nuages &eacute;parses';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;rement voil&eacute;';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Brume';	}
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nuageux';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Brouillard';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Averses';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Soleil et averses';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Orages';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Orage';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et fortes averses';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Soleil et fortes averses';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re pluie';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Pluie';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Averses de neige';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux avec neige';	  }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Soleil et averses de neige';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Averses de neige';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Averses de neige';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Neige';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et neige';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Glace';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Verglas';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Pluie vergla&ccedil;ante';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Pluie et neige m&eacute;l&eacute;es';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Chaud';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Froid';	  }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vent';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Clair';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Tr&egrave;s clair';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Partiellement nuageux';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Brume';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et averses';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et averses';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Partiellement nuageux et fortes averses';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Brouillard';    }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Flocons de neige'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;res chutes de neige'; }		
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Averses';    }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re bruine';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Pluie et verglas';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Neige et verglas';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Gros orages';    }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Ouragan';    }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Orage tropical';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornade';    }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Buine vergla&ccedil;ante';    }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Rafales de neige'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Gr&ecirc;le'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Poussi&eacute;reux';    }
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Brumeux';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Temp&ecirc;te';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Pluie et Gr&ecirc;le m&eacute;l&eacute;es';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Orages isol&eacute;s';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Averses isol&eacute;s';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Orages &eacute;parses';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Averses &eacute;parses';    }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Chutes de neige &eacute;parses';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Pluie l&eacute;g&egrave;re et &eacute;clairs';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='Non disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Neige poudreuse et vent';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='L&eacute;g&egrave;re averse'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Tonnerre'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Tr&egrave;s nuageux et vent'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Rafales de vent'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Sable'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Temp&ecirc;te de sable et vent'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='Rafales'; }
			document.getElementById("lastupdate").innerHTML = "Mise à jour: " + currentTimeString + " " + timeOfDay;
			document.getElementById("humidity").innerHTML = "Humidité: " + obj.humidity + "%";	
			document.getElementById("visibility").innerHTML = "visibilité: " + obj.visibility + obj.visibilityunit;	
			document.getElementById("pressure").innerHTML = "Pression: " + obj.pressure + obj.pressureunit;	
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NO";		
			if (direction < 326.25) obj.winddir = "NO";		
			if (direction < 303.75) obj.winddir = "O-NO";
			if (direction < 281.25) obj.winddir = "O";		
			if (direction < 258.75) obj.winddir = "O-SO";		
			if (direction < 236.25) obj.winddir = "SO";
			if (direction < 213.75) obj.winddir = "S-SO";		
			if (direction < 191.25) obj.winddir = "S";		
			if (direction < 168.75) obj.winddir = "S-SE";
			if (direction < 146.25) obj.winddir = "SE";		
			if (direction < 123.75) obj.winddir = "E-SE";		
			if (direction < 101.25) obj.winddir = "E";		
			if (direction < 78.75) obj.winddir = "E-NE";		
			if (direction < 56.25) obj.winddir = "NE";
			if (direction < 33.75) obj.winddir = "N-NE";		
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "Pas de vent";
			if (direction == 0) {
								document.getElementById("wind").innerHTML = "Vent : " + obj.winddir;				
								} else {
								document.getElementById("wind").innerHTML = "Vent : " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit; }
		break;
		case "de":
		
		hi.innerHTML = "hoch:";
		lo.innerHTML = "tief:";
		sunrisetext.innerHTML = "Morgen:";
		sunsettext.innerHTML = "Abend:";	
		feelslike.innerHTML = "Gefühlt:";		
		
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Sonnig'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Nieselregen'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Starker Schneefall'; }	
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Starker Regenschauer'; }	
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Regen und Schnee'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Regen und Schnee'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Heiter'; }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Meist Sonnig';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Teilweise Sonnig';	  }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Wechselnd Bew&ouml;lkt';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Dunstiger Sonnenschein;';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Dunstschleier'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Meist Bew&ouml;lkt'; }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Bew&ouml;lkt'; }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Nebel'; }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Schauer'; }
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Sonnig mit Regenschauern';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Bew&ouml;lkt mit Gewitterschauern';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Wechselnd bew&ouml;lkt mit Gewitterschauer';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Leichter Regen'; }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Regen'; }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Windst%F6%DFe';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Bew&ouml;lkt mit Windst%F6%DFe';	  }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Teilweise Sonnig mit Windst%F6%DFe';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Schneegest&ouml;ber'; }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Scheeschauer'; }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Schnee'; }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Bew&ouml;lkt mit Schneeschauern';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Gl%E4tte';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Gefrierender Regen'; }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Schneeregen';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Heiss'; }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Kalt'; }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Windig'; }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Klar'; }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Meist Klar';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Nebelig';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt mit Regen';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Stark Bew&ouml;lkt mit Regen';	  }
			if (translatedesc=='partly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Teilweise Bew&ouml;lkt mit Gewitter';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Nebelig'; }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Leichter Schneefall'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Regenschauer'; }
			if (translatedesc=='light drizzle') { document.getElementById("desc").innerHTML='Leichter Nieselregen'; }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Graupelschauer'; }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Schneeregen'; }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Schwere Gewitter'; }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Wirbelsturm'; }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tropischer Sturm'; }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado!'; }
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Gefrierender Nieselregen'; }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Schneetreiben'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Hagel'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Staubig'; }
			if (translatedesc=='smoky') { document.getElementById("desc").innerHTML='Dunstig'; }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='St&uuml;rmisch'; }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Regen und Hagel'; }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='&Ouml;rtliche Gewitter'; }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Vereinzelte Gewitter'; }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Vereinzelte Schauer'; }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Vereinzelte Schneeschauer'; }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='Vereinzelte Regenschauer mit Gewitter';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='nicht verfuegbar'; }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Heftiges Schneegest%F6ber';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Leichte Regenschauer'; }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Donner'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Stark Bew&ouml;lkt und Windig'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Sandsturm'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='St&uuml;rmisch'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Staubig'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Sandsturm'; }
			if (translatedesc=='squalls') { document.getElementById("desc").innerHTML='Sturmb%F6en'; }
			if (translatedesc=='light snow grains') { document.getElementById("desc").innerHTML='Leichte Schneeschauer'; }
			if (translatedesc=='thundershowers') { document.getElementById("desc").innerHTML='Gewitter'; }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Ouml;rtliche Gewitterschauer'; }
			if (translatedesc=='showers in the vicinity') { document.getElementById("desc").innerHTML='Schauer'; }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Teilweise Sonnig'; }
			if (translatedesc=='ground fog') { document.getElementById("desc").innerHTML='Bodennebel'; }
			if (translatedesc=='mist') { document.getElementById("desc").innerHTML='Nebel'; }
			if (translatedesc=='severe thunderstorm/windy') { document.getElementById("desc").innerHTML='Schwere Gewitter/Windig'; }
			document.getElementById("lastupdate").innerHTML = "Letztes Update: " + currentTimeString + " " + timeOfDay;
			document.getElementById("visibility").innerHTML = "Sichtweite: " + obj.visibility + obj.visibilityunit;
			document.getElementById("humidity").innerHTML = "Luftfeuchte: " + obj.humidity + "%";	
			document.getElementById("pressure").innerHTML = "Luftdruck: " + obj.pressure + obj.pressureunit;		
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NW";	
			if (direction < 326.25) obj.winddir = "NW";	
			if (direction < 303.75) obj.winddir = "W-NW";
			if (direction < 281.25) obj.winddir = "W";	
			if (direction < 258.75) obj.winddir = "W-SW";	
			if (direction < 236.25) obj.winddir = "SW";
			if (direction < 213.75) obj.winddir = "S-SW";	
			if (direction < 191.25) obj.winddir = "S";	
			if (direction < 168.75) obj.winddir = "S-SO";
			if (direction < 146.25) obj.winddir = "SO";	
			if (direction < 123.75) obj.winddir = "O-SO";	
			if (direction < 101.25) obj.winddir = "O";	
			if (direction < 78.75) obj.winddir = "O-NO";	
			if (direction < 56.25) obj.winddir = "NO";
			if (direction < 33.75) obj.winddir = "N-NO";	
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "Kein wind";
			if (direction == 0) {
								document.getElementById("wind").innerHTML = "Wind : " + obj.winddir;
								} else	{
								document.getElementById("wind").innerHTML = "Wind : " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit;}
		break;
		
		case "sp":
		
		hi.innerHTML = "alto:";
		lo.innerHTML = "bajo:";
		sunrisetext.innerHTML = "mañana:";
		sunsettext.innerHTML = "noche:";			
		
			translatedesc=obj.description.toLowerCase();
			if (translatedesc=='sunny') { document.getElementById("desc").innerHTML='Soleado'; }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Llovizna'; }
			if (translatedesc=='heavy snow') { document.getElementById("desc").innerHTML='Nieve fuerte'; }
			if (translatedesc=='heavy rain') { document.getElementById("desc").innerHTML='Luvia fuerte'; }
			if (translatedesc=='rain and snow') { document.getElementById("desc").innerHTML='Lluvia y nieve'; }
			if (translatedesc=='mixed rain and snow') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve'; }
			if (translatedesc=='fair') { document.getElementById("desc").innerHTML='Despejado';    }
			if (translatedesc=='mostly sunny') { document.getElementById("desc").innerHTML='Mayormente soleado';	  }
			if (translatedesc=='partly sunny') { document.getElementById("desc").innerHTML='Parcialmente soleado';   }
			if (translatedesc=='intermittent clouds') { document.getElementById("desc").innerHTML='Intermitente nublado';	 }
			if (translatedesc=='hazy sunshine') { document.getElementById("desc").innerHTML='Sol brumoso';	}
			if (translatedesc=='haze') { document.getElementById("desc").innerHTML='Bruma'; }
			if (translatedesc=='mostly cloudy') { document.getElementById("desc").innerHTML='Mayormente nublado';	 }
			if (translatedesc=='cloudy') { document.getElementById("desc").innerHTML='Nublado';    }
			if (translatedesc=='fog') { document.getElementById("desc").innerHTML='Niebla';	  }
			if (translatedesc=='showers') { document.getElementById("desc").innerHTML='Chubascos';	}
			if (translatedesc=='partly sunny with showers') { document.getElementById("desc").innerHTML='Parcialmente soleado con chubascos';    }
			if (translatedesc=='thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas';    }
			if (translatedesc=='thunderstorm') { document.getElementById("desc").innerHTML='Tormenta electrica';    }
			if (translatedesc=='mostly cloudy with thunder showers') { document.getElementById("desc").innerHTML='Mayormente nublado con tormentas de chubascos';	  }
			if (translatedesc=='partly sunny with thunder showers') { document.getElementById("desc").innerHTML='Parcialmente soleado con tormentas de chubascos';    }
			if (translatedesc=='light rain') { document.getElementById("desc").innerHTML='Lluvia ligera';	  }
			if (translatedesc=='rain') { document.getElementById("desc").innerHTML='Lluvia';    }
			if (translatedesc=='flurries') { document.getElementById("desc").innerHTML='Rafagas';	}
			if (translatedesc=='mostly cloudy with flurries') { document.getElementById("desc").innerHTML='Mayormente nublado con rafagas';   }
			if (translatedesc=='partly sunny with flurries') { document.getElementById("desc").innerHTML='Parcialmente soleado con rafagas';    }
			if (translatedesc=='snow flurries') { document.getElementById("desc").innerHTML='Rafagas de nieve';    }
			if (translatedesc=='snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve';    }
			if (translatedesc=='snow') { document.getElementById("desc").innerHTML='Nieve';    }
			if (translatedesc=='mostly cloudy with snow') { document.getElementById("desc").innerHTML='Mayormente nublado con nieve';    }
			if (translatedesc=='ice') { document.getElementById("desc").innerHTML='Hielo';	}
			if (translatedesc=='sleet') { document.getElementById("desc").innerHTML='Aguanieve';    }
			if (translatedesc=='freezing rain') { document.getElementById("desc").innerHTML='Lluvia bajo cero';	 }
			if (translatedesc=='rain and snow mixed') { document.getElementById("desc").innerHTML='Mezcla de lluvia y nieve';	}
			if (translatedesc=='hot') { document.getElementById("desc").innerHTML='Caluroso';	  }
			if (translatedesc=='cold') { document.getElementById("desc").innerHTML='Frio';   }
			if (translatedesc=='windy') { document.getElementById("desc").innerHTML='Vientoso';    }
			if (translatedesc=='clear') { document.getElementById("desc").innerHTML='Despejado';    }
			if (translatedesc=='mostly clear') { document.getElementById("desc").innerHTML='Mayormente despejado';	}
			if (translatedesc=='partly cloudy') { document.getElementById("desc").innerHTML='Parcialmente despejado';	 }
			if (translatedesc=='hazy') { document.getElementById("desc").innerHTML='Bruma';    }
			if (translatedesc=='partly cloudy with showers') { document.getElementById("desc").innerHTML='Parcialmente nublado con chubascos';	}
			if (translatedesc=='mostly cloudy with showers') { document.getElementById("desc").innerHTML='Mayormente nublado con chubascos';	  }
			if (translatedesc=='party cloudy with thunder showers') { document.getElementById("desc").innerHTML='Parcialmente nublado con tormentas de chubascos';	 }
			if (translatedesc=='foggy') { document.getElementById("desc").innerHTML='Neblina';	 }
			if (translatedesc=='light snow') { document.getElementById("desc").innerHTML='Nieve ligera'; }
			if (translatedesc=='light snow showers') { document.getElementById("desc").innerHTML='Ligeras precipitaciones de nieve'; }       
			if (translatedesc=='rain shower') { document.getElementById("desc").innerHTML='Precipitaciones de lluvia';    }
			if (translatedesc=='drizzle') { document.getElementById("desc").innerHTML='Bruma';    }
			if (translatedesc=='mixed rain and sleet') { document.getElementById("desc").innerHTML='Mezcla de lluvia y aguanieve';    }
			if (translatedesc=='mixed snow and sleet') { document.getElementById("desc").innerHTML='Mezcla de nieve y aguanieve';    }
			if (translatedesc=='severe thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas severas';	 }
			if (translatedesc=='hurricane') { document.getElementById("desc").innerHTML='Huracan';	  }
			if (translatedesc=='tropical storm') { document.getElementById("desc").innerHTML='Tormenta tropical';    }
			if (translatedesc=='tornado') { document.getElementById("desc").innerHTML='Tornado';	}
			if (translatedesc=='freezing drizzle') { document.getElementById("desc").innerHTML='Llovizna helada';	  }
			if (translatedesc=='blowing snow') { document.getElementById("desc").innerHTML='Viento y nieve'; }
			if (translatedesc=='hail') { document.getElementById("desc").innerHTML='Granizo'; }
			if (translatedesc=='dust') { document.getElementById("desc").innerHTML='Polvareda';	}
			if (translatedesc=='somky') { document.getElementById("desc").innerHTML='Humeado';    }
			if (translatedesc=='blustery') { document.getElementById("desc").innerHTML='Tempestuoso';    }
			if (translatedesc=='mixed rain and hail') { document.getElementById("desc").innerHTML='Mezcla de lluvia y granizo';    }
			if (translatedesc=='isolated thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas aisladas';    }
			if (translatedesc=='isolated thundershowers') { document.getElementById("desc").innerHTML='Tormentas aisladas';    }
			if (translatedesc=='scattered thunderstorms') { document.getElementById("desc").innerHTML='Tormentas electricas dispersas';    }
			if (translatedesc=='scattered showers') { document.getElementById("desc").innerHTML='Chubascos dispersos';	 }
			if (translatedesc=='scattered snow showers') { document.getElementById("desc").innerHTML='Precipitaciones de nieve dispersas';    }
			if (translatedesc=='light rain with thunder') { document.getElementById("desc").innerHTML='LLuvia y tormenta ligera';    }
			if (translatedesc=='not available') { document.getElementById("desc").innerHTML='No disponible';    }
			if (translatedesc=='drifting snow/windy') { document.getElementById("desc").innerHTML='Acumulacion de nieve y viento';    }
			if (translatedesc=='light rain shower') { document.getElementById("desc").innerHTML='Precipitaciones de lluvia ligera';	  }
			if (translatedesc=='thunder') { document.getElementById("desc").innerHTML='Truenos'; }
			if (translatedesc=='mostly cloudy/windy') { document.getElementById("desc").innerHTML='Mayormente nublado y ventoso'; }
			if (translatedesc=='sandstorm') { document.getElementById("desc").innerHTML='Tormentas de arena'; }
			if (translatedesc=='squalls/windy') { document.getElementById("desc").innerHTML='Chubascos y viento'; }
			if (translatedesc=='sand') { document.getElementById("desc").innerHTML='Arena'; }
			if (translatedesc=='sandstorm/windy') { document.getElementById("desc").innerHTML='Tormentas de arena y ventoso'; }
			document.getElementById("lastupdate").innerHTML = "Actualizado: " + currentTimeString + " " + timeOfDay;
			document.getElementById("humidity").innerHTML = "Humedad: " + obj.humidity + "%";
			document.getElementById("visibility").innerHTML = "visibilidad: " + obj.visibility + obj.visibilityunit;
			document.getElementById("pressure").innerHTML = "Presión: " + obj.pressure + obj.pressureunit;		
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NO";		
			if (direction < 326.25) obj.winddir = "NO";		
			if (direction < 303.75) obj.winddir = "O-NO";
			if (direction < 281.25) obj.winddir = "O";		
			if (direction < 258.75) obj.winddir = "O-SO";		
			if (direction < 236.25) obj.winddir = "SO";
			if (direction < 213.75) obj.winddir = "S-SO";		
			if (direction < 191.25) obj.winddir = "S";		
			if (direction < 168.75) obj.winddir = "S-SE";
			if (direction < 146.25) obj.winddir = "SE";		
			if (direction < 123.75) obj.winddir = "E-SE";		
			if (direction < 101.25) obj.winddir = "E";		
			if (direction < 78.75) obj.winddir = "E-NE";		
			if (direction < 56.25) obj.winddir = "NE";
			if (direction < 33.75) obj.winddir = "N-NE";		
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "No hay viento";
			if (direction == 0) {
					document.getElementById("wind").innerHTML = "Viento : " + obj.winddir;				
					} else {
					document.getElementById("wind").innerHTML = "Viento : " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit;	}		
		break;
		default: 
		
			hi.innerHTML = "Hi:";
			lo.innerHTML = "Lo:";
			sunrisetext.innerHTML = "Sunrise";
			sunsettext.innerHTML = "Sunset";
			feelslike.innerHTML = "Feels like:";
					
			document.getElementById("desc").innerHTML=obj.description;
			document.getElementById("lastupdate").innerHTML = "Last update: " + currentTimeString + " " + timeOfDay;
			document.getElementById("humidity").innerHTML = "Humidity: " + obj.humidity + "%";
			document.getElementById("visibility").innerHTML = "Visibility: " + obj.visibility + obj.visibilityunit;
			document.getElementById("pressure").innerHTML = "Pressure: " + obj.pressure + obj.pressureunit;
			
			if (direction <= 360) obj.winddir = "N";
			if (direction < 348.75) obj.winddir = "N-NW";		
			if (direction < 326.25) obj.winddir = "NW";		
			if (direction < 303.75) obj.winddir = "W-NW";
			if (direction < 281.25) obj.winddir = "W";		
			if (direction < 258.75) obj.winddir = "W-SW";		
			if (direction < 236.25) obj.winddir = "SW";
			if (direction < 213.75) obj.winddir = "S-SW";		
			if (direction < 191.25) obj.winddir = "S";		
			if (direction < 168.75) obj.winddir = "S-SE";
			if (direction < 146.25) obj.winddir = "SE";		
			if (direction < 123.75) obj.winddir = "E-SE";		
			if (direction < 101.25) obj.winddir = "E";		
			if (direction < 78.75) obj.winddir = "E-NE";		
			if (direction < 56.25) obj.winddir = "NE";
			if (direction < 33.75) obj.winddir = "N-NE";		
			if (direction < 11.25) obj.winddir = "N";
			if (direction == 0) obj.winddir = "No wind";			
			if (direction == 0) {
								document.getElementById("wind").innerHTML = "Wind : " + obj.winddir;				
								} else {
								document.getElementById("wind").innerHTML = "Wind : " + obj.winddir + " - " + Math.round(obj.windspeed) + " " + obj.windunit; }		
		break;
		}

		// ALL WEATHER CONDITIONS
		var Conditions = [
			"thunderstorm",			//0 	tornado
			"thunderstorm",			//1 	tropical storm
			"thunderstorm",			//2 	hurricane
			"thunderstorm",			//3 	severe thunderstorms
			"thunderstorm",			//4 	thunderstorms
			"sleet",					//5 	mixed rain and snow
			"sleet",					//6 	mixed rain and sleet
			"sleet",					//7 	mixed snow and sleet
			"sleet",					//8 	freezing drizzle
			"showers_cloud",		//9 	drizzle
			"sleet",					//10 	freezing rain
			"showers_cloud",		//11 	showers
			"rain",					//12 	showers
			"snow_showers",			//13 	snow flurries
			"snow_showers",			//14 	light snow showers
			"snow",					//15 	blowing snow
			"snow",					//16 	snow
			"hail",					//17 	hail
			"sleet",					//18 	sleet
			"fog",					//19 	dust
			"fog",					//20 	foggy
			"haze",					//21 	haze
			"fog",					//22 	smoky
			"windy",					//23 	blustery
			"windy",					//24 	windy
			"frost",					//25 	cold
			"cloud",					//26 	cloudy
			"mostlycloudy",			//27 	mostly cloudy (night)
			"mostlycloudy",			//28 	mostly cloudy (day)
			"partlycloudy",			//29 	partly cloudy (night)
			"partlycloudy",			//30 	partly cloudy (day)
			"clear",					//31 	clear (night)
			"clear",					//32 	sunny
			"fair",					//33 	fair (night)
			"fair",					//34 	fair (day)
			"sleet",					//35 	mixed rain and hail
			"clear",					//36 	hot
			"thunderstorm",			//37 	isolated thunderstorms
			"thunderstorm",			//38 	scattered thunderstorms
			"thunderstorm",			//39 	scattered thunderstorms
			"showers_cloud",		//40 	scattered showers
			"snow",					//41 	heavy snow
			"snow",					//42 	scattered snow showers
			"heavy_snow",			//43 	heavy snow
			"partlycloudy",			//44 	partly cloudy
			"thunderstorm",			//45 	thundershowers
			"snow_showers",			//46 	snow showers
			"thunderstorm",			//47 	isolated thundershowers
			"blank"];				//3200 	not available
			
		// SUNSET/SUNRISE FORMAT
		sunriseh = obj.sunrise.substring(0,obj.sunrise.indexOf(":",0));
		sunrisem = obj.sunrise.substring(obj.sunrise.indexOf(":",0)+1,obj.sunrise.indexOf(" ",0));
		sunseth = obj.sunset.substring(0,obj.sunset.indexOf(":",0));
		sunsetm = obj.sunset.substring(obj.sunset.indexOf(":",0)+1,obj.sunset.indexOf(" ",0));
		sunriseh = parseInt(sunriseh) + GMT;
		sunseth = parseInt(sunseth) + GMT;
		sunseth = sunseth + 12;
		
		// DAY AND NIGHT DURATION
		dayhour = parseInt(sunriseh) + parseInt(sunrisem)/60;
		nighthour = parseInt(sunseth) + parseInt(sunsetm)/60;
		DurationOfDay = nighthour - dayhour;
		DurationOfNight = 24 - DurationOfDay;
		
		if (ampm == false) {
			var sunriseh = ( sunriseh < 10 ? "0" : "" ) + sunriseh;
			var sunseth = ( sunseth < 10 ? "0" : "" ) + sunseth;
			obj.sunrise = sunriseh + ":" + sunrisem;		
			obj.sunset = sunseth + ":" + sunsetm;
		} else {
			var timeOfSunset = ( sunseth < 12 ) ? "am" : "pm";
			var timeOfSunrise = ( sunriseh < 12 ) ? "am" : "pm";
			sunriseh = ( sunriseh > 12 ) ? sunriseh - 12 : sunriseh;
			sunriseh = ( sunriseh == 0 ) ? 12 : sunriseh;
			sunseth = ( sunseth > 12 ) ? sunseth - 12 : sunseth;
			sunseth = ( sunseth == 0 ) ? 12 : sunseth;
			obj.sunrise = sunriseh + ":" + sunrisem + " " + timeOfSunrise;	
			obj.sunset = sunseth + ":" + sunsetm + " " + timeOfSunset;
		}
		
		if (SunsetSunrise == true)
		{
		document.getElementById("sunrise").innerHTML = obj.sunrise;
		document.getElementById("sunset").innerHTML = obj.sunset;		
		document.getElementById("sunrise").style.display = "block";
		document.getElementById("sunset").style.display = "block";
		}
				
		// POSITION OF SUN/MOON
					
		// CHECK IF PREVIOUS CONDITION WAS HAZE AND LOAD IAN'S SUN IF NECESSARY
		if ((DacalSun == false) && (filename == "haze") && (filename != Conditions[obj.icon])) {
			document.getElementById("sun").style.backgroundImage = "url(Images/Weather/sun/sun.png)";
			document.getElementById("sunray").style.backgroundImage = "url(Images/Weather/sun/sunray.png)";
			document.getElementById("sunray1").style.backgroundImage = "url(Images/Weather/sun/sunray1.png)";
			document.getElementById("arcsun").style.backgroundImage = "url(Images/Weather/sun/sun.png)";
			document.getElementById("arcsunray").style.backgroundImage = "url(Images/Weather/sun/sunray.png)";
			document.getElementById("arcsunray1").style.backgroundImage = "url(Images/Weather/sun/sunray1.png)";
		}

		if (Sun_Moon_from_right_to_left == true) { var reversemove = 1; } else { var reversemove = 0; }
		
		if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) {
				where = "night";
				if (time_to_change_wall < dayhour) { time_to_change_wall = time_to_change_wall +24 };
				pRotate = Math.abs((reversemove-(time_to_change_wall - nighthour)/ DurationOfNight)*70)-35; // ROTATE FROM -35deg to +35deg
				pTranslate = Math.abs((reversemove-(time_to_change_wall - nighthour)/ DurationOfNight)*320);
			} else {
				where = "day";
				pRotate = Math.abs((reversemove-(time_to_change_wall - dayhour)/ DurationOfDay)*70)-35; // ROTATE FROM -35deg to +35deg
				pTranslate = Math.abs((reversemove-(time_to_change_wall - dayhour)/ DurationOfDay)*320);
			}

		if (sun_moon_arc == true) {
				document.getElementById("arcmoon").style.webkitTransform = "rotate("+pRotate+"deg)";
				document.getElementById("arcmoonray").style.webkitTransform = "rotate("+pRotate+"deg)";
				document.getElementById("arcsun").style.webkitTransform = "rotate("+pRotate+"deg)";
				document.getElementById("arcsunray").style.webkitTransform = "rotate("+pRotate+"deg)";
				document.getElementById("arcsunray1").style.left = pTranslate - 300 + "px";
			} else {
				document.getElementById("moon").style.webkitTransform = "translateX("+pTranslate+"px)";
				document.getElementById("moonray").style.webkitTransform = "translateX("+pTranslate+"px)";			
				document.getElementById("sun").style.webkitTransform = "translateX("+pTranslate+"px)";
				document.getElementById("sunray").style.webkitTransform = "translateX("+pTranslate+"px)";
				document.getElementById("sunray1").style.left = pTranslate - 300 + "px";			
		}		

		// END POSITION OF SUN/MOON
		
		if (show_day_night_walls == true) {
			document.getElementById("DayNightWalls").src="Images/day_night_"+iPhoneType+"/"+where+".png";
		}
		
		// LOADING WEATHER CONDITIONS
		
		if ((Math.round(obj.windspeed) >= Strong_Wind) && (Conditions[obj.icon] != "windy")) { Start_wind_effects = true; } else { Start_wind_effects = false; }
		
		if (filename == "") {
					filename = Conditions[obj.icon];
					whereOld = where;
					loadjscssfile ("Weather/"+iPhoneType, filename, "css");
					loadjscssfile ("Weather/"+iPhoneType, filename, "js");
					if (Start_wind_effects == true) {
						loadjscssfile ("Weather/"+iPhoneType, wind_effects, "css");
						loadjscssfile ("Weather/"+iPhoneType, wind_effects, "js");
						Show_wind_effects = true;
					}
		} else {
					if ((Conditions[obj.icon] != filename ) || (where != whereOld) || (Start_wind_effects != Show_wind_effects)) {
						whereOld = where;
						clearInterval(meteorTimer);
						delelement("astronautContainer");
						delelement("fogContainer");
						delelement("starContainer");
						delelement("meteorContainer");
						delelement("frameContainer");
						delelement("cloudContainer");
						delelement("dropContainer");
						delelement("circleContainer");
						delelement("wiperContainer");
						delelement("starsBGContainer");
						delelement("windContainer");
						delelement("big_balloonContainer");
						delelement("small_balloonContainer");
						delelement("birdsContainer");
						if (Show_wind_effects == true) {
							removejscssfile("Weather/"+iPhoneType, wind_effects, "css");
							removejscssfile("Weather/"+iPhoneType, wind_effects, "js");
							Show_wind_effects = false;					
						}						
						replacejscssfile("Weather/"+iPhoneType, filename, Conditions[obj.icon], "css");
						replacejscssfile("Weather/"+iPhoneType, filename, Conditions[obj.icon], "js");
						filename = Conditions[obj.icon];
						if (Start_wind_effects == true) {
							loadjscssfile ("Weather/"+iPhoneType, wind_effects, "css");
							loadjscssfile ("Weather/"+iPhoneType, wind_effects, "js");
							Show_wind_effects = true;
						}
					}
		}

		if (FullScreen_WW === true) { document.getElementById("fullScreenWeatherWalls").src="Images/fullScreenWeatherWalls/" + where + "_" + Conditions[obj.icon] +".jpg"; }	
						
		if (Reverse_Hi_Lo == true) {
		document.getElementById("Day1").innerHTML=ForecastDayNames(obj.Day1).substring(0,3);
		document.getElementById("Day1Icon").src="Icon Sets/"+iconSet+"/"+obj.Day1Code+".png";
		document.getElementById("Day1HiLo").innerHTML=obj.Day1Hi+ "&#176;/ "+obj.Day1Lo+ "&#176;";
		document.getElementById("Day2").innerHTML=ForecastDayNames(obj.Day2).substring(0,3);
		document.getElementById("Day2Icon").src="Icon Sets/"+iconSet+"/"+obj.Day2Code+".png";
		document.getElementById("Day2HiLo").innerHTML=obj.Day2Hi+ "&#176;/ "+obj.Day2Lo+ "&#176;";
		document.getElementById("Day3").innerHTML=ForecastDayNames(obj.Day3).substring(0,3);
		document.getElementById("Day3Icon").src="Icon Sets/"+iconSet+"/"+obj.Day3Code+".png";
		document.getElementById("Day3HiLo").innerHTML=obj.Day3Hi+ "&#176;/ "+obj.Day3Lo+ "&#176;";
		document.getElementById("Day4").innerHTML=ForecastDayNames(obj.Day4).substring(0,3);
		document.getElementById("Day4Icon").src="Icon Sets/"+iconSet+"/"+obj.Day4Code+".png";
		document.getElementById("Day4HiLo").innerHTML=obj.Day4Hi+ "&#176;/ "+obj.Day4Lo+ "&#176;"; 
		document.getElementById("Day5").innerHTML=ForecastDayNames(obj.Day5).substring(0,3);
		document.getElementById("Day5Icon").src="Icon Sets/"+iconSet+"/"+obj.Day5Code+".png";
		document.getElementById("Day5HiLo").innerHTML=obj.Day5Hi+ "&#176;/ "+obj.Day5Lo+ "&#176;";		 
		} else {
		document.getElementById("Day1").innerHTML=ForecastDayNames(obj.Day1).substring(0,3);
		document.getElementById("Day1Icon").src="Icon Sets/"+iconSet+"/"+obj.Day1Code+".png";
		document.getElementById("Day1HiLo").innerHTML=obj.Day1Lo+ "&#176;/ "+obj.Day1Hi+ "&#176;";
		document.getElementById("Day2").innerHTML=ForecastDayNames(obj.Day2).substring(0,3);
		document.getElementById("Day2Icon").src="Icon Sets/"+iconSet+"/"+obj.Day2Code+".png";
		document.getElementById("Day2HiLo").innerHTML=obj.Day2Lo+ "&#176;/ "+obj.Day2Hi+ "&#176;";
		document.getElementById("Day3").innerHTML=ForecastDayNames(obj.Day3).substring(0,3);
		document.getElementById("Day3Icon").src="Icon Sets/"+iconSet+"/"+obj.Day3Code+".png";
		document.getElementById("Day3HiLo").innerHTML=obj.Day3Lo+ "&#176;/ "+obj.Day3Hi+ "&#176;";
		document.getElementById("Day4").innerHTML=ForecastDayNames(obj.Day4).substring(0,3);
		document.getElementById("Day4Icon").src="Icon Sets/"+iconSet+"/"+obj.Day4Code+".png";
		document.getElementById("Day4HiLo").innerHTML=obj.Day4Lo+ "&#176;/ "+obj.Day4Hi+ "&#176;";
		document.getElementById("Day5").innerHTML=ForecastDayNames(obj.Day5).substring(0,3);
		document.getElementById("Day5Icon").src="Icon Sets/"+iconSet+"/"+obj.Day5Code+".png";
		document.getElementById("Day5HiLo").innerHTML=obj.Day5Lo+ "&#176;/ "+obj.Day5Hi+ "&#176;";		  
		}
		
		} else {
		switch (No_Internet_Options) {
	case "Image":
		document.getElementById("nointernet").style.display='block';
		document.getElementById("forecastbg").style.display='none';
		document.getElementById("WeatherInfoBG").style.display='none';
	break;
	case "Demo":
		if (DemoOn == false) { demo(); }
		break;
		}
	}
}

function delelement(elem) {
var element = document.getElementById(elem);
while (element.firstChild) { element.removeChild(element.firstChild); }
}

function loadjscssfile(url, filename, filetype){
if (filetype=="js") {
	var fileref = document.createElement("script");
	fileref.type = "text/javascript";
	fileref.charset = "utf-8";
	fileref.src = "JavaScript/" + url + "/" + filename + ".js";
 }
if (filetype=="css") {
	var fileref = document.createElement("link");
	fileref.rel = "stylesheet";
	fileref.href = "Css/" + url + "/" + filename + ".css";
	fileref.type = "text/css";
	fileref.media = "screen";
 }
document.getElementsByTagName("head")[0].appendChild(fileref);
}

function createjscssfile(url, filename, filetype){
if (filetype=="js") {
	var fileref = document.createElement("script");
	fileref.type = "text/javascript";
	fileref.charset = "utf-8";
	fileref.src = "JavaScript/" + url + "/" + filename + ".js";
 }
if (filetype=="css") {
	var fileref = document.createElement("link");
	fileref.rel = "stylesheet";
	fileref.href = "Css/" + url + "/" + filename + ".css";
	fileref.type = "text/css";
	fileref.media = "screen";
 }
return fileref;
}

function removejscssfile(url, oldfilename, filetype) {
var targetelement = (filetype=="js")? "script" : (filetype=="css")? "link" : "none";
var targetattr = (filetype=="js")? "src" : (filetype=="css")? "href" : "none";
var allsuspects = document.getElementsByTagName(targetelement);
for (var i = allsuspects.length; i>=0; i--) { 
		if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(oldfilename)!=-1) {
			allsuspects[i].parentNode.removeChild(allsuspects[i]);
			}
	}
}

function replacejscssfile(url, oldfilename, newfilename, filetype){
var targetelement = (filetype=="js")? "script" : (filetype=="css")? "link" : "none";
var targetattr = (filetype=="js")? "src" : (filetype=="css")? "href" : "none";
var allsuspects = document.getElementsByTagName(targetelement);
for (var i = allsuspects.length; i>=0; i--) { 
		if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(oldfilename)!=-1) {
			var newelement = createjscssfile(url, newfilename, filetype);
			allsuspects[i].parentNode.replaceChild(newelement, allsuspects[i]);
			}
	}
}

function findChild (element, nodeName) {
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	return null;
}

function convertWoeid () {
var url = "http://weather.yahooapis.com/forecastrss?w="+locale+"&u=f";
$.get(url, function(data) {
zip = $(data).find('guid').text().split('_')[0];
weatherRefresherTemp(zip);
}).fail(function() {
	if (xmldata == false) {
		dealWithWeather({error:true});
	} else {
		document.getElementById("tiret").innerHTML = "Offline";
		document.getElementById("tiret").style.color = "red";
	}
});
}

// Get data with woeid (no GPS)
function fetchWeatherData (callback, zip) {
	var url="http://xml.weather.yahoo.com/forecastrss/"+zip+"&u="+tempUnit+"&d=6.xml";
	var xml_request = new XMLHttpRequest();
	var requestTimer = setTimeout(function() {
	xml_request.abort();
	if (xmldata == false) { callback ({error:true}); } else {
	document.getElementById("tiret").innerHTML = "Offline";
	//document.getElementById("low").innerHTML = "";
	//document.getElementById("high").innerHTML = "";
	document.getElementById("tiret").style.color = "red";	}
    }, 10000);
	xml_request.onload = function(e) {
	clearTimeout(requestTimer);
	xml_loaded(e, xml_request, callback);
	}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url);
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);
	return xml_request;
	}

function xml_loaded (event, request, callback) {
	if 	(request.responseXML) {
		var obj = {error:false};
		xmldata = true;
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		if (gps == false) {
		if (city == "") { obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city"); 
		} else { obj.city = city }
		} else { obj.city = city; }
		obj.humidity = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("humidity");
		obj.windunit = findChild(effectiveRoot, "yweather:units").getAttribute("speed");		
		obj.winddir = findChild(effectiveRoot, "yweather:wind").getAttribute("direction");
		obj.windspeed = findChild(effectiveRoot, "yweather:wind").getAttribute("speed");	
		obj.rising = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("rising");
		obj.visibility = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("visibility");	
		obj.visibilityunit = findChild(effectiveRoot, "yweather:units").getAttribute("distance");
		obj.pressure = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("pressure");
        obj.pressureunit = findChild(effectiveRoot, "yweather:units").getAttribute("pressure");
		obj.sunrise = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunrise");
		obj.sunset = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunset");
		obj.chill = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.icon = conditionTag.getAttribute("code");
		obj.description = conditionTag.getAttribute("text");
		var forecast = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");
		obj.todaylow = forecast.getAttribute("low");
		obj.todayhigh = forecast.getAttribute("high");
		if (obj.description == "Unknown") {
		obj.description = forecast.getAttribute("text");
		obj.icon = forecast.getAttribute("code");
		}
		if (obj.icon == 3200) obj.icon = 48;
		
		obj.Day1 = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("day");
		obj.Day1Hi = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("high");
		obj.Day1Lo = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("low");
		obj.Day1Code = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("code");
		
		obj.Day2 = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("day");
		obj.Day2Hi = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("high");
		obj.Day2Lo = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("low");
		obj.Day2Code = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("code");
		
		obj.Day3 = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("day");
		obj.Day3Hi = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("high");
		obj.Day3Lo = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("low");
		obj.Day3Code = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("code");
		
		obj.Day4 = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("day");
		obj.Day4Hi = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("high");
		obj.Day4Lo = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("low");
		obj.Day4Code = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("code");	
		
		obj.Day5 = request.responseXML.getElementsByTagName("forecast")[5].getAttribute("day");
		obj.Day5Hi = request.responseXML.getElementsByTagName("forecast")[5].getAttribute("high");
		obj.Day5Lo = request.responseXML.getElementsByTagName("forecast")[5].getAttribute("low");
		obj.Day5Code = request.responseXML.getElementsByTagName("forecast")[5].getAttribute("code");				
		
		callback (obj); 
		} else {
		callback ({error:true});
		}
}

function ForecastDayNames(day) {
switch (day) {
    case "Sun": { return days[0]; }
    case "Mon": { return days[1]; }
    case "Tue": { return days[2]; }
    case "Wed": { return days[3]; }
    case "Thu": { return days[4]; }
    case "Fri": { return days[5]; }
    case "Sat": { return days[6]; }
    case "Today": { return "Today"; }
    case "Tonight": { return "Tonight"; }
	}
	}
window.onload=init;