// Dandelion_Effects condition iph5
// UniAW6.2 By Ian Nicoll with credit to Dacal

var NUMBER_OF_SEEDS = 40; // seeds to show on screen
var NUMBER_OF_SEED_IMAGES = 8; // images + 1
var container = document.getElementById("windContainer");

// DANDELION
for (var i = 0; i < NUMBER_OF_SEEDS/2; i++) { container.appendChild(createAseed()); }
container.appendChild(createAdandelion());
for (var i = 0; i < NUMBER_OF_SEEDS/2; i++) { container.appendChild(createAseed()); }
// END DANDELION
function randomInteger(low, high) {
    return low + Math.floor(Math.random() * (high - low));
}

function pixelValue(value) {
    return value + "px";
}

function durationValue(value) {
    return value + "s";
}

function randomFloat(low, high) {
    return low + Math.random() * (high - low);
}

function createAseed() {
    var cloudDiv = document.createElement("div");
    var image = document.createElement("img");
	if (White_Dandelion_Seeds_During_Night == true) {
		image.src = "Images/Weather/dandelion/day/seed" + randomInteger(1, NUMBER_OF_SEED_IMAGES) + ".png";
		} else {
		image.src = "Images/Weather/dandelion/"+where+"/seed" + randomInteger(1, NUMBER_OF_SEED_IMAGES) + ".png";
	}
    var spinAnimationName = (Math.random() < 0.5) ? "clockwiseSpin" : "counterclockwiseSpinAndFlip";
	if (spinAnimationName == "clockwiseSpin") {
		cloudDiv.style.top = pixelValue(randomInteger(288, 388));
		cloudDiv.style.left = pixelValue(randomInteger(-40, 40));
		cloudDiv.style.webkitAnimationName = "fade_seed, float_seed";
		} else {
		cloudDiv.style.top = pixelValue(randomInteger(388, 488));
		cloudDiv.style.left = pixelValue(randomInteger(-200, -100));
		cloudDiv.style.webkitAnimationName = "fade_seed, float_seed2";
	}
    image.style.webkitAnimationName = spinAnimationName;
    var fadeAndfloatDuration = durationValue(randomFloat(8, 15));
    cloudDiv.style.webkitAnimationDuration = fadeAndfloatDuration + ", " + fadeAndfloatDuration;
    image.style.webkitAnimationDuration = fadeAndfloatDuration;
	var delayDuration = durationValue(randomInteger(0, 7));
	cloudDiv.style.webkitAnimationDelay = delayDuration +", " + delayDuration;
    image.style.webkitAnimationDelay = delayDuration;
    cloudDiv.appendChild(image);
    return cloudDiv;
}

function createAdandelion() {
    var image = document.createElement("img");
    image.id = "dandelion";
	if (White_Dandelion_Flowers_During_Night == true) {
		image.src = "Images/Weather/dandelion/day/dandelion.png";
		} else {
		image.src = "Images/Weather/dandelion/"+where+"/dandelion.png";
	}
    return image;
}
