// UniAW6.2 By Ian Nicoll with credit to Dacal

/*  FOR TESTING PURPOSE ONLY - Don't touch for normal use.  */

var DemoMode = false;
var WeatherTest = "clear"; 			// Choose from "WEATHER CONDITIONS FOR DEMO MODE" list below.
var WhereTest = "day";						// Choose "day" or "night".
var WindTest = 0; 							/* Choose a value bigger than Strong_Wind value if you want 
											to test the "wind effect". */
											

/* WEATHER CONDITIONS FOR DEMO MODE:

clear
cloud
fair
fog
frost
hail
haze
heavy_snow
mostlycloudy
partlycloudy
rain
showers_cloud
sleet
snow
snow_showers
thunderstorm
windy

*/	


/* CONFIGURATION
========================================================================== */

var lang = "en";								//Choose from the "LANGUAGES" list below.

/*  LANGUAGES:

(it) for Italian
(fi) for Finland
(nl) for Dutch
(fr) for french
(de) for german
(sp) for spanish
(cn) for Chinese
(ru) for Russian
(en) or for english
*/

var No_Internet_Options = "Demo";			 /* Two choices. "Image" or "Demo".
												Set to "Demo" if you want "Demo Mode" to display when you have no internet.
												set to "Image" if you just want a static image to display when you have no
												internet, (this image can be replaced by any image of your choice, it's in
												"Images/background/iph5 (or iph4)" folder, just be sure your new image
												is a .png file and named "nointernet.png" */

var Show_Birds = false;							/* true or false to show birds1 in certain weather conditions,
												(these birds have 240 frame animation) */

var V_Formation_Birds = false;					/* true or false to show the V. Formation birds in certain
												weather conditions, (these birds have only 2 frame animation) */

var Strong_Wind = 30;	 						/* If your wind speed reaches the figure you set here, flying leaves
												animation will start on every animation excepy "windy" which 
												already has the leaves animation */

var gps = true; 								/* true or false. You NEED to have the "My Location" app installed
												on your phone for GPS localization to work.*/
						    
var UseCityGPS = true; 	 					/* true or false, If your city is innacurate with Yahoo RSS,
												you can try to use the GPS localization (if available). */			

var UseNeighborhood = false; 					/* true or false, If your city is inaccurate with GPS, 
												you can try to use the neighborhood (or state).*/			
						    
var locale = 2165352;							/* Yahoo Weather, (used if gps set to false or 
												myLocation.txt file is not found).*/
						    
var tempUnit = "f";								// "f" for fahrenheit.

var updateInterval = 15;							// in minutes.

var Reverse_Hi_Lo = false;						/* true or false, set to true to display Hi temperatures
												first in the 4 day forecast. */

var GMT = 0;									/*	Adjust the hour of sunset and sunrise only if 
												YahooWeather doesn't report correctly (summer time).*/
									    
var useRealFeel = false;						/* true or false (If you disable the "Feels Like" temp
							 					in the .css file, you can enable this to show the "Feels 
												Like temp as the main display)*/
						    
var ampm = true;								// true or false, true for 12h format (digital clock & Last Update).
						    
var SecDisplay = false;							// true or false, true to display seconds (digital clock only).

var SunsetSunrise = false;						// true or false, true to display sunset and sunrise times.

var iconSet = "stardock";								/* Icons used for forecasts, choose either "HTC",
												"DB", "spils", "stardock", or "semitrans".	*/

var ShowAstronaut = false;						// true or false, true to display astronaut in certain weather conditions.
						    
var ShowWiper = false;							// true or false, true to activate the wiper in wet weather conditions only.

var ShowRainbow = false; 						/* true or false, true to display the rainbow animation in daytime 
												"Showers" weather condition only.*/
						    
var FullScreenFogHaze = true;					/* true or false, set to true to make the fog/haze animations 
												full screen, set to false and they are only in top half of screen.*/
								    
var FullScreenClouds = false;					/* true or false, set to true to make the cloud animations 
												full screen, set to false and they are only in top half of screen.*/	
														    
var Second_Hand_Options = "big";					/* (big) for big secondhand, (small) for small second hand,
												(both) for both second hands, (none) for no second hands. */
								    
var Second_Hand_Sweep = false;					/* Whichever second hand you selected, you can make it "sweep" 
												instead of tick with this option */					    
								    
var Sun_Moon_from_right_to_left = false;		/* true or false. set to true to have the sun/moon 
												animations start from the right side of the screen. */
										    
var ShowBigBalloons = false; 					/* true or false, to show or hide big hot air balloons in
												certain weather conditions. */

var Number_Of_Big_Balloons = 2;					/* set the max number of big balloons to show on screen (no limit) */	

var ShowSmallBalloons = false; 					/* true or false, to show or hide small hot air balloons in
												certain weather conditions. */

var Number_Of_Small_Balloons = 3;				/* set the max number of small balloons to show on screen (no limit) */	

var Cloudy_Balloons = false;						/* true of false, set to true if you want to see balloons included in the
												"Cloudy" condition. NOTE: "ShowBalloon" switch must also be set to "true" */
								
var show_day_night_walls = false;				/* true or false to show day & night wallpapers (in "Images/day_night_iph4"
												folder or "Images/day_night_iph5" folder. (depending on your iphone type)
												You will need to replace the images in these folders with your own ones, these
												two images will automatically change according to your sunrise/sunset times. */

var show_background = false;					/* true or false to show the standard dark wallpaper image (in "Images/Overlay"
												folder). This image is just a background image, it will not change with time
												or weather. */

var showDock = false;							/* true or false to show your dock image if "FullScreen_WW" is set to true, you can
												replace this image with your own dock image in the "Images/dock" folder). */

var sun_moon_arc = true;						/* true = the sun/moon will flow across the screen with a slight arc,
												false = the sun/moon will flow straight across the top of the screen. */
							
var FullScreen_WW = false;						/* true of false, set to true if you want "FullScreen Weather Wallpapers",
												these images are in the "Images/fullScreenWeatherWalls" folder. These images
												are linked to the weather condition for your area and will only change when
												your weather condition changes, or exactly on your sunrise/sunset times  */
								
var Hide_Forecast = false;						// true or false, set to true to hide the 4 day forecast.

var Hide_Forecast_Background = true;			// true or false, set to true to hide the 4 day forecast background.

var Hide_WeatherInfo_Background = true;		// true or false, set to true to hide the background image behind the weather info.

var Hide_AnalogClock = true;					// true or false, set to true to hide the analog clock.

var Hide_DigitalClock = false;					// true or false, set to true to hide the digital clock.

var Hide_All_Weather_Info = false;				// true or false, set to true to hide all the weather info (text) on the screen.

var Hide_AnalogClock_Info = false;				// true or false, set to true to hide the day, month & year on the analog clock (the date stays).

var Show_Single_Line_Date = true;				// true or false, If your'e not using the analog clock, you might want this style date.

var DropRain = false;							// true or false, set to true for clasic raindrops or false for Dacals circular rain drop effect.

var RainDropsAndCircles = false;				// true or false, set to true to have classic raindrops AND Dacal's circular rain drops. 

var Dandelion_Effects = false;					// true or false, set to true for Dacal's dandelion wind effect or false for blowing leaves.

var White_Dandelion_Seeds_During_Night = false; 	// To match with the wallpaper, it's sometimes better.

var White_Dandelion_Flowers_During_Night = false;// To match with the wallpaper, it's sometimes better.

var DacalSun = false;							// true or false, set to true to use Dacal's sun image or false for the UniAW's normal sun.

var ChangeClick = false; 		// True ONLY if you have problem to show forecast when touch the screen
								/*
								Interactive LockScreen Widget are incompatible with LockInfo !
								In some case, forecast don't display even without LockInfo.
								You can try to put the variable below to true, not perfect
								(slower response on animation), but better than nothing !
								*/