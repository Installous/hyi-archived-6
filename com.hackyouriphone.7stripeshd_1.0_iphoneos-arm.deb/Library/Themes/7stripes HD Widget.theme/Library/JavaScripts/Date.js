function calendarDate ( ){

    var this_date_name_array = new Array("00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31")
	var this_weekday_name_array=["sunday","monday","tuesday","wednesday","thursday","friday","saturday"];
	var this_month_name_array=["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"];
	
	var this_date_timestamp = new Date()	  
	var this_weekday = this_date_timestamp.getDay()    
	var this_date = this_date_timestamp.getDate()	 
	var this_month = this_date_timestamp.getMonth()  
	var this_year = this_date_timestamp.getYear()  

	if (this_year < 1000)
		this_year+= 1900;

	if (this_year==101)
		this_year=2001;   
		
	document.getElementById("Weekday").firstChild.nodeValue = this_weekday_name_array[this_weekday] //concat long date string
	document.getElementById("Date").firstChild.nodeValue = this_date_name_array[this_date] //concat long date string
	document.getElementById("Month").firstChild.nodeValue = " " + this_month_name_array[this_month] //concat long date string
	document.getElementById("Year").firstChild.nodeValue = " " + this_year //concat long date string
}