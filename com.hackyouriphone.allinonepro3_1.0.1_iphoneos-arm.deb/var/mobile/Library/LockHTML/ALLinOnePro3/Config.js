var time = "12h"; // Select Time Format"12h" or "24h"Saat Formati Sec 12 veya 24 Saat
var lang = "Auto"; // "Language Automatic Select Your Device Language"Widget Cihazinizin Dilini Varsayilan Olarak Secer.
