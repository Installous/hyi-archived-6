var AnimatedWallpaper = true;
var ShowFireworks = true;
var TextColor = "White";
var ZoomLevel = 100;
var RightSide = false;
var DarkIcon = false;
var CustomText = "Aussie Appz  - My Pixel 3";