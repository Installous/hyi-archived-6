var WidgetColor = "Black";
var DotColor = "DarkRed"
