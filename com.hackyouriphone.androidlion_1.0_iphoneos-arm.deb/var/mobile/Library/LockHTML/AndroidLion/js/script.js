(function () {

    var svg = document.getElementsByTagName("svg")[0]
    var body = document.getElementsByTagName("body")[0]
    var g = svg.querySelector("g")
    const minFactor = svg.clientWidth > svg.clientHeight ? svg.clientHeight : svg.clientWidth
    const WIDTH = minFactor > 1200 ? 65 : minFactor > 950 ? 55 : minFactor > 750 ? 45 : 35
    const COLS = Math.floor(svg.clientWidth / WIDTH)
    const ROWS = Math.floor(svg.clientHeight / WIDTH)
    const TOTAL = (COLS + 1) * (ROWS + 1)
    const CENTERX = Math.floor(COLS / 2)
    const CENTERY = Math.floor(ROWS / 2)

    var themes = {
        "ArkStarmap": {
            key: "ArkStarmap",
            url: "images/wallpaper.jpg",
            base: "rgba(48, 69, 95, 0.45)",
            solid1: "rgba(48, 69, 95, 0.55)",
            solid2: "rgba(48, 69, 95, 0.65)",
            solid3: "rgba(48, 69, 95, 0.75)",
            time1: 100,
            time2: 200,
            time3: 900,
            func: ArkStarmap
        }
    }


    body.onload = () => {
        g.style.fill = ArkStarmap.base
        if (ArkStarmap.className) body.className = ArkStarmap.className
        //body.style.backgroundImage = "url('images/wallpaper.jpg')";
        buildBoxes(ArkStarmap.base, ArkStarmap.gutter)
        ArkStarmap()
    }

    /* PRESETS */
    function ArkStarmap() {

        var arc = themes["ArkStarmap"]
        const BATCHES = 30
        for (var i = 0; i < BATCHES; i++) {
            oneSquare(arc.solid1, arc.time1)
            oneSquare(arc.solid3, arc.time1)
            oneSquare(arc.solid2, arc.time3)
        }
        quadRunner(arc.solid3, arc.time1)
        quadRunner(arc.solid3, arc.time2)
        quadRunner(arc.solid2, arc.time3)

        async function oneSquare(solid, time) {

            let randomPoint = getRandomPoint()
            let target = getTarget(randomPoint.row, randomPoint.col)
            target.setAttribute("fill", solid)
            await delay(time)
            target.setAttribute("fill", arc.base)
            oneSquare(solid, time)
        }
        async function quadRunner(color, time) {

            let randomPoint = getRandomPoint()
            let row = randomPoint.row
            let col = randomPoint.col
            let t1 = getTarget(row, col)
            let t2 = getTarget(row, col + 1)
            let t3 = getTarget(row + 1, col)
            let t4 = getTarget(row + 1, col + 1)
            t1 && t1.setAttribute("fill", color)
            t2 && t2.setAttribute("fill", color)
            t3 && t3.setAttribute("fill", color)
            t4 && t4.setAttribute("fill", color)
            await delay(time)
            t1 && t1.setAttribute("fill", arc.base)
            t2 && t2.setAttribute("fill", arc.base)
            t3 && t3.setAttribute("fill", arc.base)
            t4 && t4.setAttribute("fill", arc.base)
            quadRunner(color, time)
        }
    }


    /* helpers */
    function buildBoxes(color, gutter) {
        gutter = gutter === undefined ? 1 : gutter
        for (var col = 0; col <= COLS; col++) {
            for (var row = 0; row <= ROWS; row++) {
                let x = WIDTH * col
                let y = WIDTH * row
                drawSquare(row, col, x, y, WIDTH - gutter, WIDTH - gutter, color)
            }
        }
    }

    function Point(row, col, type) {
        this.col = parseInt(col)
        this.row = parseInt(row)
        this.type = type
    }


    function getRandomPoint() {
        let row = Math.floor(Math.random() * (ROWS + 1))
        let col = Math.floor(Math.random() * (COLS + 1))
        return new Point(row, col)
    }

      function getTarget(row, col) {
        return document.querySelector(`rect[col='${col}'][row='${row}']`)
    }

    function delay(ms) {
        return new Promise(done => setTimeout(() => {
            done()
        }, ms))
    }

    function drawSquare(row, col, x, y, w, h, color) {
        const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect")
        rect.setAttribute("x", x)
        rect.setAttribute("y", y)
        rect.setAttribute("row", row)
        rect.setAttribute("col", col)
        rect.setAttribute("width", w)
        rect.setAttribute("height", h)
        g.appendChild(rect)

    }
})("Visit me at sweaverD.com!")
