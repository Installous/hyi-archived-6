This widget Originally from ASUS weather,just modded by me,all credits goes to the creator of this weather,.thanks and i hope you enjoy my themes.


