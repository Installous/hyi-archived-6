/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "0.1.7",
   minimumCompatibleVersion: "0.1.7",
   build: "0.11.0.164",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'_5',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"5.png",'0px','0px']
         },
         {
            id:'_1',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"1.png",'0px','0px']
         },
         {
            id:'_2',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"2.png",'0px','0px']
         },
         {
            id:'_3',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            opacity:0,
            fill:["rgba(0,0,0,0)",im+"3.png",'0px','0px']
         },
         {
            id:'_4',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"4.png",'0px','0px']
         },
         {
            id:'Left_BK_Glass',
            type:'image',
            rect:['0px','277px','320px','480px','auto','auto'],
            opacity:0.80179146651564,
            fill:["rgba(0,0,0,0)",im+"Left%20BK%20Glass.png",'0px','0px']
         },
         {
            id:'Middle_BK_Glass',
            type:'image',
            rect:['0px','277px','320px','480px','auto','auto'],
            opacity:0.80458647423777,
            fill:["rgba(0,0,0,0)",im+"Middle%20BK%20Glass.png",'0px','0px']
         },
         {
            id:'Right_BK_Glass',
            type:'image',
            rect:['0px','277px','320px','480px','auto','auto'],
            opacity:0.80081494512229,
            fill:["rgba(0,0,0,0)",im+"Right%20BK%20Glass.png",'0px','0px']
         },
         {
            id:'Right_BK_Glass_2',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Right%20BK%20Glass%202.png",'0px','0px']
         },
         {
            id:'Middle_BK_Glass_2',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Middle%20BK%20Glass%202.png",'0px','0px']
         },
         {
            id:'Left_BK_Glass_2',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"Left%20BK%20Glass%202.png",'0px','0px']
         },
         {
            id:'BG',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"BG.png",'0px','0px']
         },
         {
            id:'S',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"S.png",'0px','0px']
         },
         {
            id:'O',
            type:'image',
            rect:['0px','0px','320px','480px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"O.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Middle_BK_Glass}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.80458647423777'],
            ["style", "left", '0px']
         ],
         "${__2}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px']
         ],
         "${__5}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px']
         ],
         "${_BG}": [
            ["style", "top", '0px'],
            ["style", "left", '0px']
         ],
         "${_Right_BK_Glass_2}": [
            ["style", "top", '277px'],
            ["style", "opacity", '0.80236395474138'],
            ["style", "left", '0px']
         ],
         "${_S}": [
            ["style", "left", '175.59px'],
            ["style", "top", '0px']
         ],
         "${_O}": [
            ["style", "left", '188.34px'],
            ["style", "top", '0px']
         ],
         "${_Left_BK_Glass}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.80179146651564'],
            ["style", "left", '0px']
         ],
         "${__4}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px']
         ],
         "${__3}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px']
         ],
         "${_Right_BK_Glass}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0.80081494512229'],
            ["style", "left", '0px']
         ],
         "${__1}": [
            ["style", "top", '0px'],
            ["style", "opacity", '0'],
            ["style", "left", '0px']
         ],
         "${_Middle_BK_Glass_2}": [
            ["style", "top", '277px'],
            ["style", "opacity", '0.79694234913793'],
            ["style", "left", '0px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "height", '480px'],
            ["style", "width", '320px']
         ],
         "${_Left_BK_Glass_2}": [
            ["style", "top", '277px'],
            ["style", "opacity", '0.80074757543103'],
            ["style", "left", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 60750,
         autoPlay: true,
         timeline: [
            { id: "eid64", tween: [ "style", "${_Left_BK_Glass_2}", "opacity", '0.80074757543103', { fromValue: '0.80074757543103'}], position: 14750, duration: 0 },
            { id: "eid115", tween: [ "style", "${_Left_BK_Glass_2}", "opacity", '0.80074757543103', { fromValue: '0.80074757543103'}], position: 22500, duration: 0 },
            { id: "eid62", tween: [ "style", "${_Right_BK_Glass_2}", "opacity", '0.80236395474138', { fromValue: '0.80236395474138'}], position: 14750, duration: 0 },
            { id: "eid153", tween: [ "style", "${__4}", "opacity", '1', { fromValue: '0'}], position: 49250, duration: 1000 },
            { id: "eid128", tween: [ "style", "${__2}", "opacity", '1', { fromValue: '0'}], position: 25750, duration: 1000 },
            { id: "eid63", tween: [ "style", "${_Middle_BK_Glass_2}", "opacity", '0.79694234913793', { fromValue: '0.79694234913793'}], position: 14750, duration: 0 },
            { id: "eid8", tween: [ "style", "${_Middle_BK_Glass}", "top", '277px', { fromValue: '0px'}], position: 4000, duration: 2000 },
            { id: "eid14", tween: [ "style", "${_Left_BK_Glass}", "left", '0px', { fromValue: '0px'}], position: 8000, duration: 2000 },
            { id: "eid160", tween: [ "style", "${__5}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 1000 },
            { id: "eid18", tween: [ "style", "${_Right_BK_Glass}", "left", '0px', { fromValue: '0px'}], position: 8000, duration: 2000 },
            { id: "eid12", tween: [ "style", "${_Left_BK_Glass}", "top", '277px', { fromValue: '0px'}], position: 8000, duration: 2000 },
            { id: "eid146", tween: [ "style", "${__3}", "opacity", '1', { fromValue: '0'}], position: 37250, duration: 1000 },
            { id: "eid61", tween: [ "style", "${_Right_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 12000, duration: 1750 },
            { id: "eid118", tween: [ "style", "${_Right_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 19750, duration: 2000 },
            { id: "eid125", tween: [ "style", "${_Right_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 23750, duration: 1750 },
            { id: "eid142", tween: [ "style", "${_Right_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 31500, duration: 2000 },
            { id: "eid145", tween: [ "style", "${_Right_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 35500, duration: 1750 },
            { id: "eid149", tween: [ "style", "${_Right_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 43250, duration: 2000 },
            { id: "eid152", tween: [ "style", "${_Right_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 47250, duration: 1750 },
            { id: "eid156", tween: [ "style", "${_Right_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 55000, duration: 2000 },
            { id: "eid159", tween: [ "style", "${_Right_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 59000, duration: 1750 },
            { id: "eid6", tween: [ "style", "${_S}", "left", '0px', { fromValue: '175.59px'}], position: 2750, duration: 1250, easing: "easeOutBounce" },
            { id: "eid10", tween: [ "style", "${_Middle_BK_Glass}", "left", '0px', { fromValue: '0px'}], position: 4000, duration: 2000 },
            { id: "eid16", tween: [ "style", "${_Right_BK_Glass}", "top", '277px', { fromValue: '0px'}], position: 8000, duration: 2000 },
            { id: "eid59", tween: [ "style", "${_Middle_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 12000, duration: 1750 },
            { id: "eid103", tween: [ "style", "${_Middle_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 15750, duration: 2063 },
            { id: "eid123", tween: [ "style", "${_Middle_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 23750, duration: 1750 },
            { id: "eid129", tween: [ "style", "${_Middle_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 27500, duration: 2000 },
            { id: "eid144", tween: [ "style", "${_Middle_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 35500, duration: 1750 },
            { id: "eid147", tween: [ "style", "${_Middle_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 39250, duration: 2000 },
            { id: "eid151", tween: [ "style", "${_Middle_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 47250, duration: 1750 },
            { id: "eid154", tween: [ "style", "${_Middle_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 51000, duration: 2000 },
            { id: "eid158", tween: [ "style", "${_Middle_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 59000, duration: 1750 },
            { id: "eid66", tween: [ "style", "${__1}", "opacity", '1', { fromValue: '0'}], position: 14000, duration: 1000 },
            { id: "eid57", tween: [ "style", "${_Left_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 12000, duration: 1750 },
            { id: "eid116", tween: [ "style", "${_Left_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 19750, duration: 2000 },
            { id: "eid121", tween: [ "style", "${_Left_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 23750, duration: 1750 },
            { id: "eid135", tween: [ "style", "${_Left_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 31500, duration: 2000 },
            { id: "eid143", tween: [ "style", "${_Left_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 35500, duration: 1750 },
            { id: "eid148", tween: [ "style", "${_Left_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 43250, duration: 2000 },
            { id: "eid150", tween: [ "style", "${_Left_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 47250, duration: 1750 },
            { id: "eid155", tween: [ "style", "${_Left_BK_Glass_2}", "top", '277px', { fromValue: '0px'}], position: 55000, duration: 2000 },
            { id: "eid157", tween: [ "style", "${_Left_BK_Glass_2}", "top", '0px', { fromValue: '277px'}], position: 59000, duration: 1750 },
            { id: "eid4", tween: [ "style", "${_O}", "left", '0px', { fromValue: '188.34px'}], position: 750, duration: 1250 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-2774320");
