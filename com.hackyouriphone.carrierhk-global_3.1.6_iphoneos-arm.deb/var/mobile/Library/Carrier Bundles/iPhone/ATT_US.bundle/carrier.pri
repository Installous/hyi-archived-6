<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Carrier Configuration Management</key>
	<dict>
		<key>CDMA 1X Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>Call Manager Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>Data Service Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>EVDO Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>OMA Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>System Determination Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>UIM Service Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>Wireless Messaging Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
	</dict>
	<key>Data Parameters</key>
	<dict>
		<key>Enable IPv6</key>
		<false/>
	</dict>
	<key>Feature Settings</key>
	<dict>
		<key>Preferred Mode</key>
		<string>GWL</string>
		<key>Rat Acq Order</key>
		<string>LWG</string>
	</dict>
	<key>GERAN</key>
	<dict>
		<key>A5 Algorithm Supported</key>
		<string>A5_3</string>
		<key>GEA Algorithm Supported</key>
		<string>GEA_3</string>
	</dict>
	<key>IMS</key>
	<dict>
		<key>SMS MO On Traffic Channel</key>
		<true/>
		<key>VOIP Preferred URI</key>
		<string>1</string>
		<key>VOIP Registration Mode</key>
		<string>0</string>
	</dict>
	<key>JCDMA</key>
	<dict>
		<key>Enable JCDMA</key>
		<false/>
	</dict>
	<key>LTE</key>
	<dict>
		<key>LTE CA Disable</key>
		<string>0</string>
		<key>Additional qos support</key>
		<string>1</string>
		<key>CSFB Fast Return</key>
		<true/>
		<key>Fplmn Backoff Time</key>
		<integer>0</integer>
		<key>ISR Enable</key>
		<false/>
		<key>LTE fast dormancy</key>
		<true/>
		<key>Prioritize LTE Mode</key>
		<string>1</string>
		<key>Voice Domain Preference</key>
		<string>CS Voice Only</string>
		<key>WTOL PS HO Support</key>
		<true/>
	</dict>
	<key>Maverick</key>
	<dict>
		<key>Carrier ID</key>
		<string></string>
		<key>PRI Revision</key>
		<string>0.1.180</string>
	</dict>
	<key>Roaming Broker</key>
	<dict>
		<key>IMSI Switch</key>
		<true/>
	</dict>
	<key>SRLTE</key>
	<dict>
		<key>TRM RF Configuration</key>
		<string>2</string>
		<key>TRM RF Mask</key>
		<string>2</string>
	</dict>
	<key>WCDMA</key>
	<dict>
		<key>ANITE GCF</key>
		<false/>
		<key>BCM Support</key>
		<false/>
		<key>Band Class Pref b16-b31</key>
		<string>49151</string>
		<key>Delay Rau During CSFB</key>
		<false/>
		<key>Enable ENS</key>
		<true/>
		<key>HSDPA Category</key>
		<string>24</string>
		<key>HSUPA Category</key>
		<string>6</string>
		<key>Ignore UPLMN</key>
		<false/>
		<key>Managed Roaming</key>
		<false/>
		<key>UMTS AMR Codec Preference</key>
		<string>13</string>
		<key>UMTS FEATURE CONTROL</key>
		<string>0</string>
		<key>UMTS RRC RELEASE VERSION</key>
		<string>4</string>
	</dict>
</dict>
</plist>
