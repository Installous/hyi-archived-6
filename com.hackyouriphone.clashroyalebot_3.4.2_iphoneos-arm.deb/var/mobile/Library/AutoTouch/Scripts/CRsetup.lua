-- CLASH ROYALE BOT iOS created by Harky (Reddit user  u/clashroyale-bot)

-- Support @ Subreddit: r/clashroyale-bot

-- Please do not share passwords OR this file.  If i find out you have done so you will not receive anymore updates.  So much time and effort has gone into creating this bot!

-- In this file you can change the defualt values of the features.  Doing this means you won't have to configure the bot on each startup. Keep any quotes "". Incorrectly editing this file will result in errors. Please follow instructions.....





--###################################

-- ***APPEARANCE/SOUND***


--Change to 1 to stop menu appearing on first run

Hide_Dialog_Menu = 0;


--Activation Sound 0 to disable

Play_Sound = 0;








--###################################

-- ***CHESTS***


-- Change 0 to 1 if you want to enable the following features

Open_Free_Chest.value = 0;


Open_Crown_Chest.value = 0;


Open_Chests.value = 0;


Unlock_Chests.value = 0;








--###################################

--***TAUNTING***

Taunt_At_End_Of_Battle.value = 0;








--###################################

--***THE FOLLOWING FEATURES ARE PRO USERS ONLY***--
---DONT EDIT PRO---
if PRO == 1 then


-- ***CLAN***


-- Change 0 to 1 if you want to enable the following features

Open_Clan_Chest.value = 0;


Request_Random_Card.value = 0;


Auto_Request_Card.value = 0;


Donate_Cards.value = 0;



-- Working from left to right on the request screen which card to request (1-72) Change "Select" to the card number you would like the bot to request. The epic request will take priority on Sunday or when epic request is available, for example inputing both values the bot will request an epic card. If epic card is not available the bot will request your non epic input.

-- The counting method is the same for epic cards, the bot will scroll to the begining of the card request screen. Card 1 is still card 1.


Card_To_Request.value = "Select";


Epic_Card_To_Request.value = "Select";








--###################################

-- ***BATTLE DECK***

-- Change "Current" to "1" "2" or "3" for the deck you would like to use for battle. Leaving as "Current" will use the current deck CR was left on.

Deck_For_Battles.value = "Current";









--###################################

-- ***BATTLE SETUP***


-- Change 0 to 1 if you want to enable the following features

Ignore_Reward_Limit.value = 0;


Ignore_Battle.value = 0;


Deploy_Cards_All_Over.value = 0;


Recorded_Attack.value = 0;



-- "Slow" "Normal" or "Fast" for the speed of card deployment

Battle_Speed.value = "Normal";







--###################################

-- ***TROPHYS***


-- Change 0 to 1 if you want to enable the following feature

Trophy_Drop_Lose_Battles.value = 0;



-- Number of battles to lose

How_Many_Battles_To_Lose.value = "0";







--###################################

-- ***TIME DELAY***


-- Change 0 to 1 if you want to enable the following feature

Enable_Time_Delay.value = 0;



--Change 0 to how many minutes (Time Delay Has to be enabled)

Run_Every_Minutes.value = "0";



--Your "passcode" keep the quotes

Passcode_Unlock.value = "passcode"








--###################################

-- ***RECONNECT DELAY***

--Connect from other device allow bot to reconnect after amount of Minutes. 1 is 1 minute

Reconnect_Delay.value = "1";







--###################################

-- ***CHEST PRIORITY*** 

-- Changing value to 1 will activate this feature. Chest priority allows you to set the order of unlocking chests, at the moment low to high will unlock in this order: silver - gold - then rare chests. Rare chests have no order as of yet. High to low is just as it sounds. Only activate 1 at a time.


Unlock_Chest_Priority_Low_High.value = 0;

Unlock_Chest_Priority_High_Low.value = 0;








--###################################

-- ***REMOTE LOG***

--To enable this feature change Email_Log to 1.  Put your email address between the quotes.  Spicify how often you would like the bot to send the log.


Email_Log.value = 0;

Email_Address.value = "YourEmail@Somthing.com";

Send_Every.value = "60";
  
  
  

  
  
  
--###################################

-- ***ATTACK-PRO***
  
--To use Attack Pro change 0 to 1 and configure from below. To enable cards you want to use during the battle change 0 to 1 this will then use that card. (you will still need to choose your own deck in CR)

Attack_Pro.value = 0;


--------MOVING CARDS--------

Archers = 0;
Baby_Dragon = 0;
Barbarians = 0;
Battle_Ram = 0;
Bomber = 0;
Bowler = 0;
Balloon = 0;
Dark_Prince = 0;
Dart_Goblin = 0;
Electro_Wizard = 0;  -- Coming Soon
Elite_Barbarians = 0;
Executioner = 0;
Fire_Spirits = 0;
Giant = 0;
Giant_Skeleton = 0;
Goblins = 0;
Goblin_Gang = 0;
Golem = 0;
Guards = 0;
Hog_Rider = 0;
Ice_Spirit = 0;
Ice_Wizard = 0; -- Coming Soon
Ice_Golem = 0;
Inferno_Dragon = 0; -- Coming Soon
Knight = 0;
Lava_Hound = 0;
Lumberjack = 0; -- Coming Soon
Mega_Minion = 0;
Miner = 0; -- Coming Soon
Mini_Pekka = 0;
Minions = 0;
Minion_Horde = 0;
Musketeer = 0;
Pekka = 0;
Prince = 0;
Princess = 0;
Royal_Giant = 0;
Skeleton_Army = 0;
Skeletons = 0;
Sparky = 0; -- Coming Soon
Spear_Goblin = 0;
Three_Musketeers = 0;
Valkyrie = 0;
Witch = 0;
Wizard = 0;

--------BUILDINGS--------

Barbarian_Hut = 0;
Bomber_Tower = 0;
Cannon = 0;
Elixir_Collector = 0;
Furnace = 0;
Goblin_Hut = 0;
Inferno_Tower = 0;
Mortar = 0;
Tombstone = 0;
Tesla = 0;
X_Bow = 0;




-- To configure this part you will need to look at the image in the list of scripts CR_Deployment.bmp to see where you want the above selected cards to be deployed. For your convenience a default location has been chosen to get you started.
  
---------MOVING CARD AREA------------
  
Archer_Area = 4;
Baby_Dragon_Area = 7;
Barbarians_Area = 6;
Battle_Ram_Area = 11;
Bomber_Area = 4;
Bowler_Area = 6;
Balloon_Area = 11;
Dark_Prince_Area = 6;
Dart_Goblin_Area = 5;
Electro_Wizard_Area = 7;  -- Coming Soon
Elite_Barbarians_Area = 11;
Executioner_Area = 4;
Fire_Spirits_Area = 7;
Giant_Area = 6;
Giant_Skeleton_Area = 11;
Goblins_Area = 1;
Goblin_Gang_Area = 11;
Golem_Area = 1;
Guards_Area = 6;
Hog_Rider_Area = 11;
Ice_Spirit_Area = 8;
Ice_Wizard_Area = 4; -- Coming Soon
Ice_Golem_Area = 7;
Inferno_Dragon_Area = 7; -- Coming Soon
Knight_Area = 11;
Lava_Hound_Area = 2;
Lumberjack_Area = 11; -- Coming Soon
Mega_Minion_Area = 2;
Miner_Area = 14; -- Coming Soon
Mini_Pekka_Area = 11;
Minions_Area = 1;
Minion_Horde_Area = 11;
Musketeer_Area = 7;
Pekka_Area = 11;
Prince_Area = 11;
Princess_Area = 4;
Royal_Giant_Area = 11;
Skeleton_Army_Area = 11;
Skeletons_Area = 8;
Sparky_Area = 2; -- Coming Soon
Spear_Goblin_Area = 11;
Three_Musketeers_Area = 11;
Valkyrie_Area = 4;
Witch_Area = 1;
Wizard_Area = 4;
  

--------BUILDINGS AREA--------
  
Barbarian_Hut_Area = 5;
Bomber_Tower_Area = 5;
Cannon_Area = 5;
Elixir_Collector_Area = 1;
Furnace_Area = 2;
Goblin_Hut_Area = 3;
Inferno_Tower_Area = 5;
Mortar_Area = 8;
Tombstone_Area = 2;
Tesla_Area = 5;
X_Bow_Area = 8;







--HAPPY BOTTING !

----------------
end




