
var TwentyFourHourClock = "false"; //Set to true for 24hr false to 12hr.
var refresh = 30 * 60 * 10000; //refresh in milliseconds (default: 1500 sec.)

function getTodayDate( )
{

var d=new Date();
var weekday=new Array(7);
weekday[0]="Sunday";
weekday[1]="Monday";
weekday[2]="Tuesday";
weekday[3]="Wednesday";
weekday[4]="Thursday";
weekday[5]="Friday";
weekday[6]="Saturday";

var n = weekday[d.getDay()];



var months = new Array(12);
months[0] = "January";
months[1] = "February";
months[2] = "March";
months[3] = "April";
months[4] = "May";
months[5] = "June";
months[6] = "July";
months[7] = "August";
months[8] = "September";
months[9] = "October";
months[10] = "November";
months[11] = "December";

var current_date = new Date();
month_value = current_date.getMonth();
day_value = current_date.getDate();
year_value = current_date.getFullYear();
document.getElementById("todayday").innerHTML= n;
document.getElementById("todaymonth").innerHTML= months[month_value];
document.getElementById("todaydate").innerHTML= day_value ;
document.getElementById("todayyear").innerHTML= year_value;

}

function updateClock ( )
{
  var currentTime = new Date ( );
  var currentHours = currentTime.getHours ( );
  var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( );
    currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
    currentHours = ( currentHours == 0 ) ? 12 : currentHours;
    currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
if (TwentyFourHourClock == "true"){
}

else{
 var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM"
currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
currentHours = ( currentHours == 0 ) ? 12 : currentHours;

}
var currentTimeString = currentHours + " " + ":";
var currentTimeString1 = currentMinutes;
document.getElementById("hours").firstChild.nodeValue = currentTimeString;
document.getElementById("mins").firstChild.nodeValue = currentTimeString1;

}

function init2 ( )

{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("ampm").appendChild ( timeDisplay );

}



function amPm ( )

{
var currentTime = new Date ( );
var currentHours = currentTime.getHours ( );
var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
currentHours = ( currentHours == 0 ) ? 12 : currentHours;
var currentTimeString = timeOfDay;
document.getElementById("ampm").firstChild.nodeValue = currentTimeString;
}



