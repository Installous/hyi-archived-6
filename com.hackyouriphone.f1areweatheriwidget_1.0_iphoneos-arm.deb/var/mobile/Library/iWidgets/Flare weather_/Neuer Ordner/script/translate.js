/****************************
*     theme translation     *
*   Version 1.0 01.05.2013  *
*     created by oldster    *
*    http://itheming.de/    *
****************************/
switch (language) {
	case "en": { 
		var this_date_name_array = ["0", "1st", "2nd", "3rd", "4th", "5th", "6th", "7th",
		"8th", "9th", "10th","11th", "12th", "13th", "14th", "15th", "16th", "17th", "18th", "19th",
		"20th","21st", "22nd", "23rd", "24th", "25th", "26th", "27th" ,"28th", "29th" ,"30th", "31st"]
		
		var this_weekday_name_array=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday",
		"Saturday"];
		var this_month_name_array=["January","February","March","April","May","June","July","August",
		"September","October","November","December"];
		
		var windDirection =['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW',
		'W', 'WNW', 'NW', 'NNW', 'N'];
		break;
	 }
	case "ge": {
		var this_date_name_array = ["00","01.","02.","03.","04.","05.","06.","07.","08.",
		"09.","10.","11.","12.","13.","14.","15.","16.","17.","18.","19.","20.","21.","22.","23.",
		"24.","25.","26.","27.","28.","29.","30.","31."]
		
		var this_weekday_name_array=["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag",	
		"Samstag"];
		var this_month_name_array=["Januar","Februar","M\u00E4rz","April","Mai","Juni","Juli","August",
		"September","Oktober","November","Dezember"];
		
	var weatherNow =["Tornado","Tropischer Sturm","Orkan","Heftiges Gewitter","Gewitter",
		"Regen und Schnee","Regen und Eisregen","Schnee und Eisregen","Gefrierender Nieselregen",
		"Nieselregen","Gefrierender Regen","Schauer","Schauer","Schneeschauer","Leichte Schneeschauer",
		"St \u00FCrmiger Schneefall","Schnee","Hagel","Eisregen","Staub","Neblig","Dunst","Staubig","St\u00FCrmisch",
		"Windig","Kalt","Bew\u00F6lkt","Gr\u00F6&#223;tenteils bew\u00F6lkt","Gr\u00F6&#223;tenteils bew\u00F6lkt","Teilweise bew\u00F6lkt",
		"Teilweise bew\u00F6lkt","Klar","Sonnig","Sch\u00F6n","Sch\u00F6n","Regen und Hagel","Hei&szlig;","Einzelne Gewitter",
		"Vereinzelte Gewitter","Vereinzelte Gewitter","Vereinzelte Schauer","Starker Schneefall",
		"Vereinzelte Schneeschauer","Starker Schneefall","Teilweise bew\u00F6lkt","Sp\u00E4ter Schauer",
		"Schneeschauer","Einzelne Gewitterschauer","N/A"];
		
		var windDirection =['N', 'NNO', 'NO', 'ONO', 'O', 'OSO', 'SO', 'SSO', 'S', 'SSW', 'SW', 'WSW',
		'W', 'WNW', 'NW', 'NNW', 'N'];
		break;	
	}
	case "fr": {
		var this_date_name_array = ["00","01.","02.","03.","04.","05.","06.","07.","08.",
		"09.","10.","11.","12.","13.","14.","15.","16.","17.","18.","19.","20.","21.","22.","23.",
		"24.","25.","26.","27.","28.","29.","30.","31."]
		
		var this_weekday_name_array=["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi",	
		"Samedi"];
		var this_month_name_array=["Janvier","F&#233;vrier","Mars","Avril","Mai","Juin","Juillet","Ao�t",
		"Septembre","Octobre","Novembre","D&#233;cembre"];
				
		var weatherNow =["Tornade","Orage Tropical","Ouragan","Orages","Orages","Pluie et Neige",
		"Pluie et Verglas","Neige et Verglas","Brouillard Verglassant","Pluie","Pluie Verglassante",
		"Averses","Averses","Bourrasques de neige","Petites chutes de neige","Chutes de neige - Vent",
		"Neige","Gr�le","Verglas","Brouillard","Brumeux","Brume","Brouillard","Temp&ecirc;te",
		"Vent","Froid","Nuageux","Tr&#233;s Nuageux","Nuageux","Passages nuageux","Passages nuageux",
		"Ciel Clair","Ensoleill&#233;","Clair","Beau Temps","Pluie et Gr�le m&#233;lang&#233;es","Tr&#233;s Chaud",
		"Passages nuageux avec orages","Orages et &#201;claircies","Orages et &#201;claircies",
		"Pluies et &#201;claircies","Chute de neige importante","Petite chutes de neige",
		"Chute de neige importante","Partiellement couvert","Tonnerre","Chutes de neige",
		"Tonnerre et &#201;claircies","Pas d'info",];		 
		var windDirection =['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSO', 'SO', 'OSO',
		'O', 'ONO', 'NO', 'NNO', 'N'];		
		break;
	}	
		case "sp": {
		var this_date_name_array = ["00","01.","02.","03.","04.","05.","06.","07.","08.",
		"09.","10.","11.","12.","13.","14.","15.","16.","17.","18.","19.","20.","21.","22.","23.",
		"24.","25.","26.","27.","28.","29.","30.","31."]
		
		var this_weekday_name_array=["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"];
		var this_month_name_array=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Juliot","Agosto","Septiembre"," Octubre","Novimbre","Decimbre"];
		
		var weatherNow =["Tornado", "tormenta tropical", "tempestad", "tormenta", "tempestad", "lluvia y nieve" , 
       "La lluvia y la lluvia helada", "nieve y lluvia helada", "lluvia helada", "lluvia", 
       "La lluvia helada", "lluvia", "lluvia", "nieve", "nieve de luz", "nevadas tormentosa" ,
       "Nieve", "granizo", "lluvia helada", "cielo", "neblina", "cielo", "niebla", "tormentoso", "viento", "fr�o", 
       "Claro", "parc. despejado", "parc. despejado", "parc. despejado" , 
       "Parc. despejado", "despejado", "soleado", "despejado", "buen d�a", 
       "La lluvia y el granizo", "caluroso", "tormentas el�ctricas aisladas", "tormenta", "tormenta", 
       "Lluvias dispersas", "nevadas", "nieve dispersas", "nevadas", "parcialmente nublado" ,
       "Despu�s de la lluvia", "nieve", "Tormenta sencilla", "N / A",]; 
		 
		var windDirection =['N', 'N-NO', 'NO', 'O-NO', 'O', 'O-SO', 'SO', 'S-SO', 'S', 'S-SE', 'SE', 'E-SE', 'E', 'E-NE', 'NE', 'N-NE', 'N'];
		break;			
			
	}
}

function ForecastDayNames(day){
	switch (language) {
		case "ge": {
			switch (day) {
				case "Mon": { return "Montag" }
				case "Tue": { return "Dienstag" }
				case "Wed": { return "Mittwoch" }
				case "Thu": { return "Donnerstag" }
				case "Fri": { return "Freitag" }
				case "Sat": { return "Samstag" }
				case "Sun": { return "Sonntag" }
			}
		}
		case "fr": {
			switch (day) {
				case "Mon": { return "Lundi" }
				case "Tue": { return "Mardi" }
				case "Wed": { return "Mercredi" }
				case "Thu": { return "Jeudi" }
				case "Fri": { return "Vendredi" }
				case "Sat": { return "Samedi" }
				case "Sun": { return "Dimanche" }				
			}
		}
		case "sp": {
			switch (day) {
				case "Mon": { return "Dom" }
				case "Tue": { return "Lun" }
				case "Wed": { return "Mar" }
				case "Thu": { return "Mie" }
				case "Fri": { return "Jue" }
				case "Sat": { return "Vie" }
				case "Sun": { return "Sab" }	
			}
		}
	}
	return day;
}

