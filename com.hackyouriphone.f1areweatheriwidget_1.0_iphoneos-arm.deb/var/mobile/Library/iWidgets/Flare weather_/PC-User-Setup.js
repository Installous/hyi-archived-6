/****************************

*	  Basic_theme created by oldster	    *

*     SB/LS Weather_Time_Date_simple Modified by hell7    *

****************************/

var locale		 = 641683;	// WOEID only numbers

var nextWeather = 15*60*1000;  // first numerol - mins

var gps_weather  = false;     // false No GPS Weather

var language = 'en'; // en-English ge-German fr-France sp-Spain

var weather_unit = 'f';      // cELSIUS - fAHRENHEIT 

var hour24		 = false;     // false 12h am/pm








