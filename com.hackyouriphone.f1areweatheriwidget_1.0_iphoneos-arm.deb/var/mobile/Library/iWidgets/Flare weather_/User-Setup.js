/****************************

*	  Basic_theme created by oldster	    *

*     Flare iWidget weather big modified by hell7    *

****************************/

var nextWeather = 30*60*1000;  // first numerol - mins

/****************************

*    The end my friend,lol    *

****************************/









