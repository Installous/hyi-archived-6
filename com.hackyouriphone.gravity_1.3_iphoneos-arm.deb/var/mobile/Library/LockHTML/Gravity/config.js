var BorderColor = 'DarkGrey';
var TimeColor = 'LightGrey';
var TempTextColor = 'White';
var TempRibbonColor1 = 'Blue';
var TempRibbonColor2 = 'Darkblue';
var TwentyFourHour = false;