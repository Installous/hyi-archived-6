function startTime() {
	var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
	var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
	Date.prototype.getMonthName = function() {
		return months[ this.getMonth() ];
	};
	Date.prototype.getDayName = function() {
		return days[ this.getDay() ];
	};

	var now = new Date();

	var day = now.getDayName();
	var month = now.getMonthName();
	var today = new Date();
	var h = today.getHours();
	var m = today.getMinutes();
	var s = today.getSeconds();
	var d = today.getDate();  //it returns the date
	var mx = today.getMonth()+1; //returns the index of the month array
									//for our convenience we add 1 to it
	m = checkTime(m);
	s = checkTime(s);
	j = ordinal_suffix_of(d)
	var ampm = h >= 12 ? 'pm' : 'am';
	document.getElementById('myTime').innerHTML = h + ":" + m + " " + ampm;
	//document.getElementById('myDate').innerHTML = "<font color='"+DateColour+"'>" + j + " " + month +"</font>";
	var t = setTimeout(startTime, 500);
}
function checkTime(i) {
	if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
	return i;
}
function ordinal_suffix_of(i) {
	var j = i % 10,
		k = i % 100;
	if (j == 1 && k != 11) {
		return i + "st";
	}
	if (j == 2 && k != 12) {
		return i + "nd";
	}
	if (j == 3 && k != 13) {
		return i + "rd";
	}
	return i + "th";
}
