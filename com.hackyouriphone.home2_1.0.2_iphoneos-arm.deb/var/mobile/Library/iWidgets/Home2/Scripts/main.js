
window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

var prC = '#FFFFFF', seC = '#FFFFFF';
//var isDock = 1;

function init(){
	checkSettings();
	updateClock();
	setInterval("updateClock();", 1000);
}


function checkSettings(){
	
	for(var i=0; i<9; i++){
		var c = i + 1;
		document.getElementById('t' + c).style.left = (100 / 9) * i + '%';
	}
	
	if(isDock === 1){
		document.getElementById('_footerHolder').style.top = '-170px';
		document.getElementById('_foot-out').style.top = '0px';
		document.getElementById('controls').style.top = '80px';
		document.getElementById('_bar').style.bottom = '120px';
		
		document.getElementById('_foot-out').style.borderRadius = '0 0 20px 20px';
		
		document.getElementById('_weaCont').classList.add('inner-cont-dock');
		document.getElementById('_musCont').classList.add('inner-cont-dock');
	}
	
	
	//create forecast
        forecastMaker.makeForecast({
            holder: document.getElementById('forecast'),
			color: seC,
            dayCount: 3, //number of days
            dayWidth: 55, //holder width can also be used as spacing
            dayHeight: 50, //holder height
            imgWidth: 40, //image size
            font: 'thin',
            dayTop: 0, //day vertical position from top
            tempBottom: 0, //temp vertical position from bottom
            fontSize: 12, //day text and temp size
            iconURL: 'weather/', //url to icon
            iconsName: 'weatherIcons', //id for weather icons (increments)
            daysName: 'weatherDays', //id for days (increments)
            tempsName: 'weatherTemps', //id for temps (increments)
        });
	
}


//------------------------- TIME FUNCTIONS ---------------------------
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	//var Time24 = 1;
	
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
		currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
		currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	}
	
	
	document.getElementById("_mo").innerHTML = shortmonths[currentTime.getMonth()];
	document.getElementById("_d").innerHTML = shortdays[currentTime.getDay()];
	document.getElementById("_da").innerHTML = currentDate;
	
	document.getElementById("_time").innerHTML = currentHours + "." + currentMinutes1;
	//document.getElementById("_minutes").innerHTML = currentMinutes1;
		
}


//------------------------- BUTTONS FUNCTIONS ---------------------------
function slide(){
	if(document.getElementById('_bar').classList.contains('closed')){
		document.getElementById('_bar').classList.remove('closed');
		document.getElementById('_bar').classList.add('open');
		if(isDock === 0){
			TweenMax.to(document.getElementById("_footerHolder"), 0.5, {bottom:0});
		}else{
			TweenMax.to(document.getElementById("_footerHolder"), 0.5, {top:0});
		}
		return;
	}else{
		document.getElementById('_bar').classList.remove('open');
		document.getElementById('_bar').classList.add('closed');
		if(isDock === 0){
			TweenMax.to(document.getElementById("_footerHolder"), 0.5, {bottom:'-175px'});
		}else{
			TweenMax.to(document.getElementById("_footerHolder"), 0.5, {top:'-175px'});
		}
		return;
	}
}

function openPanel(id){
	if(document.getElementById(id).classList.contains('closed')){
		document.getElementById(id).classList.remove('closed');
		document.getElementById(id).classList.add('open');
		if(id === 'weatButton'){
			if(isDock === 0){
				TweenMax.to(document.getElementById("_weaCont"), 0.5, {bottom:'95px'});
				TweenMax.to(document.getElementById("_musCont"), 0.5, {bottom:'0px'});
			}else{
				TweenMax.to(document.getElementById("_weaCont"), 0.5, {top:'95px'});
				TweenMax.to(document.getElementById("_musCont"), 0.5, {top:'0px'});
			}
			document.getElementById('musButton').classList.remove('open');
			document.getElementById('musButton').classList.add('closed');
		}
		if(id === 'musButton'){
			if(isDock === 0){
				TweenMax.to(document.getElementById("_musCont"), 0.5, {bottom:'95px'});
				TweenMax.to(document.getElementById("_weaCont"), 0.5, {bottom:'0px'});
			}else{
				TweenMax.to(document.getElementById("_musCont"), 0.5, {top:'95px'});
				TweenMax.to(document.getElementById("_weaCont"), 0.5, {top:'0px'});
			}
			document.getElementById('weatButton').classList.remove('open');
			document.getElementById('weatButton').classList.add('closed');
		}
		return;
	}else{
		document.getElementById(id).classList.remove('open');
		document.getElementById(id).classList.add('closed');
		
		if(id === 'weatButton'){
			if(isDock === 0){
				TweenMax.to(document.getElementById("_weaCont"), 0.5, {bottom:'0px'});
			}else{
				TweenMax.to(document.getElementById("_weaCont"), 0.5, {top:'0px'});
			}
		}
		if(id === 'musButton'){
			if(isDock === 0){
				TweenMax.to(document.getElementById("_musCont"), 0.5, {bottom:'0px'});
			}else{
				TweenMax.to(document.getElementById("_musCont"), 0.5, {top:'0px'});
			}
		}
	}
}

function openBtn(id){
	if(document.getElementById(id).classList.contains('hide')){
		document.getElementById(id).classList.remove('hide');
		document.getElementById(id).classList.add('show');
		
		if(id === '_time'){
			TweenMax.to(document.getElementById("_month"), 0.5, {alpha:1});
			TweenMax.to(document.getElementById("_date"), 0.5, {alpha:1, delay:0.25});
			TweenMax.to(document.getElementById("_day"), 0.5, {alpha:1, delay:0.5});
		}
		
		if(id === 'settButton'){
			document.getElementById("_colors").style.display = 'block';
			document.getElementById("_sBg").style.display = 'block';
			TweenMax.to(document.getElementById("_colors"), 0.5, {alpha:1});
			TweenMax.to(document.getElementById("_sBg"), 0.5, {alpha:1, delay:0.25});
		}
		return;
	}else{
		document.getElementById(id).classList.add('hide');
		document.getElementById(id).classList.remove('show');
		if(id === '_time'){
			TweenMax.to(document.getElementById("_month"), 0.5, {alpha:0});
			TweenMax.to(document.getElementById("_date"), 0.5, {alpha:0, delay:0.25});
			TweenMax.to(document.getElementById("_day"), 0.5, {alpha:0, delay:0.5});
		}
		
		if(id === 'settButton'){
			TweenMax.to(document.getElementById("_colors"), 0.5, {alpha:0});
			TweenMax.to(document.getElementById("_sBg"), 0.5, {alpha:0, delay:0.25, onComplete:function(){
				document.getElementById("_colors").style.display = 'none';
				document.getElementById("_sBg").style.display = 'none';
			}});
		}
		return;
	}
}

function showBg(){
	var cont = document.getElementById("bg");
	var ch = cont.children;
	
	if(document.getElementById("bg").classList.contains('hide')){
		document.getElementById("bg").classList.remove('hide');
		document.getElementById("bg").classList.add('show');
		for(var i=0; i < ch.length; i++){
			TweenMax.to(document.getElementById(ch[i].id), 0.1, {alpha:1, delay:i*0.05});
		}
		return;
	}else{
		document.getElementById("bg").classList.add('hide');
		document.getElementById("bg").classList.remove('show');
		for(var i=0; i < ch.length; i++){
			TweenMax.to(document.getElementById(ch[i].id), 0.1, {alpha:0, delay:i*0.05});
		}
		return;
	}
}

function changeColor(){
	
	var bgC, bgF, bgCon, bgICont, secondary, wC, sidesC;
	
	if(document.getElementById("_colors").classList.contains('black')){
		document.getElementById("_colors").classList.remove('black');
		document.getElementById("_colors").classList.add('white');
		
		bgC = '#F8F8F8';
		bgF = '#FFFFFF';
		bgCon = '#E6E6E6';
		bgICont = '#E6E6E6';
		secondary = '#000000';
		wC = '#000000';
		sidesC = '#D5DFE6';
		
		applyColor(bgC, bgF, bgCon, bgICont, secondary, wC, sidesC);
		return;
	}
	
	if(document.getElementById("_colors").classList.contains('white')){
		document.getElementById("_colors").classList.remove('white');
		document.getElementById("_colors").classList.add('blue');
		
		bgC = '#242C5F';
		bgF = '#181F45';
		bgCon = '#2A387D';
		bgICont = '#273371';
		secondary = '#6DC1F0';
		wC = '#6DC1F0';
		sidesC = '#181F45';
		
		applyColor(bgC, bgF, bgCon, bgICont, secondary, wC, sidesC);
		return;
	}
	
	if(document.getElementById("_colors").classList.contains('blue')){
		document.getElementById("_colors").classList.remove('blue');
		if(custom === 0){
			document.getElementById("_colors").classList.add('black');
			bgC = '#202328';
			bgF = '#12171B';
			bgCon = '#1F282F';
			bgICont = '#33424E';
			secondary = '#FFFFFF';
			wC = '#FFFFFF';
			sidesC = '#0394D9';
		}else{
			document.getElementById("_colors").classList.add('custom');
			bgC = bc;
			bgF = bf;
			bgCon = bco;
			bgICont = bi;
			secondary = se;
			wC = wc;
			sidesC = sc;
		}
		
		applyColor(bgC, bgF, bgCon, bgICont, secondary, wC, sidesC);
		return;
	}
	
	if(document.getElementById("_colors").classList.contains('custom')){
		document.getElementById("_colors").classList.remove('custom');
		document.getElementById("_colors").classList.add('black');
		
		bgC = '#202328';
		bgF = '#12171B';
		bgCon = '#1F282F';
		bgICont = '#33424E';
		secondary = '#FFFFFF';
		wC = '#FFFFFF';
		sidesC = '#0394D9';
		
		applyColor(bgC, bgF, bgCon, bgICont, secondary, wC, sidesC);
		return;
	}
}

function applyColor(bgC, bgF, bgCon, bgICont, secondary, wC, sidesC){
	document.documentElement.style.setProperty('--bgC', bgC);
	document.documentElement.style.setProperty('--bgF', bgF);
	document.documentElement.style.setProperty('--bgCon', bgCon);
	document.documentElement.style.setProperty('--bgICont', bgICont);
	document.documentElement.style.setProperty('--secondary', secondary);
	document.documentElement.style.setProperty('--wC', wC);
	document.documentElement.style.setProperty('--sidesC', sidesC);
		
	for (var i = 0; i < 3; i++) {
		document.getElementById(fcastObj.icon + i).style.filter = 'opacity(.5) drop-shadow(0 0 0 ' + wC +')';
		document.getElementById(fcastObj.day + i).style.color = wC;
		document.getElementById(fcastObj.temp + i).style.color = wC;
	}
	document.getElementById('temp').style.color = wC;
	document.getElementById('weatButton').style.filter = 'opacity(.5) drop-shadow(0 0 0 ' + wC +')';
	document.getElementById('condition').style.color = wC;
}
