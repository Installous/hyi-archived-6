
var startAnim = false;

//------------------------- XENINFO --------------------------
function mainUpdate(type){ 
	if(type == "weather"){
		checkWeather();
	}else if (type == "statusbar"){
		//sigBars(document.getElementById("wl2"),parseInt(wifiBars), 3);
		//sigBars(document.getElementById("sl2"),parseInt(signalBars), 4);
	}else if (type == "battery"){
		updateBattery();	  	
	}else if (type == "music"){
		checkMusic();
	}
}

//------------------------- BATTERY FUNCTIONS ---------------------------
//var batteryPercent;
//var batteryCharging = 0;
//updateBattery();
function updateBattery() {
	"use strict";

	var batt = document.getElementById("percent");
	//console.log("battery");
	//batteryPercent = 20;
	batt.innerHTML = batteryPercent;
	batInside.style.width = (batteryPercent * 16 / 100) + 'px';
	
	if(batteryCharging === 1){
		batInside.style.background = '#2483CB';
	}else{
		batInside.style.background = 'rgba(255,255,255,1)';
	}
	
	if (batteryPercent <= 20 && batteryPercent > 10 && batteryCharging === 0) {
		batInside.style.background = '#E8C04E';
	} else if (batteryPercent <= 10 && batteryCharging === 0) {
		batInside.style.background = '#DE3840';
	}
}


//------------------------- WEATHER FUNCTIONS ---------------------------
function checkWeather(){
	document.getElementById('temp').innerHTML = weather.temperature + 'º';
	document.getElementById('weatButton').src = 'weather/' + weather.conditionCode + '.png';
	document.getElementById('condition').innerHTML = weather.condition;
	
	//forecast
    var icon, i;
    for (i = 0; i < fcastObj.dayCount; i++) { //loop through forecast and update each day
    	icon = (weather.dayForecasts[i].icon == 3200) ? weather.conditionCode : weather.dayForecasts[i].icon;
        document.getElementById(fcastObj.icon + i).src = fcastObj.iconURL + icon + '.png';
        document.getElementById(fcastObj.day + i).innerHTML = shortdays[weather.dayForecasts[i].dayOfWeek - 1];
        document.getElementById(fcastObj.temp + i).innerHTML = weather.dayForecasts[i].high + '/' + weather.dayForecasts[i].low;
    }
}

//------------------------- SIGNAL FUNCTIONS ---------------------------
function sigBars(indicator,_curr, _max){
	indicator.style.height = _curr * 30 / _max + 'px';
	indicator.style.top = 30 - _curr * 30 / _max + 'px';
}