/* *************************************** */
/* The following scripts will allow you to finetune */

/* *************************************** */

/* ********* Configure Your Weather Widget here ********* */
/* Step 1 - Find YOUR city code (locale) here : http://weather.yahoo.com/

/* Step 2 - Then enter your city code here */
var locale = "1062617" 

/* Use Celsius or not */
var isCelsius = true

/* Use Real Feel Temperature or not */
var useRealFeel = true

/* Minutes between updates */
var updateInterval = 15


/* ****************************************************** */


/* *************************************** */
/* **************** CLOCK **************** */

//Toggles twelve and twenty-four hour time.
var twentyFourHourTime = false;


/* *************************************** */
/* ************** CALENDAR *************** */

//This affects the calendar.
function updateCalendarBar() {
	var theDate = new Date();
	var theWeekday = theDate.getDay();
	var theMonth = theDate.getMonth();
	var theDay = theDate.getDate();
	var theYear = theDate.getFullYear();
	
	 /* REMOVE THIS TO USE HALF YEAR
	theYear = theYear.toString().slice(2);
	 */
	 
	var weekdaysArray = new Array();
	//Change the Weekdays here
	weekdaysArray[0] = "SUNDAY";
	weekdaysArray[1] = "MONDAY";
	weekdaysArray[2] = "TUESDAY";
	weekdaysArray[3] = "WEDNESDAY";
	weekdaysArray[4] = "THURSDAY";
	weekdaysArray[5] = "FRIDAY";
	weekdaysArray[6] = "SATURDAY";
	theWeekday = weekdaysArray[theWeekday];
	
	
	var monthsArray = new Array();
	//Change the Months here
	monthsArray[0] = "JAN";
	monthsArray[1] = "FEB";
	monthsArray[2] = "MARH";
	monthsArray[3] = "APR";
	monthsArray[4] = "MAY";
	monthsArray[5] = "JUNE";
	monthsArray[6] = "JUL";
	monthsArray[7] = "AUG";
	monthsArray[8] = "SEPT";
	monthsArray[9] = "OCT";
	monthsArray[10] = "NOV";
	monthsArray[11] = "DEC";
	theMonth = monthsArray[theMonth];
	
	if (theDay < 10) {theDay = "0" + theDay};
	
	var formattedDays = String(theDay);
	formattedDays = formattedDays.split("");
	document.getElementById("year").innerHTML = "'"+theYear;  /* Use HALF year ex: '11, '12 */
	document.getElementById("year").innerHTML = theYear;	  /* Use FULL year ex: 2011, 2012 */
	document.getElementById("week").innerHTML = theWeekday;
	document.getElementById("month").innerHTML = theMonth;
	document.getElementById("day").innerHTML = theWeekday + " " + theDay + " " + theMonth;
}
