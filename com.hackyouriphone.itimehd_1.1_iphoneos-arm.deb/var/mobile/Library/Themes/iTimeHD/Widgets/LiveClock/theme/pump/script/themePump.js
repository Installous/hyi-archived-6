// ********************************************************
// themePump
// author: storyr
// version: 1.02
// last modified: 10/3/2010
// ********************************************************
var _log = false;
var _tools = new themePumpTools();
var _pump;
var _version = "1.0";

$(document).ready(function () {
   if (_log) {
      $("body").prepend("<div id='testmode' style='position: absolute; top: 20px; font-family: Helvetica, sans-serif; font-size: 0.7em; font-weight: bold; text-shadow: rgba(0,0,0,1) 1px 1px 2px; color: #ffff00; z-index: 1000;'/>");
   }
   //_tools.log("$(document).ready");
   _pump = new themePump();
   _pump.luna = new luna();
   _pump.settings = new themePumpSettings();
   _pump.settings.getThemeSettings(initPhase2);
});

function initPhase2() {
   //_tools.log("initPhase2()");
   _pump.refreshCurrentDateTime();
   _pump.settings.getWeatherData(false, initPhase3);
   $(".pump_translate").each(function () {
      $(this).html(_pump.translate($(this).html()));
   });
   if (_pump.settings.clockMode == 0) {
      setInterval("refresh();", 1000);
   } else {
      setInterval("refresh();", 5000);
   }
}

function initPhase3() {
   //_tools.log("initPhase3()");
   _pump.refreshTimeImage(true);
   _pump.themeCallback(_pump.settings.theme.callback.onInitialize);
   _pump.refreshCurrentData(_pump.settings.data, _pump.settings.theme, _pump.settings.radar);
   _pump.refreshForecastData(_pump.settings.data, _pump.settings.theme);
   //_tools.log("ready!");
}

function refresh() {
   _pump.refresh(false);
}

//*************************************************************************************************
//*************************************************************************************************

function themePump() {
   //_tools.log("themePump constructor");
   var me = this;

   this.refresh = function (force) {
      //_tools.log("themePump.refresh()")
      this.refreshCurrentDateTime();
      this.refreshTimeImage(true);
      var interval = _pump.settings.refreshInterval * 60000;
      var d = new Date();
      if (force || (_pump.settings.data.refreshTime + interval) < d.getTime()) {
         _pump.settings.getWeatherData(true, function () {
            me.refreshTimeImage(true);
            me.refreshCurrentData(_pump.settings.data, _pump.settings.theme, _pump.settings.radar);
            me.refreshForecastData(_pump.settings.data, _pump.settings.theme);
         });
         return false;
      }
      return true;
   };

   this.prevCity = function () {
      var i = (_pump.settings.cityIndex - 1) >= 0 ? _pump.settings.cityIndex - 1 : _pump.settings.cityList.length - 1;
      me.setCurrentCity(i);
   };

   this.nextCity = function () {
      var i = (_pump.settings.cityIndex + 1) < (_pump.settings.cityList.length) ? _pump.settings.cityIndex + 1 : 0;
      me.setCurrentCity(i);
   };

   this.setCurrentCity = function (index) {
      //_tools.log("themePump.setCurrentCity index = " + index);
      _pump.settings.cityIndex = index;
      if (index >= _pump.settings.cityList.length) {
         _pump.settings.cityIndex = _pump.settings.cityList.length - 1;
      }
      _pump.settings.getWeatherData(false, function () {
         me.refreshCurrentDateTime();
         me.refreshTimeImage(true);
         me.refreshCurrentData(_pump.settings.data, _pump.settings.theme, _pump.settings.radar);
         me.refreshForecastData(_pump.settings.data, _pump.settings.theme);
         //refresh();
      });
      _tools.setState("cityIndex", _pump.settings.cityIndex.toString());
   };

   this.refreshData = function () {
      me.refreshCurrentData(_pump.settings.data, _pump.settings.theme, _pump.settings.radar);
      me.refreshForecastData(_pump.settings.data, _pump.settings.theme);
   }

   this.refreshCurrentData = function (data, theme, radar) {
      //_tools.log("themePump.refreshCurrentData()");
      var ctr = theme.selector + " ";
      $(ctr + ".pump_update_time").html(data.updateTime);
      $(ctr + ".pump_update_date").html(data.updateDate);
      $(ctr + ".pump_degree_symbol").html(data.degreeSymbol);
      //$(ctr + ".pump_loc_city").html(data.location.name);
      $(ctr + ".pump_loc_asof").html(data.location.asOfTime);
      $(ctr + ".pump_loc_sunrise").html(data.location.sunrise);
      $(ctr + ".pump_loc_sunset").html(data.location.sunset);
      $(ctr + ".pump_loc_lastupdated").html(data.location.asOfText);
      $(ctr + ".pump_loc_station").html(data.location.station);
      $(ctr + ".pump_units_temp").html(data.units.temp);
      $(ctr + ".pump_units_distance").html(data.units.distance);
      $(ctr + ".pump_units_speed").html(data.units.speed);
      $(ctr + ".pump_units_pressure").html(data.units.pressure);
      $(ctr + ".pump_cc_barom_reading").html(data.cc.barometer.reading);
      $(ctr + ".pump_cc_barom_text").html(this.translate(data.cc.barometer.direction));
      $(ctr + ".pump_cc_dewpoint").html(data.cc.dewpoint);
      $(ctr + ".pump_cc_humidity").html(data.cc.humidity);
      $(ctr + ".pump_cc_weather_image").attr("src", this.getIconImageName(data.cc.icon));
      $(ctr + ".pump_cc_moon_image").attr("src", this.getImageName(theme.icons.moon, data.cc.moon.icon));
      $(ctr + ".pump_cc_moon_text").html(this.translate(data.cc.moon.text));
      $(ctr + ".pump_cc_moon_pct").html(data.cc.moon.pct);
      $(ctr + ".pump_cc_moon_nextPhase").html(this.translate(data.cc.moon.nextPhase));
      $(ctr + ".pump_cc_moon_nextPhaseDate").html(data.cc.moon.nextPhaseDate);
      $(ctr + ".pump_cc_moon_nextPhaseTime").html(data.cc.moon.nextPhaseTime);
      $(ctr + ".pump_cc_precip").html(data.cc.precip);
      $(ctr + ".pump_cc_temp").html(data.cc.temp);
      $(ctr + ".pump_cc_temp_feels").html(data.cc.apparentTemp);
      $(ctr + ".pump_cc_text").html(this.translate(data.cc.text));
      $(ctr + ".pump_cc_uv_index").html(data.cc.uv.index);
      $(ctr + ".pump_cc_uv_text").html(this.translate(data.cc.uv.text));
      $(ctr + ".pump_cc_visibility").html(data.cc.visibility);
      $(ctr + ".pump_cc_wind_speed").html(data.cc.wind.speed);
      $(ctr + ".pump_cc_wind_degrees").html(data.cc.wind.degrees);
      $(ctr + ".pump_cc_wind_direction").html(this.translate(data.cc.wind.direction));
      if (data.cc.wind.direction.toLowerCase() == "calm") {
         $(ctr + ".pump_cc_wind_text").html(this.translate("calm"));
         $(ctr + ".pump_cc_wind_text2").html(this.translate("calm"));
      } else {
         $(ctr + ".pump_cc_wind_text").html("<span class='weak'>" + this.translate("out of the") + " </span><span>" +
                data.cc.wind.direction + "</span><span class='weak'> " + this.translate("at") + " </span><span>" +
                data.cc.wind.speed + " " + data.units.speed + "</span>");
         $(ctr + ".pump_cc_wind_text2").html("<span>" +
                data.cc.wind.direction + "</span><span class='weak'> </span><span>" +
                data.cc.wind.speed + " " + data.units.speed + "</span>");
      }
      for (var i = 0; i < radar.length; i++) {
         if (radar[i].url != "") {
            $(ctr + ".pump_radar_image" + (i + 1).toString()).attr("src", radar[i].url);
         }
      }
   };

   this.refreshForecastData = function (data, theme) {
      //_tools.log("themePump.refreshForecastData()");
      var ctr = theme.selector + " ";
      $(ctr + ".pump_fcst_lastupdated").html(data.forecast.asOfText);
      for (var i = 0; i < data.forecast.day.length; i++) {
         var day = data.forecast.day[i];
         var path = ctr + ".pump_fcst_day" + day.sequence;
         $(path + "_name").html(this.translate(day.name));
         $(path + "_name_abbr").html(this.translate(day.name.substr(0, 3)));
         $(path + "_date").html(day.date);
         $(path + "_high").html(day.high.toLowerCase());
         $(path + "_low").html(day.low.toLowerCase());
         $(path + "_sunrise").html(day.sunrise);
         $(path + "_sunset").html(day.sunset);
         $(path + "_day_weather_image").attr("src", this.getIconImageName(day.daytime.icon));
         $(path + "_day_text").html(this.translate(day.daytime.text));
         $(path + "_day_precip").html(day.daytime.precip);
         $(path + "_day_humidity").html(day.daytime.humidity);
         $(path + "_day_wind_speed").html(day.daytime.wind.speed);
         $(path + "_day_wind_degrees").html(day.daytime.wind.degrees);
         $(path + "_day_wind_direction").html(this.translate(day.daytime.wind.direction));
         $(path + "_night_weather_image").attr("src", this.getIconImageName(day.nighttime.icon));
         $(path + "_night_text").html(this.translate(day.nighttime.text));
         $(path + "_night_precip").html(day.nighttime.precip);
         $(path + "_night_humidity").html(day.nighttime.humidity);
         $(path + "_night_wind_speed").html(day.nighttime.wind.speed);
         $(path + "_night_wind_degrees").html(day.nighttime.wind.degrees);
         $(path + "_night_wind_direction").html(this.translate(day.nighttime.wind.direction));
         $(path + "_moon_image").attr("src", this.getImageName(theme.icons.moon, day.moon.icon));
         $(path + "_moon_text").html(this.translate(day.moon.text));
         $(path + "_moon_pct").html(day.moon.pct);
      }
   };

   this.getImageName = function (iconSettings, code) {
      try {
         if (!iconSettings.enabled) { return ""; }
         return image = iconSettings.folder + "/" + iconSettings.image[parseInt(code, 10)].name;
      }
      catch (err) {
         return "";
      }
   };

   this.getIconImageName = function (code) {
      //_tools.log("themePump.getIconImageName() code = " + code);
      try {
         var set = _pump.settings.theme.icons.set[_pump.settings.iconSetIndex];
         var map = _pump.settings.theme.icons.map[set.mapIndex];
         var image = set.path + "/" + map.image[parseInt(code, 10)].name;
         return image;
      }
      catch (err) {
         return "";
      }
   };

   this.refreshCurrentDateTime = function () {
      //_tools.log("themePump.refreshCurrentDateTime()");
      var s = _pump.settings.theme.selector + " ";
      var d = new Date();
      if (_pump.settings.clockSource == "city" && typeof (_pump.settings.data) != "undefined") {
         d = _tools.getOffsetDate(d, _pump.settings.data.location.UtcOffset);
      }
      // year
      $(s + ".pump_year").html(d.getFullYear());
      $(s + ".pump_year_text").html(this.translate(numbertext[d.getFullYear()]));
      // week day
      $(s + ".pump_week_day").html(this.translate(weekdaytext[d.getDay()]));
      // month
      $(s + ".pump_month").html(d.getMonth() + 1);
      $(s + ".pump_month_text").html(this.translate(monthtext[d.getMonth()]));
      // month day
      var daynum = d.getDate();
      $(s + ".pump_day").html(daynum);
      var daysinmonth = 32 - new Date(d.getFullYear(), d.getMonth(), 32).getDate();
      $(s + ".pump_day_last").html(daysinmonth);
      $(s + ".pump_day_text").html(this.translate(monthdaytext[daynum]));
      // month day number suffix
      var suffix = "";
      switch (daynum) {
         case 1:
         case 21:
         case 31:
            suffix = "st";
            break;
         case 2:
         case 22:
            suffix = "nd";
            break;
         case 3:
         case 23:
            suffix = "rd";
            break;
         default:
            suffix = "th";
      }
      // day suffix
      $(s + ".pump_day_suffix").html(this.translate(suffix));
      // date
      $(s + ".pump_date").html(_tools.getFormattedDate(d));
      var t = _tools.getFormattedTime(d);
      t = t.split(" ", 2);
      // time stuff
      $(s + ".pump_time").html(t[0]);
      $(s + ".pump_time_ampm").html(t.length == 2 ? t[1] : "");
      t = t[0].split(":");
      $(s + ".pump_hour").html(t[0]);
      $(s + ".pump_hour_text").html(this.translate(numbertext[parseInt(t[0], 10)]));
      $(s + ".pump_minute").html(t[1]);
      $(s + ".pump_minute_text").html(this.translate(numbertext[parseInt(t[1], 10)]));
      var sec = ("0" + d.getSeconds()).slice(-2)
      $(s + ".pump_second").html(sec);
      $(s + ".pump_second_text").html(this.translate(numbertext[parseInt(sec, 10)]));
      // graphic clock
      var seconds = new Date().getSeconds();
      var sdegree = seconds * 6;
      var srotate = "rotate(" + sdegree + "deg)";
      $(s + ".pump_clock_sec_hand").css({ "-webkit-transform": srotate });
      var hours = new Date().getHours();
      var mins = new Date().getMinutes();
      var hdegree = hours * 30 + (mins / 2);
      var hrotate = "rotate(" + hdegree + "deg)";
      $(s + ".pump_clock_hour_hand").css({ "-webkit-transform": hrotate });
      var mdegree = mins * 6;
      var mrotate = "rotate(" + mdegree + "deg)";
      $(s + ".pump_clock_min_hand").css({ "-webkit-transform": mrotate });
      // city
      if (_pump.settings.cityIndex < _pump.settings.cityList.length) {
         $(s + ".pump_loc_city").html(_pump.settings.cityList[_pump.settings.cityIndex].name);
      }
   };

   this.refreshTimeImage = function (force) {
      //_tools.log("themePump.refreshTimeImage()");
      var time = this.getLocationTimeCode();
      if (force || time != _pump.settings.data.cc.time) {
         _pump.settings.data.cc.time = time;
         _pump.settings.data.cc.sky = this.getSkyCode(_pump.settings.data);
         $(_pump.settings.theme.selector + " .pump_cc_time_image").attr("src", this.getImageName(_pump.settings.theme.timeImage, _pump.settings.data.cc.time));
         $(_pump.settings.theme.selector + " .pump_cc_sky_image").attr("src", this.getImageName(_pump.settings.theme.skyImage, _pump.settings.data.cc.sky));
      }
   };

   this.getLocationTimeCode = function () {
      //_tools.log("themePump.getLocationTimeCode()");
      var date = new Date();
      var code = date.getUTCHours() + parseInt(_pump.settings.data.location.UtcOffset.toFixed().toString());
      if (code < 0) code = code + 24;
      if (code > 23) code = Math.abs(24 - code);
      return code;
   };

   this.getSkyCode = function (data) {
      //_tools.log("themePump.getSkyCode()");
      // compute a start and end period for sunrise and sunset
      var date = new Date();
      var offsetDate = _tools.getOffsetDate(date, data.location.UtcOffset);
      var currentTime = offsetDate.getTime();
      var sunriseTime = _tools.parseTime(offsetDate, data.location.sunrise);
      var sunsetTime = _tools.parseTime(offsetDate, data.location.sunset);

      //      date.setTime(currentTime);
      //      _tools.log("themePump.getSkyCode() currentTime: " + date);
      //      date.setTime(sunriseTime);
      //      _tools.log("themePump.getSkyCode() sunriseTime: " + date);
      //      date.setTime(sunsetTime);
      //      _tools.log("themePump.getSkyCode() sunsetTime: " + date);

      var delta = 2700000 // 45 minutes
      var sunriseStartTime = sunriseTime - delta;
      var sunriseEndTime = sunriseTime + delta;
      var sunsetStartTime = sunsetTime - delta;
      var sunsetEndTime = sunsetTime + delta;

      //      date.setTime(sunriseStartTime);
      //      _tools.log("themePump.getSkyCode() sunriseStartTime: " + date);
      //      date.setTime(sunriseEndTime);
      //      _tools.log("themePump.getSkyCode() sunriseEndTime: " + date);
      //      date.setTime(sunsetStartTime);
      //      _tools.log("themePump.getSkyCode() sunsetStartTime: " + date);
      //      date.setTime(sunsetEndTime);
      //      _tools.log("themePump.getSkyCode() sunsetEndTime: " + date);

      // determine day, night, sunrise, sunset
      // 0 = sunrise, 1 = day, 2 = sunset, 3 = night
      var sky1 = 1;
      if (currentTime >= sunriseStartTime && currentTime <= sunriseEndTime) {
         sky1 = 0;
      }
      else if (currentTime > sunriseStartTime && currentTime < sunsetStartTime) {
         sky1 = 1;
      }
      else if (currentTime >= sunsetStartTime && currentTime <= sunsetEndTime) {
         sky1 = 2;
      }
      else sky1 = 3;
      // determine weather element
      // 0 = clear, 1 = fair, 2 = partly cloudy, 3 = mostly cloudy, 4 = cloudy, 5 = rain, 6 = thunderstorm, 7 = snow
      var sky2 = 0;
      var icon = parseInt(data.cc.icon, 10);
      if (typeof (iconToSkyMap[icon]) != "undefined") {
         sky2 = iconToSkyMap[icon];
      }
      //_tools.log("sky1 = " + sky1.toString() + ", sky2 = " + sky2.toString());
      var sky = parseInt(sky1.toString() + sky2.toString(), 10);
      //_tools.log("themePump.getSkyCode() sky = " + sky);
      return sky;
   };

   this.themeCallback = function (callback) {
      if (!callback || callback == "") return;
      try {
         eval(callback + "(_pump.settings.data, _pump.settings)");
      }
      catch (err) {
         _tools.log("themePump.themeCallback[error] " + err);
      }
   };

   this.translate = function (text) {
      if (_pump.settings.language == "en") return text;
      if (typeof (text) == 'undefined') return "";
      var t = _pump.settings.dictionary[jQuery.trim(text.toLowerCase())];
      if (typeof (t) == "undefined") return text;
      return t;
   };

   var iconToSkyMap =
    [   // 0 = clear, 1 = fair, 2 = partly cloudy, 3 = mostly cloudy, 4 = cloudy, 5 = rain, 6 = thunderstorm, 7 = snow
        6,    // 0 tornado 
        6,    // 1 tropical storm 
        6,    // 2 hurricane 
        6,    // 3 severe thunderstorms 
        6,    // 4 thunderstorms 
        7,    // 5 mixed rain and snow 
        5,    // 6 mixed rain and sleet 
        7,    // 7 mixed snow and sleet 
        5,    // 8 freezing drizzle 
        5,    // 9 drizzle 
        5,    // 10 freezing rain 
        5,    // 11 showers / light rain               
        5,    // 12 heavy rain                         
        7,    // 13 snow flurries 
        7,    // 14 light snow showers 
        7,    // 15 snowflakes                         
        7,    // 16 snow 
        6,    // 17 thunderstorms                     
        6,    // 18 hail                               
        2,    // 19 dust 
        0,    // 20 foggy 
        0,    // 21 haze 
        2,    // 22 smoky 
        2,    // 23 blustery 
        2,    // 24 windy 
        1,    // 25 frigid                             
        4,    // 26 cloudy 
        3,    // 27 mostly cloudy (night) 
        3,    // 28 mostly cloudy (day) 
        2,    // 29 partly cloudy (night) 
        2,    // 30 partly cloudy (day) 
        0,    // 31 clear (night) 
        0,    // 32 sunny
        1,    // 33 fair (night) 
        1,    // 34 fair (day) 
        6,    // 35 thunderstorms                      
        1,    // 36 hot 
        6,    // 37 isolated thunderstorms (day)
        6,    // 38 scattered thunderstorms 
        5,    // 39 scattered rain (day)               
        5,    // 40 heavy rain                         
        7,    // 41 scattered snow showers            
        7,    // 42 heavy snow                        
        7,    // 43 windy/snowy                       
        2,    // 44 partly cloudy (day)
        5,    // 45 scattered showers (night)          
        7,    // 46 snow showers (night)              
        6,    // 47 isolated thundershowers (night)   
    ];

   var weekdaytext = [
      "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
   ];
   var monthtext = [
      "January", "Feburary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"
   ];
   var monthdaytext = [
      "", "first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth",
      "eleventh", "twelfth", "thirteenth", "fourteenth", "fifteenth", "sixteenth", "seventeenth", "eighteenth", "nineteenth", "twentieth",
      "twenty-first", "twenty-second", "twenty-third", "twenty-fourth", "twenty-fifth", "twenty-sixth", "twenty-seventh", "twenty-eighth", "twenty-ninth", "thirtieth",
      "thirty-first"
   ];
   var numbertext = [
      "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
      "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty",
      "twenty-one", "twenty-two", "twenty-three", "twenty-four", "twenty-five", "twenty-six", "twenty-seven", "twenty-eight", "twenty-nine", "thirty",
      "thirty-one", "thirty-two", "thirty-three", "thirty-four", "thirty-five", "thirty-six", "thirty-seven", "thirty-eight", "thirty-nine", "forty",
      "forty-one", "forty-two", "forty-three", "forty-four", "forty-five", "forty-six", "forty-seven", "forty-eight", "forty-nine", "fifty",
      "fifty-one", "fifty-two", "fifty-three", "fifty-four", "fifty-five", "fifty-six", "fifty-seven", "fifty-eight", "fifty-nine", "sixty"
   ];
   numbertext[2009] = "two thousand nine";
   numbertext[2010] = "two thousand ten";
   numbertext[2011] = "two thousand eleven";
   numbertext[2012] = "two thousand twelve";
   numbertext[2013] = "two thousand thirteen";

}

//*************************************************************************************************
//*************************************************************************************************

function themePumpSettings() {
   //_tools.log("themePumpSettings constructor");
   this.initialized = false;
   var me = this;
   var xml_request;

   // ***********************************
   this.getThemeSettings = function (callback) {
      //_tools.log("themePumpSettings.getThemeSettings start");
      me.theme = { version: _version };
      var xml_request = new XMLHttpRequest();
      xml_request.open("GET", "theme/settings.xml", false);
      if ($.browser.webkit) {
         xml_request.overrideMimeType("text/xml");
      } else {
         xml_request.setRequestHeader("Content-Type", "text/xml");
      }
      xml_request.setRequestHeader("Cache-Control", "no-cache");
      xml_request.send(null);
      me.saveThemeSettings(xml_request.responseXML, callback);
   };

   // ***********************************

   this.saveThemeSettings = function (xml, callback) {
      //_tools.log("themePumpSettings.saveThemeSettings start");
      var settingsXml = $.xmlToJSON(xml);
      me.testMode = false;
      me.language = settingsXml.language ? settingsXml.language[0].Text : "en";
      me.metric = settingsXml.units ? settingsXml.units[0].Text.toLowerCase() == "metric" : false;
      me.refreshInterval = settingsXml.refreshInterval ? settingsXml.refreshInterval[0].Text : "30";
      me.clockMode = settingsXml.clockMode ? parseInt(settingsXml.clockMode[0].Text, 10) : 0;
      me.clock = settingsXml.clock ? settingsXml.clock[0].Text : "12";
      me.clockSource = settingsXml.clockSource ? settingsXml.clockSource[0].Text : "city";
      me.themeIndex = settingsXml.themeIndex ? parseInt(settingsXml.themeIndex[0].Text, 10) : 0;
      me.iconSetIndex = settingsXml.iconSetIndex ? parseInt(settingsXml.iconSetIndex[0].Text, 10) : 0;
      // language
      me.dictionary = new Array;
      me.dictionary[""] = "";

      var xml_request = new XMLHttpRequest();
      xml_request.open("GET", "theme/language/lang_" + me.language + ".txt", false);
      xml_request.setRequestHeader("Cache-Control", "no-cache");
      xml_request.send(null);
      var lines = xml_request.responseText.split("\n");
      for (i in lines) {
         var t = lines[i].split("=");
         if (typeof (t[0]) != "undefined" && typeof (t[1]) != "undefined") {
            me.dictionary[jQuery.trim(t[0].toLowerCase())] = jQuery.trim(t[1]);
         }
      }
      // radar
      me.radar = new Array;
      if (settingsXml.radar && settingsXml.radar[0].url) {
         for (var i = 0; i < settingsXml.radar[0].url.length; i++) {
            me.radar[i] = { url: settingsXml.radar[0].url[i].Text };
         }
      }
      // days
      me.day = new Array;
      if (settingsXml.days && settingsXml.days[0].day) {
         for (var i = 0; i < settingsXml.days[0].day.length; i++) {
            me.day[i] = { name: settingsXml.days[0].day[i].Text };
         }
      }
      // months
      me.month = new Array;
      if (settingsXml.months && settingsXml.months[0].month) {
         for (var i = 0; i < settingsXml.months[0].month.length; i++) {
            me.month[i] = { name: settingsXml.months[0].month[i].Text };
         }
      }
      // cities
      me.cityIndex = 0;
      me.cityList = new Array;
      if (settingsXml.cities && settingsXml.cities[0].city) {
         for (var i = 0; i < settingsXml.cities[0].city.length; i++) {
            // ??? me.radar[i] = { url: settingsXml.radar[0].url[i].Text };
            me.cityList[i] = {
               code: settingsXml.cities[0].city[i].Text,
               name: settingsXml.cities[0].city[i].attr("name")
            };
         }
      }
      // icons
      me.theme.icons = {
         set: new Array,
         map: new Array,
         moon: ""
      };
      for (var i = 0; i < settingsXml.icons[0].sets[0].set.length; i++) {
         var s = settingsXml.icons[0].sets[0].set[i];
         me.theme.icons.set[i] = {
            name: s.attr("name"),
            mapIndex: s.attr("mapIndex"),
            path: s.attr("path")
         };
      }
      for (var i = 0; i < settingsXml.icons[0].maps[0].map.length; i++) {
         var m = settingsXml.icons[0].maps[0].map[i];
         me.theme.icons.map[i] = {
            name: m.attr("name"),
            image: new Array
         };
         try {
            for (var x = 0; x < m.image.length; x++) {
               me.theme.icons.map[i].image[parseInt(m.image[x].attr("code"), 10)] = {
                  name: m.image[x].attr("name")
               };
            }
         }
         catch (err) { }
      }
      if (typeof (settingsXml.icons[0].moon) == "undefined") {
         me.theme.icons.moon = { enabled: false };
      }
      else {
         me.theme.icons.moon = {
            enabled: true,
            folder: settingsXml.icons[0].moon[0].folder ? settingsXml.icons[0].moon[0].folder[0].Text : "",
            image: new Array
         };
         try {
            for (var x = 0; x < settingsXml.icons[0].moon[0].map[0].image.length; x++) {
               me.theme.icons.moon.image[parseInt(settingsXml.icons[0].moon[0].map[0].image[x].attr("code"), 10)] =
                            { name: settingsXml.icons[0].moon[0].map[0].image[x].attr("name") };
            }
         }
         catch (err) { }
      }
      // theme
      var i = me.themeIndex;
      me.theme.loadedThemeIndex = i;
      var themeXml = settingsXml.themes[0].theme[i];
      me.theme.name = themeXml.attr("name") ? themeXml.attr("name") : "";
      me.theme.selector = themeXml.selector ? themeXml.selector[0].Text : "body";
      me.theme.callback = {
         onInitialize: themeXml.callback[0].onInitialize ? themeXml.callback[0].onInitialize[0].Text : "",
         onRefreshStart: themeXml.callback[0].onRefreshStart ? themeXml.callback[0].onRefreshStart[0].Text : "",
         onRefreshEnd: themeXml.callback[0].onRefreshEnd ? themeXml.callback[0].onRefreshEnd[0].Text : ""
      };
      // sky image settings
      if (typeof (themeXml.skyImage) == "undefined") {
         me.theme.skyImage = { enabled: false };
      }
      else {
         me.theme.skyImage = {
            enabled: true,
            folder: themeXml.skyImage[0].folder ? themeXml.skyImage[0].folder[0].Text : "",
            image: new Array
         };
         try {
            for (var x = 0; x < themeXml.skyImage[0].map[0].image.length; x++) {
               me.theme.skyImage.image[parseInt(themeXml.skyImage[0].map[0].image[x].attr("code"), 10)] =
                            { name: themeXml.skyImage[0].map[0].image[x].attr("name") };
            }
         }
         catch (err) { }
      }
      // time based image settings
      if (typeof (themeXml.timeImage) == "undefined") {
         me.theme.timeImage = { enabled: false };
      }
      else {
         me.theme.timeImage = {
            enabled: true,
            folder: themeXml.timeImage[0].folder ? themeXml.timeImage[0].folder[0].Text : "",
            image: new Array
         };
         try {
            for (var x = 0; x < themeXml.timeImage[0].map[0].image.length; x++) {
               me.theme.timeImage.image[parseInt(themeXml.timeImage[0].map[0].image[x].attr("code"), 10)] =
                            { name: themeXml.timeImage[0].map[0].image[x].attr("name") };
            }
         }
         catch (err) { }
      }
      // save theme state
      //_tools.setState("theme_" + me.themeIndex, JSON.stringify(me.theme));
      // set the weather data source
      me.weatherSource = "wedadotcom";
      me.source = new wedadotcom(me);
      // callback
      callback();
   };

   // ***********************************
   this.getWeatherData = function (force, callback) {
      //_tools.log("themePumpSettings.getWeatherData()");
      var cache = _tools.getState("city_" + me.cityIndex);
      if (cache != null && cache != "") {
         me.data = JSON.parse(cache);
      }
      if (typeof (me.data) == "undefined" || me.data == null || me.data == "") {
         me.data = new wedaData(_pump.settings);
      }
      if (force || me.data.location.code != me.cityList[me.cityIndex].code) {
         _pump.themeCallback(me.theme.callback.onRefreshStart);
         me.source.fetchData(me.data, function (data) {
            me.saveWeatherData(data, callback);
         });
      }
      else {
         callback();
      }
   };

   // ***********************************
   this.saveWeatherData = function (data, callback) {
      //_tools.log("themePumpSettings.saveWeatherData()");
      me.data = data;
      _tools.setState("city_" + me.cityIndex, JSON.stringify(me.data));
      _pump.themeCallback(me.theme.callback.onRefreshEnd);
      callback();
   };

}

//*************************************************************************************************
//*************************************************************************************************

function wedaData(settings) {

   this.success = false;

   d = new Date();
   d.setDate(d.getDate() - 1);         // set the intial refresh time to one day in the past
   this.refreshTime = d.getTime();

   this.updateTime = "";
   this.updateDate = "";
   this.degreeSymbol = "";

   this.location = { code: "",
      name: "...",
      asOfDate: "",
      asOfDateRaw: new Date(),
      asOfTime: "",
      asOfText: "",
      station: "",
      sunrise: "6:00 AM",
      sunset: "9:00 PM",
      UtcOffset: -d.getTimezoneOffset() / 60
   };
   if (settings.metric) {
      this.units = { temp: "C", distance: "km", speed: "km/h", pressure: "mb" };
   } else {
      this.units = { temp: "F", distance: "mi", speed: "mph", pressure: "in" };
   }

   this.cc = {
      apparentTemp: "",
      barometer: { reading: "", direction: "" },
      dewpoint: "",
      humidity: "",
      icon: "99",
      sky: "99",
      time: "0",
      moon: { icon: 0, text: "", pct: 0, nextPhase: "", nextPhaseDate: "", nextPhaseTime: "" },
      precip: "",
      temp: "",
      text: "",
      uv: { index: "", text: "" },
      visibility: "",
      wind: { speed: "", degrees: "", direction: "", text: "" }
   };

   this.forecast = { asOfText: "", day: [{}] };
   this.forecast.day.length = 7;
   for (var i = 0; i < 7; i++) {
      this.forecast.day[i] = {
         sequence: i + 1,
         name: "",
         date: "",
         high: "",
         low: "",
         sunrise: "",
         sunset: "",
         daytime: { icon: "99", text: "", precip: "", humidity: "", wind: { speed: "", degrees: "", direction: ""} },
         nighttime: { icon: "99", text: "", precip: "", humidity: "", wind: { speed: "", degrees: "", direction: ""} },
         moon: { icon: 0, text: "", pct: 0 }
      }
   }
}

//*************************************************************************************************
//*************************************************************************************************

function themePumpTools() {

   this.setState = function (key, contents) {
      //_tools.log("themePumpTools setState key = " + key);
      if (_pump.settings.platform != 'cydget') return;
      //      _tools.ensureCacheFolder();
      //      if (contents == null) contents = "";
      //      objc_msgSend(contents, new Selector("writeToFile:atomically:"), "/User/Library/wedaPanel/cache/" + key + ".wedaPanel", YES);
   };

   this.getState = function (key) {
      //_tools.log("themePumpTools getState");
      if (_pump.settings.platform != 'cydget') return "";
      //      var r = objc_msgSend(NSString, new Selector("stringWithContentsOfFile:"), "/User/Library/wedaPanel/cache/" + key + ".wedaPanel");
      //      if (r == null) r = "";
      //      return r;
   };

   this.ensureCacheFolder = function () {
      //_tools.log("themePumpTools ensureCacheFolder");
      if (_pump.settings.platform != 'cydget') return;
      //      manager = objc_msgSend(NSFileManager, new Selector("defaultManager"));
      //      if (!objc_msgSend(manager, new Selector("fileExistsAtPath:"), "/User/Library/wedaPanel/cache")) {
      //         objc_msgSend(manager, new Selector("createDirectoryAtPath:withIntermediateDirectories:attributes:error:"), "/User/Library/wedaPanel/cache", YES, NULL, NULL)
      //      }
   };

   this.log = function (msg) {
      if (_log) {
         var d = new Date();
         $("#testmode").html("[" + d.toTimeString().split(" ")[0] + "] " + msg + "<br>" + $("#testmode").html());
      }
   };

   this.loadFile = function (filename, filetype) {
      if (filetype == "js") {
         var fileref = document.createElement("script");
         fileref.setAttribute("type", "text/javascript");
         fileref.setAttribute("src", filename);
      }
      else if (filetype == "css") {
         var fileref = document.createElement("link");
         fileref.setAttribute("rel", "stylesheet");
         fileref.setAttribute("type", "text/css");
         fileref.setAttribute("href", filename);
      }
      if (typeof (fileref) != "undefined")
         document.getElementsByTagName("head")[0].appendChild(fileref);
   };

   this.getFormattedDate = function (date) {
      var ds = date.toLocaleDateString();
      var dp = ds.split(" ");
      for (i in dp) {
         dp[i] = dp[i].replace(/[,.:;]/g, "");
         ds = ds.replace(dp[i], _pump.translate(dp[i]));
      }
      return ds;
   };

   this.getFormattedDateShort = function (date) {
      var ds = date.toLocaleDateString();
      var dp = ds.split(" ");
      for (var i = 0; i < 2; i++) {
         dp[i] = dp[i].replace(/[,.:;]/g, "");
         ds = ds.replace(dp[i], _pump.translate(dp[i].slice(0, 3)));
      }
      return ds;
   };

   // extract the time from the date and return it formatted as 12 or 24 hour time, depending on the settings
   this.getFormattedTime = function (date) {
      //_tools.log("tools.getFormattedTime()");
      var h = "00" + date.getHours().toString();
      h = h.substr(h.length - 2, 2);
      var m = "00" + date.getMinutes().toString();
      m = m.substr(m.length - 2, 2);
      var t = h + ":" + m;
      if (_pump.settings.clock == "12") {
         t = this.format12HourTime(t);
      }
      return t;
   };

   this.getOffsetDate = function (date, offset) {
      //_tools.log("tools.getOffsetDate date = " + date + " offset = " + offset);
      // determine utc time
      var lt = date.getTime();
      var lo = date.getTimezoneOffset() * 60000;
      var ut = lt + lo;
      // apply offset
      var so = offset * 3600000;
      var st = ut + so;
      var d = new Date(st);
      return d;
   }

   // parse a time string and set the time in the given date.
   // return the time (the number of milliseconds since midnight of January 1, 1970)
   this.parseTime = function (date, timeString) {
      var d = new Date();
      d.setTime(date.getTime());
      var timeComponents = this.parseTimeComponents(timeString);
      d.setHours(timeComponents.hours, timeComponents.minutes);
      return d.getTime();
   }

   // parse a time string into it's hours and minutes components
   this.parseTimeComponents = function (timeString) {
      var t = timeString.split(":");
      var h = t[0].split(" ");
      h = parseInt(h[h.length - 1], 10);
      var m = 0;
      if (t.length > 2) {
         m = parseInt(t[1], 10);
         t = t[2].split(" ");
      }
      else {
         t = t[1].split(" ");
         m = parseInt(t[0], 10);
      }
      // convert hours if the time string is in 12 hour format
      var s = t[1];
      if (typeof (s) != "undefined") {
         if (s == "AM") {
            if (h == 12) h = 0;
         } else {
            if (h < 12) h = h + 12;
         }
      }
      return { hours: h, minutes: m };
   };

   // parse the time string and return a new string formatted as 24 hour time
   this.format24HourTime = function (timeString) {
      var timeComponents = this.parseTimeComponents(timeString);
      return timeComponents.hours.toString() + ":" + timeComponents.minutes.toString();
   };

   // parse the time string and return a new string formatted as 12 hour time
   this.format12HourTime = function (time) {
      var t = time.split(":");
      var hour = parseInt(t[0], 10);
      var h = "";
      var suffix = "AM";
      if (hour == 0) {
         h = "12";
      }
      else if (hour > 11) {
         suffix = "PM";
         if (hour > 12) {
            h = hour - 12;
         }
         else {
            h = hour;
         }
      }
      else {
         h = hour;
      }
      return h + ":" + t[1] + " " + suffix;
   };

   this.capitalize = function (text) {
      var str = text.toLowerCase();
      var rx = /\b([a-z]+)\b/ig;
      str = str.replace(rx, function (w) {
         return w.charAt(0).toUpperCase() + w.substring(1);
      });
      return str;
   };

   this.setCookie = function (name, value, days) {
      if (days) {
         var date = new Date();
         date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
         var expires = "; expires=" + date.toGMTString();
      }
      else var expires = "";
      document.cookie = name + "=" + value + expires + "; path=/";
   };

   this.getCookie = function (name) {
      var nameEQ = name + "=";
      var ca = document.cookie.split(';');
      for (var i = 0; i < ca.length; i++) {
         var c = ca[i];
         while (c.charAt(0) == ' ') c = c.substring(1, c.length);
         if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
      }
      return null;
   };

   this.eraseCookie = function (name) {
      createCookie(name, "", -1);
   };

}

//*************************************************************************************************
//*************************************************************************************************

// **********************************
// wĕdadotcom - weather.com interface
// author: storyr
// **********************************
function wedadotcom(settings) {

   this.fetchData = function (currentData, callback) {
      //_tools.log("wedadotcom.fetchData() " + settings.cityList[settings.cityIndex].code);
      var url = "http://yahoowidget.weather.com/weather/local/" +
            settings.cityList[settings.cityIndex].code + "?cc=*&dayf=7&hbhf=2&unit=" + (settings.metric ? "m" : "c");
      try {
         var xml_request = new XMLHttpRequest();
         xml_request.open("GET", url);
         if ($.browser.webkit) {
            xml_request.overrideMimeType("text/xml");
         } else {
            xml_request.setRequestHeader("Content-Type", "text/xml");
         }
         xml_request.onreadystatechange = function (e) {
            if (xml_request.readyState == 4) {
               if (xml_request.status == 200) {
                  var adapter = new wedadotcomAdapter(settings);
                  callback(adapter.adapt(currentData, xml_request.responseXML));
               } else {
                  // not successful - try again in 1 minute
                  var d = new Date();
                  var interval = Math.max(_pump.settings.refreshInterval - 1, 1) * 60000;
                  _pump.settings.data.refreshTime = d.getTime() - interval;
                  callback(currentData);
               }
            }
         }
         xml_request.setRequestHeader("Cache-Control", "no-cache");
         xml_request.send(null);
      }
      catch (err) {
         _tools.log("wedadotcom.fetchData[error caught]");
         return false;
      }
      return true;
   };
}

function wedadotcomAdapter(settings) {

   this.adapt = function (currentData, xmlData) {

      var data = $.xmlToJSON(xmlData);
      var wd = currentData;

      if (typeof (data.error) !== "undefined") {
         _tools.log("wedadotcomAdapter[fail]");
         wd.location.name = data.error[0].err[0].Text;
         return wd;
      }

      wd.degreeSymbol = String.fromCharCode(176);
      wd.units.temp = data.head[0].ut[0].Text;
      wd.units.distance = data.head[0].ud[0].Text;
      wd.units.speed = data.head[0].us[0].Text;
      wd.units.pressure = data.head[0].up[0].Text;

      wd.location.code = settings.cityList[settings.cityIndex].code;
      wd.location.name = data.loc[0].dnam[0].Text.split(",")[0];
      wd.location.station = data.cc[0].obst[0].Text;

      var d = new Date();
      // <lsup>9/22/10 5:20 AM Local Time</lsup>
      var lsup = data.cc[0].lsup[0].Text.split(" ", 3);
      d.setTime(Date.parse(lsup[0] + " " + lsup[1] + " " + lsup[2]));
      var t = new Date();
      d.setFullYear(t.getFullYear());

      wd.location.asOfText = d.toLocaleString();
      wd.location.asOfTime = _tools.getFormattedTime(d);
      wd.location.asOfDate = d.toLocaleDateString();
      wd.location.asOfDateRaw = d;

      d.setTime(Date.parse(t.toDateString() + " " + data.loc[0].sunr[0].Text));
      wd.location.sunrise = _tools.getFormattedTime(d);
      d.setTime(Date.parse(t.toDateString() + " " + data.loc[0].suns[0].Text));
      wd.location.sunset = _tools.getFormattedTime(d);

      wd.location.UtcOffset = parseFloat(data.loc[0].zone[0].Text, 10);
      // determine if there is an additional offset adjustment needed
      // (based on weather source local time - some times are 30 minutes off normal)
      var d = new Date();
      var d1 = _tools.getOffsetDate(d, wd.location.UtcOffset);
      var lt = _tools.format24HourTime(data.loc[0].tm[0].Text).split(":");
      var d2 = new Date;
      d2.setFullYear(d1.getFullYear(), d1.getMonth(), d1.getDate());
      d2.setHours(parseInt(lt[0]), parseInt(lt[1]));
      var diff = parseFloat(((d2 - d1) / 3600000).toFixed(1));
      //        _tools.log(">>>>>>>>> UtcOffset = " + wd.location.UtcOffset);
      //        _tools.log(">>>>>>>>> d1 = " + d1);
      //        _tools.log(">>>>>>>>> lt = " + lt);
      //        _tools.log(">>>>>>>>> d2 = " + d2);
      //        _tools.log(">>>>>>>>> diff = " + diff);
      if (diff > 0 && diff < 1) {
         wd.location.UtcOffset = wd.location.UtcOffset + diff;
      }

      wd.cc.apparentTemp = data.cc[0].flik[0].Text;
      wd.cc.barometer.direction = data.cc[0].bar[0].d[0].Text;
      wd.cc.barometer.reading = data.cc[0].bar[0].r[0].Text;
      wd.cc.dewpoint = data.cc[0].dewp[0].Text;
      wd.cc.humidity = data.cc[0].hmid[0].Text;
      wd.cc.icon = iconMap[parseInt(data.cc[0].icon[0].Text, 10)];

      var moon = _pump.luna.getPhase(wd.location.asOfDateRaw);
      wd.cc.moon.pct = moon.pct;
      wd.cc.moon.icon = moon.icon;
      wd.cc.moon.text = moon.text;
      wd.cc.moon.nextPhase = moon.nextPhase;
      wd.cc.moon.nextPhaseDate = moon.nextPhaseDate;
      wd.cc.moon.nextPhaseTime = moon.nextPhaseTime;

      wd.cc.precip = data.hbhf[0].hour[0].ppcp[0].Text;
      wd.cc.temp = data.cc[0].tmp[0].Text;
      wd.cc.text = data.cc[0].t[0].Text;
      wd.cc.uv.index = data.cc[0].uv[0].i[0].Text;
      wd.cc.uv.text = data.cc[0].uv[0].t[0].Text;
      wd.cc.visibility = data.cc[0].vis[0].Text.split(".0", 1)[0];
      wd.cc.wind.degrees = data.cc[0].wind[0].d[0].Text;
      wd.cc.wind.direction = data.cc[0].wind[0].t[0].Text;
      wd.cc.wind.speed = data.cc[0].wind[0].s[0].Text;

      var fd = new Date();
      var day = 90000000; // milliseconds in a day + one hour (in case of dst)

      wd.forecast.asOfText = data.dayf[0].lsup[0].Text;

      for (var i = 0; i < data.dayf[0].day.length; i++) {

         var lsup = data.cc[0].lsup[0].Text.split(" ", 3);
         fd.setTime(Date.parse(lsup[0] + " " + lsup[1] + " " + lsup[2]));
         var t = new Date();
         fd.setFullYear(t.getFullYear());

         // the damn forecast date has no year, so start with the observed date
         //         if (i == 0) {
         //            var ds = data.dayf[0].lsup[0].Text.split(" ", 1)[0];
         //            ds = ds.split("/");
         //            ds = ds = ds[0] + "/" + ds[1] + "/20" + ds[2];
         //            fd.setTime(Date.parse(ds));
         //         }
         //         else {
         //            fd.setTime(fd.getTime() + day);
         //         }

         var wfd = wd.forecast.day[i];
         var ddd = data.dayf[0].day[i];

         wfd.sequence = i + 1;
         wfd.name = ddd.attr("t");
         wfd.date = ddd.attr("dt");
         wfd.high = handleNA(wfd.high, ddd.hi[0].Text);
         wfd.low = handleNA(wfd.low, ddd.low[0].Text);

         var d = new Date();
         d.setTime(Date.parse(t.toDateString() + " " + ddd.sunr[0].Text));
         wfd.sunrise = _tools.getFormattedTime(d);
         d.setTime(Date.parse(t.toDateString() + " " + ddd.suns[0].Text));
         wfd.sunset = _tools.getFormattedTime(d);

         var moon = _pump.luna.getPhase(fd);
         wfd.moon.pct = moon.pct;
         wfd.moon.icon = moon.icon;
         wfd.moon.text = moon.text;

         for (var dp = 0; dp < ddd.part.length; dp++) {
            var prt = ddd.part[dp];
            switch (prt.attr("p")) {
               case "d":
                  var dayPart = wfd.daytime;
                  break;
               case "n":
                  var dayPart = wfd.nighttime;
                  break;
            }
            if (prt.icon[0].Text.toString() != "44" || (prt.icon[0].Text.toString() == "44" && dayPart.icon.toString() == "99")) {
               dayPart.icon = iconMap[parseInt(prt.icon[0].Text, 10)];
            }

            dayPart.text = handleNA(dayPart.text, prt.t[0].Text);
            dayPart.precip = handleNA(dayPart.precip, prt.ppcp[0].Text);
            dayPart.humidity = handleNA(dayPart.humidity, prt.hmid[0].Text);
            dayPart.wind.speed = handleNA(dayPart.wind.speed, prt.wind[0].s[0].Text);
            dayPart.wind.degrees = handleNA(dayPart.wind.degrees, prt.wind[0].d[0].Text);
            dayPart.wind.direction = handleNA(dayPart.wind.direction, prt.wind[0].t[0].Text);
         }
      }

      // update the refresh time
      var d = new Date();
      wd.refreshTime = d.getTime();
      wd.updateDate = _tools.getFormattedDate(d);
      wd.updateTime = _tools.getFormattedTime(d);

      //_tools.log("wedadotcomAdapter[succeed]");
      wd.success = true;
      return wd;
   };

   function handleNA(target, source) {
      //_tools.log("handleNA target = " + target + " source = " + source);
      //_tools.log("handleNA source* = " + source.toString().toLowerCase());
      if (source.toString().toLowerCase() != "n/a") {
         return source;
      }
      // disabled until we can cache data - it was using other cities data
      //if (typeof (target) == "undefined" || target == "") {
      return "~"
      //}
      //else {
      //   return target;
      //}
   };

   var iconMap =
    [
        "00",    // 0 tornado 
        "01",    // 1 tropical storm 
        "02",    // 2 hurricane 
        "03",    // 3 severe thunderstorms 
        "04",    // 4 thunderstorms 
        "05",    // 5 mixed rain and snow 
        "06",    // 6 mixed rain and sleet 
        "07",    // 7 mixed snow and sleet 
        "08",    // 8 freezing drizzle 
        "09",    // 9 drizzle 
        "10",    // 10 freezing rain 
        "11",    // 11 showers / light rain              **** 
        "12",    // 12 heavy rain                        **** 
        "13",    // 13 snow flurries 
        "14",    // 14 light snow showers 
        "15",    // 15 snowflakes                        **** 
        "16",    // 16 snow 
        "17",    // 17 thunderstorms                     ****
        "18",    // 18 hail                              **** 
        "19",    // 19 dust 
        "20",    // 20 foggy 
        "21",    // 21 haze 
        "22",    // 22 smoky 
        "23",    // 23 blustery 
        "24",    // 24 windy 
        "25",    // 25 frigid                            **** 
        "26",    // 26 cloudy 
        "27",    // 27 mostly cloudy (night) 
        "28",    // 28 mostly cloudy (day) 
        "29",    // 29 partly cloudy (night) 
        "30",    // 30 partly cloudy (day) 
        "31",    // 31 clear (night) 
        "32",    // 32 sunny
        "33",    // 33 fair (night) 
        "34",    // 34 fair (day) 
        "35",    // 35 thunderstorms                     **** 
        "36",    // 36 hot 
        "37",    // 37 isolated thunderstorms (day)
        "38",    // 38 scattered thunderstorms 
        "39",    // 39 scattered rain (day)              **** 
        "40",    // 40 heavy rain                        **** 
        "41",    // 41 scattered snow showers            ****
        "42",    // 42 heavy snow                        ****
        "43",    // 43 windy/snowy                       ****
        "44",    // 44 N/A
        "45",    // 45 scattered showers (night)         **** 
        "46",    // 46 snow showers (night)              ****
        "47",    // 47 isolated thundershowers (night)   ****
        "99",    // N/A
    ];
}

// ********************************
// accuwĕda - AccuWeather interface
// author: storyr
// ********************************
//function accuweda(settings) {

//   this.fetchData = function (callback) {

//      //_tools.log("accuweda.fetchData");

//      var url = "http://wu.apple.com/adcbin/apple/Apple_Weather_Data.asp?zipcode=" +
//            settings.weatherLocation + "&metric=" + (settings.metric ? "1" : "0");
//      if (settings.testMode) url = "weda/pump/script/accuwedaTest.xml";
//      try {
//         var xml_request = new XMLHttpRequest();
//         xml_request.open("GET", url);
//         if ($.browser.webkit) {
//            xml_request.overrideMimeType("text/xml");
//         } else {
//            xml_request.setRequestHeader("Content-Type", "text/xml");
//         }
//         xml_request.onreadystatechange = function (e) {
//            if (xml_request.readyState == 4) {
//               if (xml_request.status == 200) {
//                  var adapter = new accuwedaAdapter(settings);
//                  callback(adapter.adapt(currentData, xml_request.responseXML));
//               } else {
//                  // not successful - try again in 1 minute
//                  var d = new Date();
//                  var interval = Math.max(_pump.settings.refreshInterval - 1, 1) * 60000;
//                  _pump.settings.data.refreshTime = d.getTime() - interval;
//                  callback(currentData);
//               }
//            }
//         }
//         xml_request.setRequestHeader("Cache-Control", "no-cache");
//         xml_request.send(null);
//      }
//      catch (err) {
//         _tools.log("accuweda.fetchData[error caught]");
//         return false;
//      }
//      return true;
//   };
//}

//function accuwedaAdapter(settings) {

//   this.adapt = function (currentData, xmlData) {

//      var data = $.xmlToJSON(xmlData);
//      var wd = currentData;

//      if (typeof (data.failure) !== "undefined") {
//         _tools.log("accuwedaAdapter[fail]");
//         wd.location.name = data.failure.Text;
//         return wd;
//      }

//      wd.degreeSymbol = String.fromCharCode(176);

//      wd.location.code = settings.weatherLocation;
//      wd.location.name = data.CurrentConditions[0].City[0].Text;
//      wd.location.asOfTime = data.CurrentConditions[0].Time[0].Text;
//      wd.location.asOfDate = data.Forecast[0].day[0].ObsDate[0].Text;
//      wd.location.sunrise = data.Planets[0].Sun[0].attr("rise");
//      wd.location.sunset = data.Planets[0].Sun[0].attr("set");
//      wd.location.UtcOffset = parseInt(data.GmtDiff[0].Text, 10);

//      wd.cc.apparentTemp = data.CurrentConditions[0].RealFeel[0].Text;
//      wd.cc.barometer.direction = data.CurrentConditions[0].Pressure[0].attr("state");
//      wd.cc.barometer.reading = data.CurrentConditions[0].Pressure[0].Text;
//      wd.cc.dewpoint = "";
//      wd.cc.humidity = parseInt(data.CurrentConditions[0].Humidity[0].Text.replace("%", ""), 10).toString();
//      wd.cc.icon = iconMap[parseInt(data.CurrentConditions[0].WeatherIcon[0].Text, 10)];

//      var d = new Date();
//      d.setTime(Date.parse(wd.location.asOfDate));
//      var moon = _pump.luna.getPhase(d);
//      wd.cc.moon.pct = moon.pct;
//      wd.cc.moon.icon = moon.icon;
//      wd.cc.moon.text = moon.text;
//      wd.cc.moon.nextPhase = moon.nextPhase;
//      wd.cc.moon.nextPhaseDate = moon.nextPhaseDate;
//      wd.cc.moon.nextPhaseTime = moon.nextPhaseTime;

//      wd.cc.precip = parseInt(data.CurrentConditions[0].Precip[0].Text, 10);
//      wd.cc.temp = data.CurrentConditions[0].Temperature[0].Text;
//      wd.cc.text = _tools.capitalize(data.CurrentConditions[0].WeatherText[0].Text);
//      wd.cc.uv.index = data.CurrentConditions[0].UVIndex[0].Text;
//      wd.cc.uv.text = "";
//      wd.cc.visibility = data.CurrentConditions[0].Visibility[0].Text;
//      wd.cc.wind.degrees = "";
//      wd.cc.wind.direction = data.CurrentConditions[0].WindDirection[0].Text;
//      wd.cc.wind.speed = data.CurrentConditions[0].WindSpeed[0].Text;

//      if (settings.clock == "12") {
//         wd.location.asOfTime = _tools.format12HourTime(wd.location.asOfTime);
//         wd.location.sunrise = _tools.format12HourTime(wd.location.sunrise);
//         wd.location.sunset = _tools.format12HourTime(wd.location.sunset);
//         wd.cc.moon.nextPhaseTime = _tools.format12HourTime(wd.cc.moon.nextPhaseTime);
//      }

//      for (var i = 0; i < data.Forecast[0].day.length; i++) {
//         var wfd = wd.forecast.day[i];
//         wfd.sequence = i + 1;
//         wfd.name = data.Forecast[0].day[i].DayCode[0].Text;
//         wfd.date = data.Forecast[0].day[i].ObsDate[0].Text;
//         wfd.high = data.Forecast[0].day[i].High_Temperature[0].Text;
//         wfd.low = data.Forecast[0].day[i].Low_Temperature[0].Text;
//         wfd.sunrise = "n/a"; // not available from accuweather
//         wfd.sunset = "n/a";  // not available from accuweather

//         d.setTime(Date.parse(wfd.date));
//         var moon = _pump.luna.getPhase(d);
//         wfd.moon.pct = moon.pct;
//         wfd.moon.icon = moon.icon;
//         wfd.moon.text = moon.text;

//         wfd.daytime.icon = iconMap[parseInt(data.Forecast[0].day[i].WeatherIcon[0].Text, 10)];
//         wfd.daytime.text = data.Forecast[0].day[i].TXT_Short[0].Text;
//         wfd.daytime.precip = "n/a";
//         //wfd.daytime.precip = data.Forecast[0].day[i].TStorm_Prob[0].Text;
//         wfd.daytime.humidity = "n/a";
//         wfd.daytime.wind.speed = data.Forecast[0].day[i].WindSpeed[0].Text;
//         wfd.daytime.wind.degrees = "n/a";
//         wfd.daytime.wind.direction = data.Forecast[0].day[i].WindDirection[0].Text;

//         // accuweather doesn't supply nighttime forecast data
//         wfd.nighttime.icon = iconMap[0];
//         wfd.nighttime.text = "n/a";
//         wfd.nighttime.precip = "n/a";
//         wfd.nighttime.humidity = "n/a";
//         wfd.nighttime.wind.speed = "n/a";
//         wfd.nighttime.wind.degrees = "n/a";
//         wfd.nighttime.wind.direction = "n/a";
//      }

//      // update the refresh time (e.g. Mon Oct 19 15:46:58 PDT 2009)
//      var d = new Date();
//      wd.refreshTime = d.getTime();
//      wd.updateDate = _tools.getFormattedDate(d);
//      wd.updateTime = _tools.getFormattedTime(d);

//      wd.success = true;
//      return wd;
//   };

//   var iconMap =
//    [
//        "99",    // 00 ?                                    => not available
//        "32",    // 01 Sunny                                => 32 sunny
//        "34",    // 02 Mostly Sunny                         => 34 fair (day) 
//        "30",    // 03 Partly Sunny                         => 30 partly cloudy (day)
//        "30",    // 04 Intermittent Clouds                  => 30 partly cloudy (day) 
//        "21",    // 05 Hazy Sunshine                        => 21 haze 
//        "28",    // 06 Mostly Cloudy                        => 28 mostly cloudy (day) 
//        "26",    // 07 Cloudy (am/pm)                       => 26 cloudy 
//        "26",    // 08 Dreary (am/pm)                       => 26 cloudy 
//        "99",    // 09 retired                              => not available 
//        "99",    // 10 retired                              => not available
//        "20",    // 11 fog (am/pm)                          => 20 foggy
//        "11",    // 12 showers (am/pm)                      => 11 showers / light rain
//        "39",    // 13 Mostly Cloudy with Showers           => 39 scattered rain (day)
//        "39",    // 14 Partly Sunny with Showers            => 39 scattered rain (day)
//        "17",    // 15 Thunderstorms (am/pm)                => 17 thunderstorms
//        "37",    // 16 Mostly Cloudy with Thunder Showers   => 37 isolated thunderstorms (day)
//        "37",    // 17 Partly Sunny with Thunder Showers    => 37 isolated thunderstorms (day)
//        "11",    // 18 Rain (am/pm)                         => 12 heavy rain 
//        "13",    // 19 Flurries (am/pm)                     => 13 snow flurries
//        "41",    // 20 Mostly Cloudy with Flurries          => 41 scattered snow showers
//        "41",    // 21 Partly Sunny with Flurries           => 41 scattered snow showers
//        "16",    // 22 Snow (am/pm)                         => 16 snow
//        "16",    // 23 Mostly Cloudy with Snow              => 16 snow
//        "25",    // 24 Ice (am/pm)                          => 25 frigid
//        "06",    // 25 Sleet (am/pm)                        => 6 mixed rain and sleet 
//        "10",    // 26 Freezing Rain (am/pm)                => 10 freezing rain 
//        "99",    // 27 retired                              => not available 
//        "99",    // 28 retired                              => not available
//        "05",    // 29 Rain and Snow Mixed (am/pm)          => 5 mixed rain and snow 
//        "36",    // 30 Hot (am/pm)                          => 36 hot
//        "25",    // 31 Cold (am/pm)                         => 25 frigid 
//        "24",    // 32 Windy (am/pm)                        => 24 windy 
//        "31",    // 33 Clear                                => 31 clear (night) 
//        "33",    // 34 Mostly Clear                         => 33 fair (night) 
//        "29",    // 35 Partly Cloudy                        => 29 partly cloudy (night) 
//        "29",    // 36 Intermittent Clouds                  => 29 partly cloudy (night) 
//        "22",    // 37 Hazy                                 => 22 smoky 
//        "27",    // 38 Mostly Cloudy                        => 27 mostly cloudy (night)
//        "45",    // 39 Partly Cloudy with Showers           => 45 scattered showers (night) 
//        "45",    // 40 Mostly Cloudy with Showers           => 45 scattered showers (night) 
//        "47",    // 41 Partly Cloudy with Thunder Showers   => 47 isolated thundershowers (night) 
//        "47",    // 42 Mostly Cloudy with Thunder Showers   => 47 isolated thundershowers (night) 
//        "46",    // 43 Mostly Cloudy with Flurries          => 46 snow showers (night) 
//    ];
//}

// ********************************
// XML to JSON jQuery plugin
// ********************************
/*
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
Author: Sam Tsvilik
Version: 4.0 Beta
Last Modified: 08/29/2009
*/
(function ($) {
   //Converts XML DOM to JSON				
   //Helper functions
   var util = {
      isIE: function () { return (+"\0" === 0); },
      isStr: function (o) { return typeof (o) === "string"; },
      isFn: function (o) { return typeof (o) === "function"; },
      isDef: function (o) { return (typeof (o) !== "undefined"); },
      isArr: function (o) { return o instanceof Array; },
      isInt: function (o) { return o instanceof Number && !isNaN(o); },
      isNum: function (s) {
         var out = false;
         if (util.isStr(s)) {
            var pattern = /^((-)?([0-9]*)((\.{0,1})([0-9]+))?$)/;
            out = pattern.test(s);
         }
         return out;
      },
      isXNode: function (o) { return (typeof (o) === "object" && this.isDef(o.nodeName)); },
      isNodeSet: function (o) { return o instanceof INodeSet; },
      //Alters attribute and collection names to comply with JS
      trim: function (str) {
         var out = str;
         if (this.isStr(str)) {
            out = str.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
         }
         return out;
      },
      formatName: function (name) {
         var tName = this.trim(String(name));
         return tName;
      }
   };

   var XMLSerializer = {
      //Creates an XMLDomDocument instance
      newDocument: function (rootTagName, namespaceURL) {
         if (!rootTagName) rootTagName = "";
         if (!namespaceURL) namespaceURL = "";
         if (document.implementation && document.implementation.createDocument) {
            // This is the W3C standard way to do it
            return document.implementation.createDocument(namespaceURL, rootTagName, null);
         } else { // This is the IE way to do it
            // Create an empty document as an ActiveX object
            // If there is no root element, this is all we have to do
            var doc = new ActiveXObject("MSXML2.DOMDocument");
            // If there is a root tag, initialize the document
            if (rootTagName) {
               // Look for a namespace prefix
               var prefix = "";
               var tagname = rootTagName;
               var p = rootTagName.indexOf(':');
               if (p !== -1) {
                  prefix = rootTagName.substring(0, p);
                  tagname = rootTagName.substring(p + 1);
               }
               // If we have a namespace, we must have a namespace prefix
               // If we don't have a namespace, we discard any prefix
               if (namespaceURL) {
                  if (!prefix) prefix = "a0"; // What Firefox uses
               } else prefix = "";
               // Create the root element (with optional namespace) as a
               // string of text
               var text = "<" + (prefix ? (prefix + ":") : "") + tagname +
				  (namespaceURL
				   ? (" xmlns:" + prefix + '="' + namespaceURL + '"')
				   : "") +
				  "/>";
               // And parse that text into the empty document
               doc.loadXML(text);
            }
            return doc;
         }
      },
      //Recursively converts JSON object to an XML node
      objToNode: function (curNode, obj) {
         var subElement, val, newNode;
         if (util.isDef(curNode) && util.isDef(obj)) {
            for (subElement in obj) {
               if (obj.hasOwnProperty && obj.hasOwnProperty(subElement)) {
                  val = obj[subElement];
                  if (subElement.indexOf("@") !== -1) {
                     curNode.setAttribute(subElement.replace('@', ''), val);
                  } else if (subElement === "$comments") {
                     if (!!val.length) {
                        var c = 0, clen = val.length - 1, cc;
                        do {
                           cc = val[c];
                           curNode.appendChild(this.createComment(cc));
                        } while (c++ < clen);
                     }
                  } else if (util.isNodeSet(val)) {
                     var n = 0, nlen = val.length - 1, nn;
                     do {
                        nn = val[n];
                        if (!!nn.ns) {
                           if (util.isDef(this.createElementNS)) {
                              newNode = curNode.appendChild(this.createElementNS(nn.ns, subElement));
                           } else {
                              newNode = curNode.appendChild(this.createNode(1, subElement, nn.ns));
                           }
                        } else {
                           newNode = curNode.appendChild(this.createElement(subElement));
                        }
                        if (!!nn.Text) { newNode.appendChild(util.isDef(nn.hasCDATA) ? this.createCDATASection(nn.Text) : this.createTextNode(nn.Text)); }
                        XMLSerializer.objToNode.call(this, newNode, nn);
                     } while (n++ < nlen);
                  }
               }
            }
         }
      }
   };
   //Base child element
   var IChild = function (parent) {
      this.parent = parent || null;
   };
   //Root Node Class
   var IRoot = function (name) {
      this.nodeName = name || "";
      this.ns = "";
   };
   //Node Class
   var INode = function () {
      var parent = null, name = null, value = null;
      switch (arguments.length) {
         case 1: name = arguments[0]; break;
         case 2: parent = arguments[0]; name = arguments[1]; break;
         case 3: parent = arguments[0]; name = arguments[1]; value = arguments[2]; break;
         default: name = "noname";
      }
      IRoot.apply(this, [name]);
      IChild.apply(this, [parent]);
      this.Text = value || "";
   };
   //Node Object - can have children
   var INodeSet = function () {
      this.length = 0;
      this.push = function (elem) { Array.prototype.push.call(this, elem); };
      this.sort = function () { Array.prototype.sort.apply(this, arguments); };
   };
   INodeSet.prototype = {
      getNodesByAttribute: function (attr, obj) {
         var out = [];
         if (!!this.length && util.isStr(attr) && util.isDef(obj)) {
            var n = this.length, node, aval;
            while (n--) {
               node = this[n]; aval = node[attr];
               if (util.isDef(aval) && aval === obj) { out.unshift(node); }
            }
         }
         return (!out.length) ? null : out;
      },
      getNodesByValue: function (obj) {
         var out = [];
         if (!!this.length && util.isDef(obj)) {
            var n = this.length, node;
            while (n--) {
               node = this[n];
               if (node.Text === obj) { out.unshift(node); }
            }
         }
         return (!out.length) ? null : out;
      },
      contains: function (attr, obj) {
         var out = false;
         if (!!this.length && util.isStr(attr) && util.isDef(obj)) {
            var n = this.length, node, aval;
            while (n--) {
               node = this[n]; aval = node[attr];
               if (util.isDef(aval) && aval === obj) { out = true; break; }
            }
         }
         return out;
      },
      indexOf: function () {
         var out = -1, attr, obj;
         if (!!this.length) {
            var n = this.length, node, val;
            switch (arguments.length) {
               case 1: obj = arguments[0];
                  while (n--) {
                     node = this[n]; val = node.val();
                     if (util.isDef(val) && val === obj) { out = n; break; }
                  }
                  break;
               case 2: attr = arguments[0]; obj = arguments[1];
                  while (n--) {
                     node = this[n]; val = node[attr];
                     if (util.isDef(val) && val === obj) { out = n; break; }
                  }
                  break;
            }
         }
         return out;
      },
      sortByAttribute: function (attr, dir) {
         if (!!this.length && util.isStr(attr)) {
            this.sort(function (a, b) {
               var _a = (a.attr(attr)),
						_b = (b.attr(attr));
               _a = util.isNum(_a) ? parseFloat(_a) : _a;
               _b = util.isNum(_b) ? parseFloat(_b) : _b;
               var _out = (_a < _b) ? -1 : (_b < _a) ? 1 : 0;
               _out = (util.isDef(dir) && dir.toLowerCase() === "desc") ? (0 - _out) : _out;
               return _out;
            });
         }
      },
      sortByValue: function (dir) {
         if (!!this.length) {
            this.sort(function (a, b) {
               var _a = (a.Text),
						_b = (b.Text);
               _a = util.isNum(_a) ? parseFloat(_a) : _a;
               _b = util.isNum(_b) ? parseFloat(_b) : _b;
               var _out = (_a < _b) ? -1 : (_b < _a) ? 1 : 0;
               _out = (util.isDef(dir) && dir.toLowerCase() === "desc") ? (0 - _out) : _out;
               return _out;
            });
         }
      },
      sortByChildNode: function (nodeName, dir) {
         if (!!this.length && util.isStr(nodeName)) {
            this.sort(function (a, b) {
               var _a = a[nodeName],
						_b = b[nodeName];
               _a = (util.isDef(_a) && !!_a.length) ? _a[0].Text : null;
               _b = (util.isDef(_b) && !!_b.length) ? _b[0].Text : null;
               //---------------------------------------------------//
               _a = util.isNum(_a) ? parseFloat(_a) : _a;
               _b = util.isNum(_b) ? parseFloat(_b) : _b;
               var _out = (_a < _b) ? -1 : (_b < _a) ? 1 : 0;
               _out = (util.isDef(dir) && dir.toLowerCase() === "desc") ? (0 - _out) : _out;
               return _out;
            });
         }
      },
      first: function () {
         var out = null;
         if (!!this.length) { out = this[0]; }
         return out;
      },
      last: function () {
         var out = null;
         if (!!this.length) { out = this[this.length - 1]; }
         return out;
      }
   };
   //Engine Factory
   var XMLObjectifierEngine = (function () {
      var _public = {
         makeNodeSet: function () {
            var node = new INodeSet();
            return node;
         },
         makeNode: function (parent, obj) {
            var name = obj.localName || obj.baseName;
            name = util.formatName(name);
            var node = new INode(parent, name);
            node.ns = obj.prefix || "";
            this.setAttributes(node, obj);
            return node;
         },
         setAttributes: function (obj, xnode) {
            if (util.isDef(xnode) && !!xnode.attributes.length) {
               var a = xnode.attributes.length - 1, attName = null, objParent = null;
               do { //Order is irrelevant (speed-up)
                  attName = "@" + xnode.attributes[a].name;
                  obj.attr(attName, xnode.attributes[a].value);
               } while (a--);
            }
         },
         run: function (parent, xobj) {
            var curChild, newNode;
            if (util.isDef(parent) && util.isDef(xobj)) {
               if (xobj.hasChildNodes()) {
                  var nodesLen = xobj.childNodes.length - 1, n = 0;
                  do {
                     curChild = xobj.childNodes[n];
                     switch (curChild.nodeType) {
                        case 1: //Node										
                           //Create a single node
                           newNode = _public.makeNode(parent, curChild);
                           if (util.isFn(this.decorator)) {
                              var _dout = this.decorator.call(newNode);
                              //Skip node if decorator returns false
                              if (_dout === false) { continue; }
                           }
                           if (!!newNode) {
                              //Add child node to parent
                              parent.appendChild(newNode);
                              //Recursive call if node contains children
                              if (curChild.hasChildNodes()) { _public.run.apply(this, [newNode, curChild]); }
                           }
                           break;
                        case 3: //Text Value
                           parent.val(util.trim(curChild.nodeValue));
                           break;
                        case 4: //CDATA										
                           parent.hasCDATA = true;
                           parent.val(util.isDef(curChild.text) ? util.trim(curChild.text) : util.trim(curChild.nodeValue));
                           break;
                        case 8: //Comments
                           if (!util.isDef(this.noComments) || !this.noComments) {
                              if (!util.isDef(parent.$comments)) { parent.$comments = []; }
                              parent.$comments.push(util.trim(curChild.nodeValue));
                           }
                           break;
                     }
                  } while (n++ < nodesLen);
               }
            }
         },
         init: function (xobj, opt) {
            opt = opt || { noComments: true };
            if (util.isStr(xobj)) {
               xobj = this.textToXML(xobj);
            } else if (util.isXNode(xobj)) {
               xobj = xobj;
            } else { xobj = null; }
            //If invalid xml object - abort
            if (!xobj) { return null; }
            //Determine a document root node
            var xroot = (xobj.nodeType === 9) ? xobj.documentElement : (xobj.nodeType === 11) ? xobj.firstChild : xobj;
            //Root Node
            var root = new IRoot(xroot.nodeName);
            if (util.isFn(opt.decorator)) {
               opt.decorator.call(root);
            }
            //If init argument is just a text or CDATA return value
            if (xobj.nodeType === 3 || xobj.nodeType === 4) {
               return xobj.nodeValue;
            }
            //Begins a recursive process to build out a JSON structure						
            this.run.apply(opt, [root, xroot]);
            this.setAttributes(root, xroot);
            return root;
         },
         textToXML: function (strXML) {
            var xmlDoc = null;
            try {
               xmlDoc = (util.isIE()) ? new ActiveXObject("MSXML2.DOMDocument") : new DOMParser();
               xmlDoc.async = false;
            } catch (e) { throw new Error("XML Parser could not be instantiated"); }
            var out = null, isParsed = true;
            if (util.isIE()) {
               isParsed = xmlDoc.loadXML(strXML);
               out = (isParsed) ? xmlDoc : false;
            } else {
               out = xmlDoc.parseFromString(strXML, "text/xml");
               isParsed = (out.documentElement.tagName !== "parsererror");
            }
            if (!isParsed) { throw new Error("Error parsing XML string"); }
            return out;
         }
      };

      return _public;
   })();
   IRoot.prototype = {
      typeOf: "xmlObjectifier",
      attr: function () {
         var out, attr, val;
         if (!!arguments.length) {
            switch (arguments.length) {
               case 1: attr = util.formatName(arguments[0]);
                  val = this["@" + attr] || this[attr];
                  if (util.isDef(val) && !util.isArr(val)) { out = val; } break;
               case 2: attr = util.formatName(arguments[0]);
                  val = arguments[1];
                  if (util.isStr(attr)) { this[(/^@/.test(attr)) ? attr : "@" + attr] = val; out = this; } break;
            }
         }
         return out;
      },
      find: function (sel) {
         var out = null, tokens, token, tokenOnly;
         if (util.isStr(sel)) {
            var curMatch, subNode;
            var condMatch = /\[(\d+|@\w+(=\w+)?)\]/, conditionStr, parts, partA, partB;
            var rx = /(?=\.)?([A-Za-z\-]+(\[(\d+|@\w+(=\w+)?)\])?)/g;
            var attrMatch = /^@\w+/, attr;
            //If selector is an attribute, then just find attribute and return it
            if (sel.match(attrMatch)) {
               attr = sel.match(attrMatch)[0];
               return this.attr(attr);
            }
            tokens = sel.match(rx);
            if (!!tokens.length) {
               var t = 0, tLen = tokens.length - 1;
               do {
                  token = tokens[t];
                  tokenOnly = token.match(/[A-Za-z\-]+/)[0];
                  curMatch = !!curMatch ? (util.isArr(curMatch) ? curMatch[0] : curMatch)[tokenOnly] : this[tokenOnly];
                  if (!curMatch) { break; }
                  conditionStr = !!token.match(condMatch) && token.match(condMatch)[0].replace("[", "").replace("]", "");
                  if (conditionStr && !!conditionStr.length) {
                     if (conditionStr.indexOf("=") !== -1) {
                        parts = conditionStr.split("=");
                        partA = util.trim(parts[0]); partB = util.trim(parts[1]);
                        if (partA.indexOf("@") !== -1) {
                           attr = partA;
                           curMatch = curMatch.getNodesByAttribute(attr, partB);
                        } else {
                           subNode = util.trim(curMatch[partA]);
                           if (subNode) {
                              curMatch = subNode.getNodesByValue(partB);
                           }
                        }
                     } else if (util.isNum(conditionStr)) {
                        curMatch = curMatch[parseInt(conditionStr, 10)];
                     }
                  }
               } while (t++ < tLen);
               out = curMatch;
            }
         }
         return out;
      },
      addComment: function (comment) {
         if (util.isStr(comment)) {
            if (!util.isDef(this.$comments)) { this.$comments = []; }
            this.$comments.push(comment);
         }
         return this;
      },
      val: function (v) {
         var out = this;
         if (util.isDef(v)) {
            this.Text = v;
         } else { out = this.Text; }
         return out;
      },
      toXML: function () {
         var root = XMLSerializer.newDocument(this.nodeName, this.ns);
         XMLSerializer.objToNode.call(root, root.documentElement, this);
         return root;
      },
      toString: function () {
         var root = this.toXML();
         var out = "";
         if (util.isDef(root.xml)) {
            out = root.xml;
         } else if (util.isDef(XMLSerializer)) {
            var serializer = new window.XMLSerializer();
            out = serializer.serializeToString(root);
         }
         return out;
      },
      appendChild: function (nodeClassInst) {
         if (util.isDef(nodeClassInst) && nodeClassInst instanceof INode) {
            nodeClassInst.parent = this;
            if (!util.isDef(this[nodeClassInst.nodeName])) { this[nodeClassInst.nodeName] = XMLObjectifierEngine.makeNodeSet(); }
            this[nodeClassInst.nodeName].push(nodeClassInst);
         }
      }
   };
   INode.prototype = {
      attr: IRoot.prototype.attr,
      val: IRoot.prototype.val,
      find: IRoot.prototype.find,
      addComment: IRoot.prototype.addComment,
      appendChild: IRoot.prototype.appendChild
   };
   //All Public members
   var _publicMapping = {
      xmlToJSON: function (xdoc, opt) {
         return XMLObjectifierEngine.init(xdoc, opt);
      },
      //Converts Text to XML DOM
      textToXML: XMLObjectifierEngine.textToXML,
      //Classes exposed for prototype extensibility
      xmlObjectifier: {
         RootClass: IRoot, //Root node only
         NodeClass: INode,  //Node element
         NodeSetClass: INodeSet //NodeSet class
      }
   };

   if (util.isDef($)) {
      $.extend(_publicMapping);
   } else {
      window.XMLObjectifier = _publicMapping;
   }
})((typeof (jQuery) !== "undefined") && jQuery || undefined);

/*
http://www.JSON.org/json2.js
2010-03-20

Public Domain.

NO WARRANTY EXPRESSED OR IMPLIED. USE AT YOUR OWN RISK.

See http://www.JSON.org/js.html


This code should be minified before deployment.
See http://javascript.crockford.com/jsmin.html

USE YOUR OWN COPY. IT IS EXTREMELY UNWISE TO LOAD CODE FROM SERVERS YOU DO
NOT CONTROL.


This file creates a global JSON object containing two methods: stringify
and parse.

JSON.stringify(value, replacer, space)
value       any JavaScript value, usually an object or array.

replacer    an optional parameter that determines how object
values are stringified for objects. It can be a
function or an array of strings.

space       an optional parameter that specifies the indentation
of nested structures. If it is omitted, the text will
be packed without extra whitespace. If it is a number,
it will specify the number of spaces to indent at each
level. If it is a string (such as '\t' or '&nbsp;'),
it contains the characters used to indent at each level.

This method produces a JSON text from a JavaScript value.

When an object value is found, if the object contains a toJSON
method, its toJSON method will be called and the result will be
stringified. A toJSON method does not serialize: it returns the
value represented by the name/value pair that should be serialized,
or undefined if nothing should be serialized. The toJSON method
will be passed the key associated with the value, and this will be
bound to the value

For example, this would serialize Dates as ISO strings.

Date.prototype.toJSON = function (key) {
function f(n) {
// Format integers to have at least two digits.
return n < 10 ? '0' + n : n;
}

return this.getUTCFullYear()   + '-' +
f(this.getUTCMonth() + 1) + '-' +
f(this.getUTCDate())      + 'T' +
f(this.getUTCHours())     + ':' +
f(this.getUTCMinutes())   + ':' +
f(this.getUTCSeconds())   + 'Z';
};

You can provide an optional replacer method. It will be passed the
key and value of each member, with this bound to the containing
object. The value that is returned from your method will be
serialized. If your method returns undefined, then the member will
be excluded from the serialization.

If the replacer parameter is an array of strings, then it will be
used to select the members to be serialized. It filters the results
such that only members with keys listed in the replacer array are
stringified.

Values that do not have JSON representations, such as undefined or
functions, will not be serialized. Such values in objects will be
dropped; in arrays they will be replaced with null. You can use
a replacer function to replace those with JSON values.
JSON.stringify(undefined) returns undefined.

The optional space parameter produces a stringification of the
value that is filled with line breaks and indentation to make it
easier to read.

If the space parameter is a non-empty string, then that string will
be used for indentation. If the space parameter is a number, then
the indentation will be that many spaces.

Example:

text = JSON.stringify(['e', {pluribus: 'unum'}]);
// text is '["e",{"pluribus":"unum"}]'


text = JSON.stringify(['e', {pluribus: 'unum'}], null, '\t');
// text is '[\n\t"e",\n\t{\n\t\t"pluribus": "unum"\n\t}\n]'

text = JSON.stringify([new Date()], function (key, value) {
return this[key] instanceof Date ?
'Date(' + this[key] + ')' : value;
});
// text is '["Date(---current time---)"]'


JSON.parse(text, reviver)
This method parses a JSON text to produce an object or array.
It can throw a SyntaxError exception.

The optional reviver parameter is a function that can filter and
transform the results. It receives each of the keys and values,
and its return value is used instead of the original value.
If it returns what it received, then the structure is not modified.
If it returns undefined then the member is deleted.

Example:

// Parse the text. Values that look like ISO date strings will
// be converted to Date objects.

myData = JSON.parse(text, function (key, value) {
var a;
if (typeof value === 'string') {
a =
/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z$/.exec(value);
if (a) {
return new Date(Date.UTC(+a[1], +a[2] - 1, +a[3], +a[4],
+a[5], +a[6]));
}
}
return value;
});

myData = JSON.parse('["Date(09/09/2001)"]', function (key, value) {
var d;
if (typeof value === 'string' &&
value.slice(0, 5) === 'Date(' &&
value.slice(-1) === ')') {
d = new Date(value.slice(5, -1));
if (d) {
return d;
}
}
return value;
});


This is a reference implementation. You are free to copy, modify, or
redistribute.
*/

/*jslint evil: true, strict: false */

/*members "", "\b", "\t", "\n", "\f", "\r", "\"", JSON, "\\", apply,
call, charCodeAt, getUTCDate, getUTCFullYear, getUTCHours,
getUTCMinutes, getUTCMonth, getUTCSeconds, hasOwnProperty, join,
lastIndex, length, parse, prototype, push, replace, slice, stringify,
test, toJSON, toString, valueOf
*/


// Create a JSON object only if one does not already exist. We create the
// methods in a closure to avoid creating global variables.

if (!this.JSON) {
   this.JSON = {};
}

(function () {

   function f(n) {
      // Format integers to have at least two digits.
      return n < 10 ? '0' + n : n;
   }

   if (typeof Date.prototype.toJSON !== 'function') {

      Date.prototype.toJSON = function (key) {

         return isFinite(this.valueOf()) ?
                   this.getUTCFullYear() + '-' +
                 f(this.getUTCMonth() + 1) + '-' +
                 f(this.getUTCDate()) + 'T' +
                 f(this.getUTCHours()) + ':' +
                 f(this.getUTCMinutes()) + ':' +
                 f(this.getUTCSeconds()) + 'Z' : null;
      };

      String.prototype.toJSON =
        Number.prototype.toJSON =
        Boolean.prototype.toJSON = function (key) {
           return this.valueOf();
        };
   }

   var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        gap,
        indent,
        meta = {    // table of character substitutions
           '\b': '\\b',
           '\t': '\\t',
           '\n': '\\n',
           '\f': '\\f',
           '\r': '\\r',
           '"': '\\"',
           '\\': '\\\\'
        },
        rep;


   function quote(string) {

      // If the string contains no control characters, no quote characters, and no
      // backslash characters, then we can safely slap some quotes around it.
      // Otherwise we must also replace the offending characters with safe escape
      // sequences.

      escapable.lastIndex = 0;
      return escapable.test(string) ?
            '"' + string.replace(escapable, function (a) {
               var c = meta[a];
               return typeof c === 'string' ? c :
                    '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
            }) + '"' :
            '"' + string + '"';
   }


   function str(key, holder) {

      // Produce a string from holder[key].

      var i,          // The loop counter.
            k,          // The member key.
            v,          // The member value.
            length,
            mind = gap,
            partial,
            value = holder[key];

      // If the value has a toJSON method, call it to obtain a replacement value.

      if (value && typeof value === 'object' &&
                typeof value.toJSON === 'function') {
         value = value.toJSON(key);
      }

      // If we were called with a replacer function, then call the replacer to
      // obtain a replacement value.

      if (typeof rep === 'function') {
         value = rep.call(holder, key, value);
      }

      // What happens next depends on the value's type.

      switch (typeof value) {
         case 'string':
            return quote(value);

         case 'number':

            // JSON numbers must be finite. Encode non-finite numbers as null.

            return isFinite(value) ? String(value) : 'null';

         case 'boolean':
         case 'null':

            // If the value is a boolean or null, convert it to a string. Note:
            // typeof null does not produce 'null'. The case is included here in
            // the remote chance that this gets fixed someday.

            return String(value);

            // If the type is 'object', we might be dealing with an object or an array or
            // null.

         case 'object':

            // Due to a specification blunder in ECMAScript, typeof null is 'object',
            // so watch out for that case.

            if (!value) {
               return 'null';
            }

            // Make an array to hold the partial results of stringifying this object value.

            gap += indent;
            partial = [];

            // Is the value an array?

            if (Object.prototype.toString.apply(value) === '[object Array]') {

               // The value is an array. Stringify every element. Use null as a placeholder
               // for non-JSON values.

               length = value.length;
               for (i = 0; i < length; i += 1) {
                  partial[i] = str(i, value) || 'null';
               }

               // Join all of the elements together, separated with commas, and wrap them in
               // brackets.

               v = partial.length === 0 ? '[]' :
                    gap ? '[\n' + gap +
                            partial.join(',\n' + gap) + '\n' +
                                mind + ']' :
                          '[' + partial.join(',') + ']';
               gap = mind;
               return v;
            }

            // If the replacer is an array, use it to select the members to be stringified.

            if (rep && typeof rep === 'object') {
               length = rep.length;
               for (i = 0; i < length; i += 1) {
                  k = rep[i];
                  if (typeof k === 'string') {
                     v = str(k, value);
                     if (v) {
                        partial.push(quote(k) + (gap ? ': ' : ':') + v);
                     }
                  }
               }
            } else {

               // Otherwise, iterate through all of the keys in the object.

               for (k in value) {
                  if (Object.hasOwnProperty.call(value, k)) {
                     v = str(k, value);
                     if (v) {
                        partial.push(quote(k) + (gap ? ': ' : ':') + v);
                     }
                  }
               }
            }

            // Join all of the member texts together, separated with commas,
            // and wrap them in braces.

            v = partial.length === 0 ? '{}' :
                gap ? '{\n' + gap + partial.join(',\n' + gap) + '\n' +
                        mind + '}' : '{' + partial.join(',') + '}';
            gap = mind;
            return v;
      }
   }

   // If the JSON object does not yet have a stringify method, give it one.

   if (typeof JSON.stringify !== 'function') {
      JSON.stringify = function (value, replacer, space) {

         // The stringify method takes a value and an optional replacer, and an optional
         // space parameter, and returns a JSON text. The replacer can be a function
         // that can replace values, or an array of strings that will select the keys.
         // A default replacer method can be provided. Use of the space parameter can
         // produce text that is more easily readable.

         var i;
         gap = '';
         indent = '';

         // If the space parameter is a number, make an indent string containing that
         // many spaces.

         if (typeof space === 'number') {
            for (i = 0; i < space; i += 1) {
               indent += ' ';
            }

            // If the space parameter is a string, it will be used as the indent string.

         } else if (typeof space === 'string') {
            indent = space;
         }

         // If there is a replacer, it must be a function or an array.
         // Otherwise, throw an error.

         rep = replacer;
         if (replacer && typeof replacer !== 'function' &&
                    (typeof replacer !== 'object' ||
                     typeof replacer.length !== 'number')) {
            throw new Error('JSON.stringify');
         }

         // Make a fake root object containing our value under the key of ''.
         // Return the result of stringifying the value.

         return str('', { '': value });
      };
   }


   // If the JSON object does not yet have a parse method, give it one.

   if (typeof JSON.parse !== 'function') {
      JSON.parse = function (text, reviver) {

         // The parse method takes a text and an optional reviver function, and returns
         // a JavaScript value if the text is a valid JSON text.

         var j;

         function walk(holder, key) {

            // The walk method is used to recursively walk the resulting structure so
            // that modifications can be made.

            var k, v, value = holder[key];
            if (value && typeof value === 'object') {
               for (k in value) {
                  if (Object.hasOwnProperty.call(value, k)) {
                     v = walk(value, k);
                     if (v !== undefined) {
                        value[k] = v;
                     } else {
                        delete value[k];
                     }
                  }
               }
            }
            return reviver.call(holder, key, value);
         }


         // Parsing happens in four stages. In the first stage, we replace certain
         // Unicode characters with escape sequences. JavaScript handles many characters
         // incorrectly, either silently deleting them, or treating them as line endings.

         text = String(text);
         cx.lastIndex = 0;
         if (cx.test(text)) {
            text = text.replace(cx, function (a) {
               return '\\u' +
                        ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
            });
         }

         // In the second stage, we run the text against regular expressions that look
         // for non-JSON patterns. We are especially concerned with '()' and 'new'
         // because they can cause invocation, and '=' because it can cause mutation.
         // But just to be safe, we want to reject all unexpected forms.

         // We split the second stage into 4 regexp operations in order to work around
         // crippling inefficiencies in IE's and Safari's regexp engines. First we
         // replace the JSON backslash pairs with '@' (a non-JSON character). Second, we
         // replace all simple value tokens with ']' characters. Third, we delete all
         // open brackets that follow a colon or comma or that begin the text. Finally,
         // we look to see that the remaining characters are only whitespace or ']' or
         // ',' or ':' or '{' or '}'. If that is so, then the text is safe for eval.

         if (/^[\],:{}\s]*$/.
test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@').
replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {

            // In the third stage we use the eval function to compile the text into a
            // JavaScript structure. The '{' operator is subject to a syntactic ambiguity
            // in JavaScript: it can begin a block or an object literal. We wrap the text
            // in parens to eliminate the ambiguity.

            j = eval('(' + text + ')');

            // In the optional fourth stage, we recursively walk the new structure, passing
            // each name/value pair to a reviver function for possible transformation.

            return typeof reviver === 'function' ?
                    walk({ '': j }, '') : j;
         }

         // If the text is not JSON parseable, then a SyntaxError is thrown.

         throw new SyntaxError('JSON.parse');
      };
   }
} ());
