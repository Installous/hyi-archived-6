// themePump callback: refresh starting - show the update indicator

function onPumpRefreshStart(data, settings) {
   $(".updateInd").removeClass("off");
}


//  themePump callback: refresh finished - hide the update indicator

function onPumpRefreshEnd(data, settings) {

   // hide the update indicator

   setTimeout(function () { $(".updateInd").addClass("off"); }, 500);

   // slide the day of month indicator

   var temp = parseInt(data.cc.temp, 10);
   if (!isNaN(temp)) {
      var high = data.forecast.day[0].high;
      if (isNaN(high)) high = temp + 10;
      var low = data.forecast.day[0].low;
      if (isNaN(low)) low = temp - 10;
      var left = ((150 / Math.max((high - low), 1)) * (temp - low)) - 16;
      left = Math.min(Math.max(left, -16), 136);
      $("#weather .current").css("left", left);
   }

   // slide the temperature indicator

   var d = new Date();
   var daysinmonth = 32 - new Date(d.getFullYear(), d.getMonth(), 32).getDate();
   var monthday = d.getDate();
   var left = ((150 / daysinmonth) * monthday) - 20;
   $("#calendar .day").css("left", left);
}
