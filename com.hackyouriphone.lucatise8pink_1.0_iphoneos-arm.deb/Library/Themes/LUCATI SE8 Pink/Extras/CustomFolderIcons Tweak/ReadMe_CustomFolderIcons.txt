Follow the Steps

1. Choose one of the two provided icons, if you are using 2x2 or 3x3 folder icons.
2. Duplicate/Rename the Icon according to the actual folder’s name you have on your springboard. The name should be in the format: Name@2x.png

3. Copy them into the following directory: /var/mobile/Library/CustomFolderIcons

4. Respring


