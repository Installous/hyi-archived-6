var clock_options = "pulse"; // OPTIONS: ''anime"_for_animation "pulse"_for_pulse_animation "glow"_no_animation_glow "still"_for_no_animation "crazy"_for_crazy_fast_pulse_animation
var bg_options = "bg"; // OPTIONS: "nobg"_no_box "bg"_box
var language = "en"; // en, cz, it, sp, de, fr, zh
