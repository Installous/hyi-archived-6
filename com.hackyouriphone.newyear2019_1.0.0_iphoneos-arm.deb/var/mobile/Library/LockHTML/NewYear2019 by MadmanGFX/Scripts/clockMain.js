var twentyfour = false; 
var padzero = false; 
var refresh = 5000; 
var weathercode = "CAXX0501"; // go to weather.com to get your city's code, the code is in the url
var celsius = false; 
var gpsswitch = true; // must use widget weather xml if set to true
var refreshrate = 30; 
clock({
  twentyfour : twentyfour,
  padzero : padzero,
  refresh : refresh,
  success: function(clock){


document.getElementById('hour').innerHTML = clock.hourtext(true,true); //returns the current hour set to 24hr with the zero padded

document.getElementById('minute').innerHTML = clock.minute(); //returns the current minute. 

document.getElementById('ampm').innerHTML = clock.am(); //returns the current time of day.
      
document.getElementById('weekday').innerHTML = clock.daytext(); //returns the current day.

document.getElementById('date').innerHTML = clock.date(); //returns the current date.
      
document.getElementById('month').innerHTML = clock.smonth(); //returns the word of the current month.

document.getElementById('year').innerHTML = clock.year(); //returns the current year.

  }
});

switch (clock_options) {
		case "anime":
			document.getElementById("DefaultStyle").href = "Styles/animate.css"
		break;
		case "still":
			document.getElementById("DefaultStyle").href = "Styles/still.css"
		break;
		case "pulse":
			document.getElementById("DefaultStyle").href = "Styles/pulse.css"
		break;		
		case "glow":
			document.getElementById("DefaultStyle").href = "Styles/glow.css"
		break;		
		case "crazy":
			document.getElementById("DefaultStyle").href = "Styles/crazy.css"
		break; 
}

switch (bg_options) {
		case "nobg":
			document.getElementById("Wallpaper").src = "Images/AnalogWidgetNoBG.png"
		break;
		case "bg":
			document.getElementById("Wallpaper").src = "Images/AnalogWidget.png"
		break;

}