var Clock = "12h"; // choose between "12h" or "24h"
var Lang = "en"; // choose between "en", "ca", "fr", "de", "it", or "cz"
var C1P = '#21B3F4';
var C2P = '#2073EE';