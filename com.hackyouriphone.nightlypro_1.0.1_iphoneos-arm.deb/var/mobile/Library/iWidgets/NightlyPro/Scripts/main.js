
window.addEventListener("load", function() { 
   //document.body.style.width='100%';
   //document.body.style.height='100%';
}, false);

//var pa = 1;
//var bg = 1;


function init(){
	updateClock();
	setInterval("updateClock();", 1000);
	checkSettings();
}

function checkSettings(){
	
	document.documentElement.style.setProperty('--br', br + 'px');
	document.documentElement.style.setProperty('--bl', bl + 'px');
	document.documentElement.style.setProperty('--cH', cH + 'px');
	document.documentElement.style.setProperty('--cW', cW + 'px');
	document.documentElement.style.setProperty('--gY', gY + 'px');
	
	document.documentElement.style.setProperty('--primary', C1);
	document.documentElement.style.setProperty('--primary2', C2);
	document.documentElement.style.setProperty('--secondary', C3);
	document.documentElement.style.setProperty('--secondary2', C4);
	
	C1P = pC1;
	C2P = pC2;
	
	if(ba === 0){
		document.getElementById('battCont').style.display = 'none';
	}
	
	if(dt === 0){
		document.getElementById('date').style.display = 'none';
	}
	
	if(bg === 0){
		document.getElementById('mainCont').style.background = 'rgba(0,0,0,0)';
		document.getElementById('mainCont').classList.remove('shadow-dark-out');
		document.getElementById('particles-js').style.display = 'none';
	}else{
		document.getElementById('mainCont').style.background = bgC;
		if(pa === 0){
			document.getElementById('particles-js').style.display = 'none';
		}else{
			//loadjscssfile("Scripts/particles.js", "js")
			loadjscssfile("Scripts/app.js", "js")
		}
	}
	
	if(cg === 1){
		document.getElementById("greet").innerHTML = cgT;
	}
	
}

function loadjscssfile(filename, filetype){
    if (filetype=="js"){ //if filename is a external JavaScript file
        var fileref=document.createElement('script')
        fileref.setAttribute("type","text/javascript")
        fileref.setAttribute("src", filename)
    }
    else if (filetype=="css"){ //if filename is an external CSS file
        var fileref=document.createElement("link")
        fileref.setAttribute("rel", "stylesheet")
        fileref.setAttribute("type", "text/css")
        fileref.setAttribute("href", filename)
    }
    if (typeof fileref!="undefined")
        document.getElementsByTagName("head")[0].appendChild(fileref)
}

//------------------------- TIME FUNCTIONS ---------------------------
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	//var Time24 = 1;
	
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	
	if(cg === 0){
		if(currentTime.getHours() > 0 && currentTime.getHours() < 12){
			document.getElementById("greet").innerHTML = greet[0];
		}
		if(currentTime.getHours() >= 12 && currentTime.getHours() < 18){
			document.getElementById("greet").innerHTML = greet[1];
		}
		if(currentTime.getHours() >= 18 && currentTime.getHours() < 24){
			document.getElementById("greet").innerHTML = greet[2];
		}
	}
	
	document.getElementById("date").innerHTML = shortdays[currentTime.getDay()] + " " + currentDate + " - " + currentHours + ":" + currentMinutes1;
		
}


function openWea(){
	//if(document.getElementById("weaCont").classList.contains('closed')){
		if(document.getElementById("mainCont").classList.contains('home')){
			//show weather hide home
			document.getElementById("weaCont").classList.remove('closed');
			document.getElementById("mainCont").classList.add('weather');
			document.getElementById("mainCont").classList.remove('home');
			
			document.getElementById("battCont").classList.add('move');
			document.getElementById("greet").classList.add('move');
			document.getElementById("date").classList.add('move');
			
			document.getElementById("weaCont").style.display = 'block';
			TweenMax.to(document.getElementById("weaCont"), 0.5, {alpha:1});
			
			document.getElementById("homeWe").style.display = 'block';
			document.getElementById("weatherIconHome").style.display = 'none';
			
			return;
		}
		
		if(document.getElementById("mainCont").classList.contains('music')){
			//show weather hide music
			document.getElementById("weaCont").classList.remove('closed');
			document.getElementById("musCont").classList.add('closed');
			document.getElementById("mainCont").classList.add('weather');
			document.getElementById("mainCont").classList.remove('music');
			
			document.getElementById("weaCont").style.display = 'block';
			TweenMax.to(document.getElementById("weaCont"), 0.5, {alpha:1});
			
			TweenMax.to(document.getElementById("musCont"), 0.5, {alpha:0, onComplete:function(){
				document.getElementById("musCont").style.display = 'none';
			}});
			
			document.getElementById("homeWe").style.display = 'block';
			document.getElementById("weatherIconHome").style.display = 'none';
			
			document.getElementById("homeMu").style.display = 'none';
			document.getElementById("musicArtHome").style.display = 'block';
			
			return;
		}
		
	//}else{
	if(document.getElementById("mainCont").classList.contains('weather')){
		//hide weather show home
		document.getElementById("mainCont").classList.add('home');
		document.getElementById("mainCont").classList.remove('weather');
		document.getElementById("mainCont").classList.remove('music');
		
		document.getElementById("weaCont").classList.add('closed');
		document.getElementById("battCont").classList.remove('move');
		document.getElementById("greet").classList.remove('move');
		document.getElementById("date").classList.remove('move');
		
		TweenMax.to(document.getElementById("weaCont"), 0.5, {alpha:0, onComplete:function(){
			document.getElementById("weaCont").style.display = 'none';
		}});
		
		document.getElementById("homeWe").style.display = 'none';
		document.getElementById("weatherIconHome").style.display = 'block';
		
		return;
	}
}

function openMu(){
	if(document.getElementById("musCont").classList.contains('closed')){
		if(document.getElementById("mainCont").classList.contains('home')){
			//show music hide home
			document.getElementById("musCont").classList.remove('closed');
			document.getElementById("weaCont").classList.add('closed');
			document.getElementById("mainCont").classList.add('music');
			document.getElementById("mainCont").classList.remove('home');
			
			document.getElementById("battCont").classList.add('move');
			document.getElementById("greet").classList.add('move');
			document.getElementById("date").classList.add('move');
			
			document.getElementById("musCont").style.display = 'block';
			TweenMax.to(document.getElementById("musCont"), 0.5, {alpha:1});
			
			document.getElementById("homeMu").style.display = 'block';
			document.getElementById("musicArtHome").style.display = 'none';
			
			return;
		}
		
		if(document.getElementById("mainCont").classList.contains('weather')){
			//show music hide weather
			document.getElementById("musCont").classList.remove('closed');
			document.getElementById("mainCont").classList.add('music');
			document.getElementById("mainCont").classList.remove('weather');
			
			document.getElementById("musCont").style.display = 'block';
			TweenMax.to(document.getElementById("musCont"), 0.5, {alpha:1});
			
			TweenMax.to(document.getElementById("weaCont"), 0.5, {alpha:0, onComplete:function(){
				document.getElementById("weaCont").style.display = 'none';
			}});
			
			document.getElementById("homeWe").style.display = 'none';
			document.getElementById("weatherIconHome").style.display = 'block';
			
			document.getElementById("homeMu").style.display = 'block';
			document.getElementById("musicArtHome").style.display = 'none';
			
			return;
		}
	}else{
		document.getElementById("mainCont").classList.add('home');
		document.getElementById("mainCont").classList.remove('weather');
		document.getElementById("mainCont").classList.remove('music');
		
		document.getElementById("musCont").classList.add('closed');
		document.getElementById("battCont").classList.remove('move');
		document.getElementById("greet").classList.remove('move');
		document.getElementById("date").classList.remove('move');
		
		TweenMax.to(document.getElementById("musCont"), 0.5, {alpha:0, onComplete:function(){
			document.getElementById("musCont").style.display = 'none';
		}});
		
		document.getElementById("homeMu").style.display = 'none';
		document.getElementById("musicArtHome").style.display = 'block';
		
		return;
	}
}

