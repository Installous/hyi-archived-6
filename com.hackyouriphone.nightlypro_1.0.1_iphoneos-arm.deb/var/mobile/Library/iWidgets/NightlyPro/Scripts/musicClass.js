
//------------------------- MUSIC FUNCTIONS ---------------------------
function checkMusic(){
	if (isplaying === 1) {
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
		document.getElementById('playPause2').classList.remove("zeek-buttonplay");
		document.getElementById('playPause2').classList.add("zeek-buttonpause");
	}else{
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
		document.getElementById('playPause2').classList.remove("zeek-buttonpause");
		document.getElementById('playPause2').classList.add("zeek-buttonplay");
	}
	
	if(title === "(null)"){
		document.getElementById('_title').innerHTML = '';
	}else{
		document.getElementById('_title').innerHTML = title;
	}
	
	if(artist === "(null)"){
		document.getElementById('_artist').innerHTML = '';
	}else{
		document.getElementById('_artist').innerHTML = artist;
	}
	
	
	if(album === "(null)"){
		document.getElementById('musicArt').src = 'img/note.PNG';
		document.getElementById('musicArtHome').src = 'img/note.PNG';
	}else{
		var xhr = new XMLHttpRequest();
		xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
		xhr.send();
		if (xhr.status === "404") {
			document.getElementById('musicArt').src = 'img/note.PNG';
		document.getElementById('musicArtHome').src = 'img/note.PNG';
		}else{
			document.getElementById('musicArt').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
			document.getElementById('musicArtHome').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
		}
	}
	
}


function playPause() {
	if ( document.getElementById('playPause').classList.contains("zeek-buttonplay")){ 
		document.getElementById('playPause').classList.remove("zeek-buttonplay");
		document.getElementById('playPause').classList.add("zeek-buttonpause");
		document.getElementById('playPause2').classList.remove("zeek-buttonplay");
		document.getElementById('playPause2').classList.add("zeek-buttonpause");
	}else{ 
		document.getElementById('playPause').classList.remove("zeek-buttonpause");
		document.getElementById('playPause').classList.add("zeek-buttonplay");
		document.getElementById('playPause2').classList.remove("zeek-buttonpause");
		document.getElementById('playPause2').classList.add("zeek-buttonplay");
	}
	window.location = 'xeninfo:playpause';
	
}

function next() {
	window.location = 'xeninfo:nexttrack';
}
			
function prev() {
	window.location = 'xeninfo:prevtrack';
}


