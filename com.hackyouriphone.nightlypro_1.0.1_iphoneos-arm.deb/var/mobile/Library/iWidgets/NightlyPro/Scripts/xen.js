
//--------------------------- XENINFO ---------------------------
function mainUpdate(type){ 
	if(type === "weather"){
		//if(we === 0)
			checkWeather();
	}else if (type === "music"){
		//if(mu === 1)
			checkMusic();
	}else if (type === "battery"){
		if(ba === 1)
			updateBattery();	  	
	}
}


//------------------------- WEATHER FUNCTIONS ---------------------------
function checkWeather(){
	
	document.getElementById('weatherIcon').src = 'weather_icons/' + weather.conditionCode + '.png';
	document.getElementById('weatherIconHome').src = 'weather_icons/' + weather.conditionCode + '.png';
	
	document.getElementById('condition').innerHTML = weather.condition;
	document.getElementById('tempe').innerHTML = weather.temperature + 'º';
	document.getElementById('mm').innerHTML = weather.low + "/" + weather.high;
	
}


//------------------------- BATTERY FUNCTIONS ---------------------------
//var batteryPercent = 100;
//var batteryCharging = 0;
//updateBattery();
//var isCharging = false;

function updateBattery() {
	"use strict";

	document.getElementById("percentage").innerHTML = batteryPercent + '%';
	
	document.getElementById("bl2").style.width = batteryPercent + '%';
	
}


