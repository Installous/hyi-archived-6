<!-------------------------------------------------- Configuration  by Schnedi ------------------------------------------------>


// Configuration Clock //

var ampm = true;	       // true= 12h clock    /   false= 24h clock


// Configuration Language //

var Lang = "en";			// (fr) for french, (de) for german, (ca) for spanish, (it) for italian, (en) for english.