<!------------------------------------------------------ Configuration by Schnedi --------------------------------------------------->

// Configuration Language //

	var German = false;	       // change to true to display date in German