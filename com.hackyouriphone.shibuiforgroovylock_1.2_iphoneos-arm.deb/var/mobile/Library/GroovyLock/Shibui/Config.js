var Celsius = false; //Change temp to celsius
var WeatherCode = "38671"; // Weather code for weather.com
var TwentyFourHourClock = false; // Change sunrise to 24hr
var HideSunset = false; //Hide sunrise/sunset.
var HideWeather = false; //Hide Weather Elements
