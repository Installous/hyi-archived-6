var Clock = "24h"; // choose between saat formatı seç"12h" or "24h"
var Lang = "fr"; // choose between dil seçimi yap "tr", "en", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh" "ca"
