
function checkSettings(){
	
	document.documentElement.style.setProperty('--primary', config.C1);
	document.documentElement.style.setProperty('--secondary', config.C2);
	
	document.documentElement.style.setProperty('--bg', config.bgC);
	
	document.documentElement.style.setProperty('--br', config.br + 'px');
	document.documentElement.style.setProperty('--bl', config.bl + 'px');
	
	if(config.da){
		document.getElementById("controls").classList.add('invertColor');
		document.getElementById("batt-icon").classList.add('invertColor');
	}
	
	switch (config.bg) {
		case 1:
			break;
		case 2:
			document.getElementById("container").style.background = 'none';
			document.getElementById("container").classList.add('addBlur');
			break;
		case 3:
			document.getElementById("container").classList.add('addBlur');
			break;
		case 4:
			document.getElementById("container").style.background = 'none';
			break;
		case 5:
			document.getElementById("container").style.background = 'none';
			document.getElementById("apps-container").style.background = 'none';
			document.getElementById("top-container").classList.add('addBlur');
			document.getElementById("bottom-container").classList.add('addBlur');
			document.getElementById("top-container").style.background = config.bgC;
			document.getElementById("bottom-container").style.background = config.bgC;
			break;
		case 6:
			document.getElementById("container").style.background = 'none';
			document.getElementById("apps-container").style.background = 'none';
			document.getElementById("top-container").classList.add('addBlur');
			document.getElementById("bottom-container").classList.add('addBlur');
			document.getElementById("top-container").style.background = config.bgC;
			document.getElementById("bottom-container").style.background = config.bgC;
			document.getElementById("top-container").style.borderRadius = config.br + 'px';
			document.getElementById("bottom-container").style.borderRadius = config.br + 'px';
			break;
	}
	
	document.documentElement.style.setProperty('--cY', config.cY + 'px');
	document.documentElement.style.setProperty('--cX', config.cX + '%');
	document.documentElement.style.setProperty('--cH', config.cH + 'vh');
	document.documentElement.style.setProperty('--cW', config.cW + 'vw');
	
	
}


