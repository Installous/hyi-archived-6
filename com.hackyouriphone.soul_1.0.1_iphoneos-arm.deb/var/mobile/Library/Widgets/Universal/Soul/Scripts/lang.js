﻿//Translation for major components. Originally by Junesiphone, modified by Evelyn (@ev_ynw)//

Lang = config.lang;

if (Lang == "en") {
	var greet = ["Good Morning","Good Afternoon","Good Evening"];
    var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var shortdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var months=["January","February","March","April","May","June","July","August","September","October","November","December"];
    var shortmonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var hourtext = ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
    var minutestext = ["O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", ""];
    var minutesunittext = ["clock", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", ""];
    var weatherdesc = ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank"];
} 
if (Lang == "sp") {
	var greet = ["Buenos Dias","Buenas Tardes","Buenas Noches","Buenas Noches"];
    var days = ["Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"];
    var months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
    var shortmonths = ["Ene", "Feb", "Mar", "Abr", "Mayo", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
    var shortdays = ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"];
    var hourtext = ["doce", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce"];
    var minutestext = ["en punto", "y", "y", "y", "y", "y", "y", "y", "y", "y", "y diez", "y once", "y doce", "y trece", "y catorce", "y quince", "y dieciseis", "y diecisiete", "y dieciocho", "y diecinueve", "y veinte", "y veinti", "y veinti", "y veinti", "y veinti", "y veinti", "y veinti", "y veinti", "y veinti", "y veinti", "y treinta", "y treinta", "y treinta", "y treinta", "y treinta", "y treinta", "treinta", "y treinta", "y treinta", "y treinta", "y cuarenta", "y cuarenta", " cuarenta", "y cuarenta", "y cuarenta", "y cuarenta", "y cuarenta", "y cuarenta", "y cuarenta", "y cuarenta", "y cincuenta", "y cincuenta", "y cincuenta", "y cincuenta", "y cincuenta", "y cincuenta", "y cincuenta", "y cincuenta", "y cincuenta", "y cincuenta", ""];
    var minutesunittext = ["", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", " ", "y uno", "y dos", "y tres", "y cuatro", "y cinco", "y seis", "y siete", "y ocho", "y nueve", " ", "y uno", "y dos", "y tres", "y cuatro", "y cinco", "y seis", "y siete", "y ocho", "y nueve", " ", "y uno", "y dos", "y tres", "y cuatro", "y cinco", "y seis", "y siete", "y ocho", "y nueve", ""];
    var weatherdesc = ["Tornado", "Tormenta Tropical", "Huracan", "Tormentas Electricas Severas", "Tormentas Electricas", "Mezcla de Lluvia y Nieve", "Mezcla de lluvia y aguanieve", "Mezcla de nieve y aguaniev", "Llovizna helada", "Llovizna", "Lluvia bajo cero", "Chubascos", "Chubascos", "Rafagas de nieve", "Ligeras precipitaciones de nieve", "Viento y nieve", "Nieve", "Granizo", "Aguanieve", "Polvareda", "Neblina", "Bruma", "Humeado", "Tempestuoso", "Vientoso", "Frio", "Nublado ", "Mayormente nublado", "Mayormente nublado", "despejado", "despejado", "Despejado", "Soleado", "Lindo", "Lindo", "Mezcla de lluvia y granizo", "Caluroso", "Tormentas electricas aisladas", "Tormentas electricas dispersas", "Tormentas electricas dispersas", "Chubascos dispersos", "Nieve fuerte", "Precipitaciones de nieve dispersas", "Nieve fuerte", "despejado", "Lluvia con truenos y relampagos", "Precipitaciones de nieve", "Tormentas aisladas", "No disponible"];
}
if (Lang == "de") {
	var greet = ["Guten Morgen","Guten Tag","Guten Abend","Guten Abend"];
    var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
    var months = ["Januar", "Februar", "MÃ¤rz", "April", "Mai", "Juni", "Ju li", "August", "September", "Oktober", "November", "Dez ember"];
    var shortmonths = ["Jan", "Feb", "MÃ¤", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez "];
    var shortdays = ["Son", "Mon", "Die", "Mit", "Don", "Fre", "Sam"];
    var hourtext = ["null", "ein", "zwei", "drei", "vier", "f¸nf", "sechs", "sieben", "acht", "neun", "zehn", "elf", "zwˆlf", "dreizehn", "vierzehn", "f¸nfzehn", "sechzehn", "siebzehn", "achtzehn", "neunzehn", "zwanzig", "einundzwanzig", "zweiundzwanzig", "dreiundzwanzig", "null"];
    var minutestext = ["uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr", "uhr"];
    var minutesunittext = ["", "eins", "zwei", "drei", "vier", "funf", "sechs", "sieben", "acht", "neun", "zehn", "elf", "zwˆlf", "dreizehn", "vierzehn", "funfzehn", "sechzehn", "siebzehn", "achtzehn", "neunzehn", "zwanzig", "einundzwanzig", "zweiundzwanzig", "dreiundzwanzig", "vierundzwanzig", "funfundzwanzig", "sechsundzwanzig", "siebenundzwanzig", "achtundzwanzig","neunundzwanzig", "dreiﬂig", "einunddreiﬂig", "zweiunddreiﬂig", "dreiunddreiﬂig", "vierunddreiﬂig", "f¸nfunddreiﬂig", "sechsunddreiﬂig", "siebenunddreiﬂig", "achtunddreiﬂig", "neununddreiﬂig", "vierzig", "einundvierzig", "zweiundvierzig", "dreiundvierzig", "vierundvierzig", "funfundvierzig", "sechsundvierzig", "siebenundvierzig", "achtundvierzig", "neunundvierzig", "funfzig", "einundfunfzig", "zweiundfunfzig", "dreiundfunfzig", "vierundfunfzig", "funfundfunfzig", "sechsundfunfzig", "siebenundfunfzig", "achtundfunfzig", "neunundfunfzig" , ""];
    var weatherdesc = ["Tornado", "Tropischer Sturm", "Wirbelsturm", "Schwere Gewitter", "Gewitter", "Regen und Schnee", "Graupelschauer", "Schneeregen", "Gefrierender Nieselregen", "Nieselregen", "Gefrierender Regen", "Schauer", "Schauer", "SchneegestÃ¶ber", "Leichte Schneeschauer", "Schneetreiben", "Schnee", "Hagel", "Schneeregen", "Staubig", "Nebelig", "Dunstschleier", "Dunstig", "StÃ¼rmisch", "Windig", "Kalt", "BewÃ¶lkt", "Meist BewÃ¶lkt", "Meist BewÃ¶lkt", "BewÃ¶lkt", "BewÃ¶lkt", "Klar", "Sonnig", "Heiter", "Heiter", "Regen und Hagel", "Heiss", "Ã–rtliche Gewitter", "Vereinzelte Gewitter", "Vereinzelte Gewitter", "Vereinzelte Schauer", "Starker Schneefall", "Vereinzelte Schneeschauer", "Starker Schneefall", "BewÃ¶lkt", "Gewitter", "Scheeschauer", "Ã–rtliche Gewitterschauer", "Nicht VerfÃ¼gbar"];
}
if (Lang == "fr") {
	var greet = ["Bonjour","Bonne après-midi","Bonsoir","Bonsoir"];
    var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
    var months = ["Janvie", "FÃ©vrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "AoÃ»t", "Septembre", "Octobre", "Novembre", "DÃ©cembre"];
    var shortmonths = ["Jan", "FÃ©v", "Mar", "Avr", "Mai", "Jui", "Jui", "AoÃ»", "Sep", "Oct", "Nov", "DÃ©c"];
    var shortdays = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
    var hourtext = ["minuit", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "midi", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "minuit"];
    var minutestext = ["et", "et", "et", "et", "et", "et", "et", "et", "et", "et", "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize", "dix-sept", "dix-huit", "dix-neuf", "vingt", "vingt", "vingt", "vingt", "vingt", "vingt", "vingt", "vingt", "vingt", "vingt", "trente", "trente", "trente", "trente", "trente", "trente", "trente", "trente", "trente", "trente", "quarante", "quarante", "quarante", "quarante", "quarante", "quarante", "quarante", "quarante", "quarante", "quarante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", "cinquante", ""];
    var minutesunittext = ["heure", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", " ", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", " ", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", " ", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", ""];
    var weatherdesc = ["Tornade", "Tropical", "Ouragan", "Orages Violents", "Orages", "Pluie", "Pluie", "Neige", "Bruine", "Bruine", "Pluie", "Averses", "Averses", "Quelques Flocons", "Faibles Chutes de Neige", "Rafales de Neige", "Neige", "GrÃƒÂªle", "Neige Fondue", "PoussiÃƒÂ©reux", "Brouillard", "Brume", "Brumeux", "TempÃƒÂªte", "Vent", "Temps Froid", "Temps Nuageux ", "TrÃƒÂ¨s Nuageux", "TrÃƒÂ¨s Nuageux", "Nuageux", "Nuageux", "Temps Clair", "Ensoleille", "Beau Temps", "Beau Temps", "Pluie et GrÃƒÂªles", "Temps Chaud", "Orages IsolÃƒÂ©s", "Orages Eparses", "Orages Eparses", "Averses Eparses", "Fortes Chutes de Neige", "Chutes de Neige Eparses", "Fortes Chutes de Neige", "Nuageux", "Orages", "Chute de Neige", "Orages IsolÃƒÂ©s", "Non Disponible"];
}

if (Lang == "pt") {
	var greet = ["Bom Dia","Boa tarde","Boa noite","Boa noite"];
    var days = ["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];
    var shortdays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
    var months=["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
    var shortmonths = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
    var hourtext = ["Doze", "Um", "Dois", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove", "Dez", "Onze", "Doze", "Um", "Dois", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove", "Dez", "Onze", "Doze"];
    var minutestext = ["O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "O'", "Dez", "Onze", "Doze", "Treze", "Quatorze", "Quinze", "Dezesseis", "Dezessete", "Dezoito", "Dezenove", "Vinte", "Vinte", "Vinte", "Vinte", "Vinte", "Vinte", "Vinte", "Vinte", "Vinte", "Vinte", "Trinta", "Trinta", "Trinta", "Trinta", "Trinta", "Trinta", "Trinta", "Trinta", "Trinta", "Trinta", "Quarenta", "Quarenta", "Quarenta", "Quarenta", "Quarenta", "Quarenta", "Quarenta", "Quarenta", "Quarenta", "Quarenta", "Cinquenta", "Cinquenta", "Cinquenta", "Cinquenta", "Cinquenta", "Cinquenta", "Cinquenta", "Cinquenta", "Cinquenta", "Cinquenta", ""];
    var minutesunittext = ["Relógio", "Um", "Dois", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove", "", "", "", "", "", "", "", "", "", "", "", "Um", "Dois", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove", "", "Um", "Dois", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove", "", "Um", "Dois", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove", "", "Um", "Dois", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove", ""];
    var weatherdesc = ["Tornado", "Tempestade Tropical", "Furacão", "Trovoada Forte", "Trovoada", "Mistura de Chuva e Neve", "Mistura de Chuva e Granizo", "Granizo", "Chuva Gelada", "Chuva", "Chuva Congelada", "Chuva", "Chuva", "Enxurrada de Neve", "Neve", "Neve", "Neve", "Granizo", "Aguaneve", "Empoeirado", "Névoa", "Neblina", "Esfumaçado", "Tempestuoso", "Ventoso", "Frio", "Nublado", "Nublado", "Nublado", "Nublado", "Nublado", "Claro", "Ensolarado", "Bom Tempo", "Bom Tempo", "Granizo", "Quente", "Tempestades", "Tempestades", "Tempestades", "Chuvas", "Neve Pesada", "Neve Leve", "Neve Pesada", "Parcialmente Nublado", "Tempestade", "Neve", "Tempestade", "blank"];
}

if (Lang == "ch") {
	var greet = ["早上好","下午好","晚上好","晚上好"];
	var days = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
	var shortdays = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
	var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
	var shortmonths = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
	var weatherdesc = ["风卷残云", "热带风暴", "狂风暴雨", "电闪雷鸣", "电闪雷鸣", "雨雪霏霏", "雨雪霏霏", "雨雪纷纷", "寒风冷雨", "蒙蒙细雨", "凄风冷雨", "疾风骤雨", "疾风骤雨", "俄而雪骤", "流风回雪", "狂风暴雪", "大雪纷飞", "天降冰雹", "雨雪霏霏", "飞沙走石", "云迷雾锁", "十面霾伏", "烟雾弥漫", "风起云涌", "风和日丽", "天寒地冻", "乌云蔽日", "浮云蔽日", "浮云蔽日", "云淡风轻", "云淡风轻", "晴空万里", "阳光明媚", "天朗气清", "天朗气清", "冰雹带雨", "霹雳列缺", "电闪雷鸣", "电闪雷鸣", "急风骤雨", "大雪纷飞", "骤雪初歇", "大雪纷飞", "云淡风轻", "雷阵雨", "雨雪霏霏", "霹雳列缺", "自行判断"];
}



