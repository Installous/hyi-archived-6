
window.addEventListener("load", function() { 
   //document.body.style.width='100%';
   //document.body.style.height='100%';
}, false);


var appPlaying;//, timer = null, isScroll = false;
var scT = '', scB = '';
//var C1 = '#FFFFFF', C3 = '#8450E8', C4 = '#575CDC', C5 = '#0471D3';


function init(){
	
	checkSettings();
	
	updateClock();
	setInterval("updateClock();", 1000);
	
	move('weather-container', 'top');
	move('date-container', 'bottom');
	
	XenApi();
	
}


//----------------------------- PANELS MOVE FUNCTION --------------------------------
function move(el, pos){
	if(document.getElementById(el).classList.contains('open')){
		
		if(pos === 'top'){
			removeOpen(el);
			addOpen('batteries-container');
		}else{
			removeOpen(el);
			addOpen('music-container');
			document.getElementById('music-btn').classList.add('open');
		}
		
		return;
	}else{
		if(pos === 'top'){
			if(scT !== ''){
				removeOpen('batteries-container');
			}
			addOpen(el);
			scT = el;
		}else{
			if(scB !== ''){
				removeOpen('music-container');
				document.getElementById('music-btn').classList.remove('open');
			}
			addOpen(el);
			scB = el;
		}
		
		return;
	}
}


function removeOpen(el){
	document.getElementById(el).classList.remove('open');
	setTimeout(function(){
		document.getElementById(el).style.display = 'none';
	}, 300);
}

function addOpen(el){
	document.getElementById(el).style.display = 'block';
	setTimeout(function(){
		document.getElementById(el).classList.add('open');
	}, 100);
}


function openApp(app){
	api.apps.launchApplication(app);
}

