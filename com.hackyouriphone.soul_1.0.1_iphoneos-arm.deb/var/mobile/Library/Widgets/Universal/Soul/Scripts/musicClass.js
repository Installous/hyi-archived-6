
//------------------------- MUSIC FUNCTIONS ---------------------------

function checkMusic(newData){
	
    if (newData.isPlaying) {
		document.getElementById('playPause').src = 'img/pause.svg';
    } else {
		document.getElementById('playPause').src = 'img/play.svg';
    }
	
	if (newData.isStopped) {
		document.getElementById('_title').innerHTML = 'No Media';
    	document.getElementById('_artist').innerHTML = '';
		//document.getElementById('music-btn').style.display = 'none';
	}else{
		//document.getElementById('music-btn').style.display = 'block';
		document.getElementById('_title').innerHTML = newData.nowPlaying.title;
    	document.getElementById('_artist').innerHTML = newData.nowPlaying.artist;
		
		/*if (checkOverflow(document.getElementById('foot-title')) === true){
			document.getElementById('foot-title').classList.add("marquee");
		} else {
			document.getElementById('foot-title').classList.remove("marquee");
		}*/
		
	}
	
	// Artwork image
    document.getElementById('musicArt').src = newData.nowPlaying.artwork.length > 0 ? newData.nowPlaying.artwork : 'img/note.PNG';
	
	
}

function handleTrackTimes(elapsed, length, forceUpdate) {

    const elapsedContent = length === 0 ? '--:--' : secondsToFormatted(elapsed);
    document.getElementById('elapsed').innerHTML = elapsedContent;

    const lengthContent = length === 0 ? '--:--' : secondsToFormatted(length);
    document.getElementById('length').innerHTML = lengthContent;

	document.getElementById('barIn').style.width = elapsed * 100 / length + '%';
	
}

function secondsToFormatted(seconds) {
    if (seconds === 0) return '00:00';

    const isNegative = seconds < 0;
    if (isNegative) return '00:00';

    seconds = Math.abs(seconds);
    const hours = Math.floor(seconds / 60 / 60);
    const minutes = Math.floor(seconds / 60) - (hours * 60);
    const secs = Math.floor(seconds - (minutes * 60) - (hours * 60 * 60));

    if (hours > 0) {
        return hours + ':' + (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
    } else {
        return (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
    }
}

function playPause() {
	document.getElementById('playPause').style.opacity = 0.5;
	setTimeout(function (){
		document.getElementById('playPause').style.opacity = 1;
	}, 200);
	api.media.togglePlayPause();
	
}


function next() {
	document.getElementById('next').style.transform = 'translateY(-50%) scale(1.5,1.5)';
	setTimeout(function (){
		document.getElementById('next').style.transform = 'translateY(-50%) scale(1,1)';
	}, 200);
	api.media.nextTrack();
}
			
function prev() {
	document.getElementById('prev').style.transform = 'translateY(-50%) scale(1.5,1.5)';
	setTimeout(function (){
		document.getElementById('prev').style.transform = 'translateY(-50%) scale(1,1)';
	}, 200);
	api.media.previousTrack();
}


function checkOverflow(el) {
	var curOverflow = el.style.overflow;
	if ( !curOverflow || curOverflow === "visible" ){
		el.style.overflow = "hidden"; 
	}
	var isOverflowing = el.clientWidth < el.scrollWidth;// || el.clientHeight < el.scrollHeight
	el.style.overflow = curOverflow;
	return isOverflowing; 
} 


