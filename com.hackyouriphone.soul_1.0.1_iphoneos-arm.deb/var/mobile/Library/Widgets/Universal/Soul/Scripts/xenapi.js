


function XenApi(){
	
	//if(config.fc){
		api.system.observeData(function (newData) {	
			document.getElementById('dev-name').innerHTML = newData.deviceType;
		});
		
		api.resources.observeData(function (newData) {
			checkBattery(newData);
		});
		
		api.comms.observeData(function (newData) {
			checkComms(newData);
		});
		
		api.weather.observeData(function (newData) {
			checkWeather(newData);
		});
		
		api.media.observeData(function (newData) {
			appPlaying = newData.nowPlayingApplication.identifier;
			checkMusic(newData);
		});
		
		api.calendar.observeData(function(newData) {
			checkCalendar(newData);
		});
	//}
	
}

function checkWeather(newData){
	
	document.getElementById('cond').innerHTML = newData.now.condition.description;
	document.getElementById('temp').innerHTML = newData.now.temperature.current + 'º';
	document.getElementById('mm').innerHTML = newData.now.temperature.minimum + 'º/' + newData.now.temperature.maximum + 'º';
	document.getElementById('wIcon').src = 'weather/' + newData.now.condition.code + '.png';
}

function checkCalendar(newData){
	const hasAnyEvents = newData.upcomingWeekEvents.length > 0;
	
	const today = new Date();
    today.setDate(today.getDate() + 1);
    today.setHours(0, 0, 0, 0);
	
	const hasTodayEvent = hasAnyEvents ? newData.upcomingWeekEvents[0].start <= today.getTime() : false;
	
	 if(hasTodayEvent){
     	const nextEvent = newData.upcomingWeekEvents[0];
            
        document.getElementById('bar').style.background = nextEvent.calendar.color;
            
        if (nextEvent.allDay) {
        	document.getElementById('_eve').innerText = nextEvent.title + '\nAll day';
        } else {
            const formatted = new Date(nextEvent.start).toLocaleTimeString(undefined, {
            	hour: '2-digit', 
            	minute: '2-digit'
         	});
                
        	document.getElementById('_eve').innerText = nextEvent.title + '\n' + formatted;
    	}
	}else{
    	document.getElementById('_eve').innerText = 'No upcoming events';
        document.getElementById('bar').style.background = 'var(--primary)';
	}
}

//------------------------- BATTERY FUNCTIONS ---------------------------
function checkBattery(newData) {
	"use strict";

	document.getElementById('percent').innerHTML = newData.battery.percentage + '%';
	
	document.getElementById("lvl").style.width = newData.battery.percentage + '%';
	
}


function checkComms(newData){
	const container = document.getElementById('bl-dev-cont');
	
	function createDevice(index){
		var cont = document.createElement('div'),
			per = document.createElement('div'),
			name = document.createElement('div'),
			ic = document.createElement('img'),
			ga = document.createElement('div');
			
		cont.className = 'battery morph';
		cont.id = 'device' + index;
		
		ga.className = 'lvl';
		ga.id = 'lvl' + index;
		cont.appendChild(ga);
		
		per.className = 'percent';
		per.innerHTML = 'device' + index;
		per.id = 'percent' + index;
		cont.appendChild(per);
		
		name.className = 'name';
		name.innerHTML = 'device' + index;
		name.id = 'name' + index;
		cont.appendChild(name);
		
		if(config.da){
			ic.className = 'icon invertColor';
		}else{
			ic.className = 'icon';
		}
		ic.id = 'icon' + index;
		cont.appendChild(ic);
		
		container.appendChild(cont);
	}
	
	if (newData.bluetooth.devices.length > 0) {
		container.innerHTML = '';
		container.style.display = 'inline-block';
		
		for(var i=0; i < newData.bluetooth.devices.length; i++){
			if(i < 2){
				createDevice(i);
				document.getElementById('percent' + i).innerHTML = newData.bluetooth.devices[i].supportsBattery ? newData.bluetooth.devices[i].battery + '%' : 'N/A';
				document.getElementById('lvl' + i).style.width = newData.bluetooth.devices[i].supportsBattery ? newData.bluetooth.devices[i].battery + '%' : '0%';
				
				if(newData.bluetooth.devices[i].majorClass === 1024){
					document.getElementById('icon' + i).src = 'img/headphones.svg';
				}else if(newData.bluetooth.devices[i].majorClass === 1792){
					document.getElementById('icon' + i).src = 'img/watch.svg';
				}else{
					document.getElementById('icon' + i).src = 'img/bluetooth.svg';
				}
				
				document.getElementById('name' + i).innerHTML = newData.bluetooth.devices[i].name;
			}
		}
	}else{
		container.style.display = 'none';
	}
	
}








