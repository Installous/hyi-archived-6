function ordinal_suffix_of(i) {
	var j = i % 10,
		k = i % 100;
	if (j == 1 && k != 11) {
		return i + "st";
	}
	if (j == 2 && k != 12) {
		return i + "nd";
	}
	if (j == 3 && k != 13) {
		return i + "rd";
	}
	return i + "th";
}

function updateTime(){
	var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	var currentTime = new Date();
	var hours = currentTime.getHours();
	var minutes = currentTime.getMinutes();
	var day = currentTime.getDate();
	var monthIndex = currentTime.getMonth();
	var year = currentTime.getFullYear();
	if (minutes < 10){
		minutes = "0" + minutes
	}
	if(hours > 12){
		hours = hours - 12;
	}
	var t_str = hours + ":" + minutes;
	document.getElementById('time').innerHTML = t_str;
	document.getElementById('current_date').innerHTML = "Date: " + ordinal_suffix_of(day) + " " + monthNames[monthIndex] + " " + year;
}

setInterval(updateTime, 1000);
