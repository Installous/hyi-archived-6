Luna for iOS by: [null] aka akidwithnoname



Twitter: @akidwithnoname

Email: akidwithnoname@gmail.com




Luna is my take on how iOS 7-8 should have looked like in the first place. The subtle gradients and carefully chosen color scheme give each icon a unified design that greatly improves the look and feel of iOS 7/8, no more radically inconsistent looking icons which causes the chaotic look of stock iOS 7/8.


Please visit 
http://null-bin.blogspot.com/2015/06/luna-for-ios.html

 for Wallpapers, Instructions, More Information, Support, and Extras

Compatibility: This theme is fully supported on (iPhone 4/4s 5/5s/5c 6/6+ & iPod Touch 5/6) from iOS 7.0 to 8.4



Luna fonts: Luna was designed to go well with the Ubuntu font family, I recomend using 'Ubuntu Light Font' with Luna as it is used throughout some of the artwork in this theme. There is also the normal 'Ubuntu Font' and the more familiar 'Ubuntu Mono Font' all of which are available on Cydia for free. Fonts can be installed via BytaFont2.


Tweaks I used to make my theme fully complete: 

BytaFont2 (to change system font)

Iconomatic (to add shadows and custom folder icon)

FolderIcons (to remove folder icons so the Iconomatic theme shows through)

To request icons to be added/changed please use the 'Request an Icon or Tweak to be Themed' link on the Luna homepage here: http://null-bin.blogspot.com/2015/06/luna-for-ios.html or email me at 'akidwithnoname@gmail.com' using 'Luna for iOS, Icon/Tweak Request' as the subject line. Include proof of purchase such as your recipt, device UDID, or a screenshot of Cydia showing you've purchased Luna and please also include either the bundle ID and Application Icon file names or the info.plist from the app, it is not necessary but is very helpful if the application is paid or hard to find. 




Special thanks to Zach Wallenta, aka @z8137 on Twitter for helping me with testing iPhone 6 compatibility and providing screenshots. 